import { create } from 'zustand';
import { get as idbGet, set as idbSet, del as idbDel } from 'idb-keyval';
import type {
  AppScreen, CarBuild, PartInstance, ProcessStepDef, StepRuntimeState, QualityReport,
} from '../types';
import { getCarModel } from '../data/carModels';
import { buildProcessPlan } from '../data/processTemplates';
import type { TaskSpec } from '../manufacturing/recipes';

const SAVE_KEY = 'make-everything-save-v1';

/** Checks for a saved build without touching store state — used by the menu to decide whether to show "이어서 제작하기". */
export async function hasSavedBuild(): Promise<boolean> {
  const saved = await idbGet(SAVE_KEY);
  return !!saved?.build;
}

interface SelectionState {
  carModelId: string | null;
  selectedOptionIds: string[];
}

export interface SessionHud {
  title: string;
  phase: string;
  hint: string;
  /** 0..100, optional */
  progress?: number;
  stats?: string;
  actions?: { label: string; disabled?: boolean; onClick: () => void }[];
}

interface GameState {
  screen: AppScreen;
  selection: SelectionState;
  build: CarBuild | null;
  selectedPartId: string | null;
  activeStepId: string | null;
  qualityReport: QualityReport | null;
  /**
   * Cross-tree crafting handoff: a DOM station panel (outside the R3F
   * canvas) sets this to ask the 3D workshop to open a full CraftRig
   * session (carve mold → heat → pour → quench → polish) for one
   * specific output. When the rig finishes, it calls onDone with the
   * achieved quality/errors, then the field is cleared. Not persisted —
   * it's pure UI handoff, never part of a saved build.
   */
  craftTarget: {
    id: string;
    label: string;
    spec: TaskSpec;
    /** where the task is physically performed (bench by default; the unit's target spot for fastening/painting) */
    origin?: [number, number, number];
    /** cast tasks: the sand mould carved earlier for THIS unit (quality only; the grid itself lives in moldStore) */
    mold?: { quality: number; errors: string[] } | null;
    /** unit key used to find this unit's carved mould in moldStore */
    unitKey?: string;
    /** part shape key (piston, wheel, panel ...) — decides the cavity outline */
    shape?: string;
    onDone: (quality: number, errors: string[], extra?: { carveQuality?: number }) => void;
  } | null;
  setCraftTarget: (t: GameState['craftTarget']) => void;
  /** system-controlled camera shot while a hand-work session runs */
  shot: { pos: [number, number, number]; look: [number, number, number]; snap: boolean; id: number } | null;
  setShot: (pos: [number, number, number], look: [number, number, number], snap?: boolean) => void;
  /** black veil used for the walk-to-another-room transition */
  fade: boolean;
  setFade: (v: boolean) => void;
  /** HUD card of the running session (phase, progress, buttons) */
  hud: SessionHud | null;
  setHud: (h: SessionHud | null) => void;
  /** whether the session HUD is collapsed to a small badge (player toggle) */
  hudCollapsed: boolean;
  setHudCollapsed: (v: boolean) => void;
  /**
   * 3D guide arrow floating above the next thing the player should do.
   * Each stage writes {pos, label, key} here; writing `null` clears it.
   * The arrow fades out on its own 3 seconds after the stage reports the
   * step as handled (by calling `fadeGuide(key)`); the stage then writes
   * the next target.
   */
  guide: { pos: [number, number, number]; label?: string; key: string; fadingSince: number | null } | null;
  setGuide: (g: { pos: [number, number, number]; label?: string; key: string } | null) => void;
  fadeGuide: (key: string) => void;
  /** short feedback line shown over the 3D view (placement results etc.) */
  toast: { text: string; tone: 'ok' | 'bad'; id: number } | null;
  showToast: (text: string, tone?: 'ok' | 'bad') => void;
  /** asks the camera to glide to a point (station buttons / new tasks) */
  focus: { pos: [number, number, number]; dist: number; id: number } | null;
  requestFocus: (pos: [number, number, number], dist?: number) => void;

  // navigation
  setScreen: (s: AppScreen) => void;
  selectCarModel: (id: string) => void;
  toggleOption: (id: string) => void;
  confirmOptionsAndStartBuild: () => void;

  // build/process
  setActiveStep: (stepId: string | null) => void;
  updateStepProgress: (stepId: string, progress: number, data?: Record<string, unknown>) => void;
  completeStep: (stepId: string, qualityScore: number, errors: string[]) => void;
  resetStep: (stepId: string) => void;
  /** Deletes every part whose id was spawned by this step (id prefix `${stepId}-`). */
  clearStepParts: (stepId: string) => void;
  /** Marks the step completed as-is (whatever was done, or nothing) and unlocks the next one. Used when the player chooses not to finish a step. */
  forceAdvanceStep: (stepId: string) => void;
  advanceToNextStep: () => void;

  // parts
  upsertPart: (part: PartInstance) => void;
  updatePartTransform: (id: string, pos: [number, number, number], rot: [number, number, number]) => void;
  setSelectedPart: (id: string | null) => void;
  removePart: (id: string) => void;

  // quality / completion
  finalizeCar: () => void;

  // persistence
  saveToStorage: () => Promise<void>;
  loadFromStorage: () => Promise<boolean>;
  resetAll: () => void;
  /** Fully abandons the car being built: wipes the save file and all in-memory progress, back to the main menu. Not recoverable. */
  abandonBuild: () => Promise<void>;

  // undo/redo (lightweight, per-part-transform)
  history: { past: PartInstance[][]; future: PartInstance[][] };
  pushHistory: () => void;
  undo: () => void;
  redo: () => void;
}

function initialStepStates(steps: ProcessStepDef[]): Record<string, StepRuntimeState> {
  const states: Record<string, StepRuntimeState> = {};
  steps.forEach((s) => {
    // free navigation: every step is reachable from the start. If a step's
    // task needs a part that doesn't exist yet, the panel will tell the
    // player which step to make it in.
    states[s.id] = {
      stepId: s.id,
      status: 'available',
      progress: 0,
      qualityScore: 0,
      errors: [],
      data: {},
    };
  });
  return states;
}

export const useGameStore = create<GameState>((set, get) => ({
  screen: 'intro',
  selection: { carModelId: null, selectedOptionIds: [] },
  build: null,
  selectedPartId: null,
  activeStepId: null,
  qualityReport: null,
  craftTarget: null,
  shot: null,
  fade: false,
  hud: null,
  hudCollapsed: false,
  guide: null,
  toast: null,
  focus: null,
  history: { past: [], future: [] },

  setShot: (pos, look, snap = false) => set({ shot: { pos, look, snap, id: Date.now() + Math.random() } }),
  setFade: (v) => set({ fade: v }),
  setHud: (h) => set({ hud: h }),
  setHudCollapsed: (v) => set({ hudCollapsed: v }),
  setGuide: (g) =>
    set((state) => {
      // ignore no-op writes so React doesn't re-render every frame
      const cur = state.guide;
      if (!g) return cur ? { guide: null } : state;
      if (cur && cur.key === g.key && !cur.fadingSince) return state;
      return { guide: { ...g, fadingSince: null } };
    }),
  fadeGuide: (key) =>
    set((state) => {
      const cur = state.guide;
      if (!cur || cur.key !== key || cur.fadingSince) return state;
      return { guide: { ...cur, fadingSince: Date.now() } };
    }),

  showToast: (text, tone = 'ok') => {
    const id = Date.now() + Math.random();
    set({ toast: { text, tone, id } });
    setTimeout(() => {
      if (get().toast?.id === id) set({ toast: null });
    }, 3200);
  },

  requestFocus: (pos, dist = 7) => set({ focus: { pos, dist, id: Date.now() + Math.random() } }),

  setScreen: (s) => set({ screen: s }),

  setCraftTarget: (t) => set({ craftTarget: t }),

  selectCarModel: (id) => set({ selection: { carModelId: id, selectedOptionIds: [] } }),

  toggleOption: (id) =>
    set((state) => {
      const has = state.selection.selectedOptionIds.includes(id);
      return {
        selection: {
          ...state.selection,
          selectedOptionIds: has
            ? state.selection.selectedOptionIds.filter((o) => o !== id)
            : [...state.selection.selectedOptionIds, id],
        },
      };
    }),

  confirmOptionsAndStartBuild: () => {
    const { selection } = get();
    if (!selection.carModelId) return;
    const car = getCarModel(selection.carModelId);
    if (!car) return;
    const steps = buildProcessPlan(car, selection.selectedOptionIds);
    const build: CarBuild = {
      carModelId: car.id,
      selectedOptionIds: selection.selectedOptionIds,
      steps,
      stepStates: initialStepStates(steps),
      parts: {},
      snapshots: [],
      startedAt: Date.now(),
      currentStepIndex: 0,
    };
    set({ build, screen: 'workshop', activeStepId: steps[0]?.id ?? null });
    get().saveToStorage();
  },

  setActiveStep: (stepId) => set({ activeStepId: stepId, craftTarget: null, hud: null, hudCollapsed: false, guide: null, fade: false }),

  updateStepProgress: (stepId, progress, data) =>
    set((state) => {
      if (!state.build) return state;
      const prev = state.build.stepStates[stepId];
      if (!prev) return state;
      return {
        build: {
          ...state.build,
          stepStates: {
            ...state.build.stepStates,
            [stepId]: {
              ...prev,
              status: 'inProgress',
              progress: Math.max(prev.progress, Math.min(100, progress)),
              data: data ? { ...prev.data, ...data } : prev.data,
            },
          },
        },
      };
    }),

  completeStep: (stepId, qualityScore, errors) =>
    set((state) => {
      if (!state.build) return state;
      const steps = state.build.steps;
      const idx = steps.findIndex((s) => s.id === stepId);
      const nextStepId = steps[idx + 1]?.id;
      const stepStates = { ...state.build.stepStates };
      stepStates[stepId] = {
        ...stepStates[stepId],
        status: 'completed',
        progress: 100,
        qualityScore,
        errors,
        completedAt: Date.now(),
      };
      if (nextStepId && stepStates[nextStepId]?.status === 'locked') {
        stepStates[nextStepId] = { ...stepStates[nextStepId], status: 'available' };
      }
      const snapshot = {
        stepId,
        takenAt: Date.now(),
        partIds: Object.keys(state.build.parts),
        qualityScore,
        note: `${stepId} 단계 완료 (품질 ${qualityScore}점)`,
      };
      return {
        build: {
          ...state.build,
          stepStates,
          snapshots: [...state.build.snapshots, snapshot],
          currentStepIndex: Math.max(state.build.currentStepIndex, idx + 1),
        },
      };
    }),

  // "현재 진행 중인 프로세스만 초기화" — only resets the target step's
  // runtime state and any parts tagged as belonging to it; everything else
  // (previously completed steps, other parts) is untouched.
  resetStep: (stepId) =>
    set((state) => {
      if (!state.build) return state;
      const prev = state.build.stepStates[stepId];
      if (!prev) return state;
      return {
        build: {
          ...state.build,
          stepStates: {
            ...state.build.stepStates,
            [stepId]: { stepId, status: 'available', progress: 0, qualityScore: 0, errors: [], data: {} },
          },
        },
      };
    }),

  clearStepParts: (stepId) =>
    set((state) => {
      if (!state.build) return state;
      const parts = { ...state.build.parts };
      let changed = false;
      for (const id of Object.keys(parts)) {
        if (id === stepId || id.startsWith(`${stepId}-`)) {
          delete parts[id];
          changed = true;
        }
      }
      if (!changed) return state;
      return { build: { ...state.build, parts }, selectedPartId: null };
    }),

  forceAdvanceStep: (stepId) =>
    // free-navigation mode: "skip" just moves to the next step without
    // marking this one completed, so coming back opens the normal panel.
    set((state) => {
      if (!state.build) return state;
      const steps = state.build.steps;
      const idx = steps.findIndex((s) => s.id === stepId);
      const nextStepId = steps[idx + 1]?.id;
      return { activeStepId: nextStepId ?? null };
    }),

  advanceToNextStep: () =>
    set((state) => {
      if (!state.build) return state;
      const idx = state.build.currentStepIndex;
      const next = state.build.steps[idx];
      if (!next) return state;
      return { activeStepId: next.id };
    }),

  upsertPart: (part) =>
    set((state) => {
      if (!state.build) return state;
      return { build: { ...state.build, parts: { ...state.build.parts, [part.id]: part } } };
    }),

  updatePartTransform: (id, pos, rot) =>
    set((state) => {
      if (!state.build) return state;
      const part = state.build.parts[id];
      if (!part) return state;
      return {
        build: {
          ...state.build,
          parts: { ...state.build.parts, [id]: { ...part, position: pos, rotation: rot } },
        },
      };
    }),

  setSelectedPart: (id) => set({ selectedPartId: id }),

  removePart: (id) =>
    set((state) => {
      if (!state.build) return state;
      const parts = { ...state.build.parts };
      delete parts[id];
      return { build: { ...state.build, parts }, selectedPartId: null };
    }),

  finalizeCar: () =>
    set((state) => {
      if (!state.build) return state;
      const steps = state.build.steps;
      const states = state.build.stepStates;

      const scoreOf = (category: string) => {
        const relevant = steps.filter((s) => s.category === category);
        if (relevant.length === 0) return 100;
        const scores = relevant.map((s) => states[s.id]?.qualityScore ?? 0);
        return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
      };

      const bodyScore = Math.round((scoreOf('bodyPanel') + scoreOf('frame')) / 2);
      const engineScore = scoreOf('engine');
      const elecScore = scoreOf('electronics');
      const assemblyScore = scoreOf('finalAssembly');
      const overall = Math.round(
        (bodyScore + engineScore + elecScore + assemblyScore) / 4,
      );

      const errorLog = steps.flatMap((s) => states[s.id]?.errors.map((e) => `[${s.title}] ${e}`) ?? []);
      const functioning: string[] = [];
      const broken: string[] = [];
      for (const s of steps) {
        if (s.category !== 'electronics') continue;
        const st = states[s.id];
        if (!st) continue;
        const powered = st.data['powered'] !== false;
        if (st.qualityScore >= 50 && powered) functioning.push(s.title);
        else broken.push(s.title);
      }

      const fuelEfficiency = Math.max(4, Math.round((10 + (100 - engineScore) * -0.04 + (overall - 50) * 0.03) * 10) / 10);
      const totalMinutes = steps.reduce((sum, s) => sum + (states[s.id]?.status === 'completed' ? s.estimatedMinutes : 0), 0);

      const report: QualityReport = {
        overall, body: bodyScore, engine: engineScore, electronics: elecScore, assembly: assemblyScore,
        fuelEfficiency, functioningFeatures: functioning, brokenFeatures: broken, errorLog, totalMinutes,
      };

      return {
        qualityReport: report,
        build: { ...state.build, completedAt: Date.now() },
        screen: 'completion',
      };
    }),

  saveToStorage: async () => {
    const { selection, build } = get();
    await idbSet(SAVE_KEY, { selection, build });
  },

  loadFromStorage: async () => {
    const saved = await idbGet(SAVE_KEY);
    if (!saved) return false;
    set({ selection: saved.selection, build: saved.build, activeStepId: saved.build?.steps?.[Math.max(0, Math.min(saved.build.currentStepIndex ?? 0, saved.build.steps.length - 1))]?.id ?? null });
    return true;
  },

  resetAll: () => set({
    screen: 'menu', selection: { carModelId: null, selectedOptionIds: [] },
    build: null, selectedPartId: null, activeStepId: null, qualityReport: null,
    craftTarget: null, shot: null, fade: false, hud: null, hudCollapsed: false, guide: null, toast: null, focus: null, history: { past: [], future: [] },
  }),

  abandonBuild: async () => {
    await idbDel(SAVE_KEY);
    set({
      screen: 'menu', selection: { carModelId: null, selectedOptionIds: [] },
      build: null, selectedPartId: null, activeStepId: null, qualityReport: null,
      craftTarget: null, shot: null, fade: false, hud: null, hudCollapsed: false, guide: null, toast: null, focus: null, history: { past: [], future: [] },
    });
  },

  pushHistory: () =>
    set((state) => {
      if (!state.build) return state;
      const parts = Object.values(state.build.parts);
      return { history: { past: [...state.history.past.slice(-49), parts], future: [] } };
    }),

  undo: () =>
    set((state) => {
      if (!state.build || state.history.past.length === 0) return state;
      const past = [...state.history.past];
      const prevParts = past.pop()!;
      const currentParts = Object.values(state.build.parts);
      const partsMap: Record<string, PartInstance> = {};
      prevParts.forEach((p) => { partsMap[p.id] = p; });
      return {
        build: { ...state.build, parts: partsMap },
        history: { past, future: [currentParts, ...state.history.future] },
      };
    }),

  redo: () =>
    set((state) => {
      if (!state.build || state.history.future.length === 0) return state;
      const [nextParts, ...rest] = state.history.future;
      const currentParts = Object.values(state.build.parts);
      const partsMap: Record<string, PartInstance> = {};
      nextParts.forEach((p) => { partsMap[p.id] = p; });
      return {
        build: { ...state.build, parts: partsMap },
        history: { past: [...state.history.past, currentParts], future: rest },
      };
    }),
}));
