import { useGameStore } from './store/useGameStore';
import type { AppScreen } from './types';

const BASE = import.meta.env.BASE_URL.replace(/\/$/, '');
const paths: Record<AppScreen, string> = {
  intro: 'main', menu: 'main', tutorial: 'tutorial', carSelect: 'choose',
  modelSelect: 'models', optionSelect: 'options', workshop: 'workshop',
  completion: 'completion', drive: 'drive',
};
const screens: Record<string, AppScreen> = {
  main: 'intro', tutorial: 'tutorial', choose: 'carSelect', models: 'modelSelect',
  options: 'optionSelect', workshop: 'workshop', completion: 'completion', drive: 'drive',
};
const pathFor = (screen: AppScreen) => `${BASE}/${paths[screen]}`;
const selectionKey = 'make-everything-route-selection';

function readPath(): string {
  const redirected = new URLSearchParams(location.search).get('__route');
  if (redirected) return redirected.replace(/^\/+|\/+$/g, '');
  let path = location.pathname;
  if (BASE && (path === BASE || path.startsWith(BASE + '/'))) path = path.slice(BASE.length);
  return path.replace(/^\/+|\/+$/g, '');
}

/** Keep the URL, history and the existing game store in sync. */
export async function startRouting() {
  const store = useGameStore;
  try {
    const raw = sessionStorage.getItem(selectionKey);
    if (raw) {
      const selection = JSON.parse(raw);
      if (typeof selection.carModelId === 'string' && Array.isArray(selection.selectedOptionIds)) {
        store.setState({ selection });
      }
    }
  } catch { /* private browsing can disable storage */ }

  let navigating = false;
  let navigationId = 0;
  const navigate = async (path: string) => {
    const id = ++navigationId;
    let screen = screens[path] ?? 'intro';
    if (screen === 'optionSelect' && !store.getState().selection.carModelId) screen = 'modelSelect';
    if (screen === 'workshop' || screen === 'completion' || screen === 'drive') {
      if (!store.getState().build) {
        try { await store.getState().loadFromStorage(); } catch { /* no usable save */ }
      }
      if (id !== navigationId) return;
      if (!store.getState().build) screen = 'carSelect';
      else if ((screen === 'completion' || screen === 'drive') && !store.getState().qualityReport) screen = 'workshop';
    }
    navigating = true;
    store.setState({ screen, craftTarget: null, hud: null, guide: null, fade: false });
    navigating = false;
    const target = pathFor(screen);
    if (location.pathname !== target || location.search.includes('__route') || !screens[path]) history.replaceState(null, '', target);
  };

  await navigate(readPath());
  store.subscribe((state, previous) => {
    if (state.selection !== previous.selection) {
      try { sessionStorage.setItem(selectionKey, JSON.stringify(state.selection)); } catch { /* optional */ }
    }
    if (!navigating && state.screen !== previous.screen) {
      const target = pathFor(state.screen);
      if (location.pathname !== target) history.pushState(null, '', target);
    }
  });
  window.addEventListener('popstate', () => { void navigate(readPath()); });
}
