import { useEffect, useState } from 'react';
import { useGameStore, hasSavedBuild } from '../store/useGameStore';
import { clearMoulds } from '../scenes/foundryKit';

export default function IntroScreen() {
  const setScreen = useGameStore(s => s.setScreen);
  const load = useGameStore(s => s.loadFromStorage);
  const [saved, setSaved] = useState(false);
  useEffect(() => { hasSavedBuild().then(setSaved).catch(() => setSaved(false)); }, []);
  const start = async () => { if (saved && await load()) setScreen('workshop'); else setScreen('carSelect'); };
  return <main className="landing">
    <div className="sky" aria-hidden="true"><div className="nebula"/><div className="stars stars-a"/><div className="stars stars-b"/></div>
    <header className="landing-nav"><span className="brand-mark">M<span>✳</span>E</span><span className="nav-note">A GAME BY LDY9218</span></header>
    <section className="landing-hero">
      <div className="hero-copy"><div className="eyebrow"><span/> A WORLD MADE BY YOU</div>
        <h1>MAKE<br/><em>EVERYTHING</em><span className="title-dot">.</span></h1>
        <p className="hero-lead">상상한 자동차를, <strong>당신의 손으로.</strong></p>
        <p className="hero-description">모래를 깎고, 쇳물을 붓고, 부품을 조립하세요.<br/>작은 실수까지 나만의 이야기가 되는 작업실.</p>
        <div className="hero-actions"><button className="hero-button primary" onClick={start}>{saved ? '이어서 만들기' : '작업실 입장'} <span>↗</span></button><button className="hero-button secondary" onClick={() => setScreen('tutorial')}>이용 방법 <span>→</span></button></div>
        {saved && <button className="new-build" onClick={() => { clearMoulds(); setScreen('carSelect'); }}>새 자동차 만들기 →</button>}
      </div>
      <div className="hero-art" aria-hidden="true"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="blueprint"><div className="blueprint-top">PROJECT 001 <span>HAND BUILT / AUTOMOBILE</span></div><svg viewBox="0 0 600 250" fill="none"><path d="M48 171 L75 143 L157 126 L211 75 Q225 65 251 64 L375 64 Q400 65 424 88 L472 128 L536 142 Q555 148 558 170 L555 187 H526 M101 187 H72 Q49 186 48 171Z"/><path d="M172 125 L220 82 Q230 77 252 77 H294 V125 Z M307 77 H370 Q389 77 406 94 L438 125 H307 Z"/><circle cx="145" cy="185" r="35"/><circle cx="145" cy="185" r="19"/><circle cx="480" cy="185" r="35"/><circle cx="480" cy="185" r="19"/><path d="M180 185 H445 M306 128 V176 M70 154 H102 M520 154 H550"/></svg><div className="blueprint-bottom"><span>DESIGNED TO BE MADE</span><span>01 — 10</span></div></div><div className="art-label">IDEA <b>→</b> OBJECT</div></div>
      <div className="hero-bottom"><span>SCROLL TO EXPLORE ↓</span><span>CREATE WITH INTENTION &nbsp; • &nbsp; EST. 2026</span></div>
    </section>
    <section className="landing-story"><div className="story-heading"><span>THE PROCESS / 제작의 즐거움</span><h2>손끝에서 시작되는<br/><em>작은 변화.</em></h2></div><div className="story-cards"><article><b>01 / SHAPE</b><h3>틀을 만들고</h3><p>선을 따라 모래를 깎아 부품의 형태를 만듭니다. 벗어난 자국도 그대로 남아요.</p></article><article><b>02 / CAST</b><h3>금속을 붓고</h3><p>연결된 틈을 따라 쇳물이 흘러갑니다. 손으로 만든 틀이 결과를 바꿉니다.</p></article><article><b>03 / ASSEMBLE</b><h3>하나씩 조립하고</h3><p>각 공정을 거친 부품을 모아 나만의 자동차를 완성해 보세요.</p></article></div><button className="hero-button primary" onClick={start}>작업 시작하기 <span>↗</span></button></section>
  </main>;
}
