import { useCallback, useEffect, useRef, useState } from 'react';
import { useGameStore } from '../store/useGameStore';
import { getCarModel } from '../data/carModels';
import DriveScene, { type ViewMode, type Telemetry } from '../scenes/DriveScene';

const VIEW_ORDER: ViewMode[] = ['interior', 'near', 'far'];
const VIEW_LABEL: Record<ViewMode, string> = { far: '3인칭 (원거리)', near: '3인칭 (근거리)', interior: '1인칭 · 운전석' };

export default function DriveScreen() {
  const build = useGameStore((s) => s.build);
  const report = useGameStore((s) => s.qualityReport);
  const setScreen = useGameStore((s) => s.setScreen);
  const model = build ? getCarModel(build.carModelId) : undefined;

  const [viewMode, setViewMode] = useState<ViewMode>('interior');
  const [night, setNight] = useState(false);
  const [muted, setMuted] = useState(false);
  const [help, setHelp] = useState(true);
  const [tele, setTele] = useState<Telemetry>({ speedKmh: 0, rpm: 900, gear: 1, indicator: 0, braking: false, headlights: false });
  const keysRef = useRef<Record<string, boolean>>({});

  useEffect(() => {
    const onDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
      keysRef.current[k] = true;
      if (e.repeat) return;
      if (k === 'v') setViewMode((v) => VIEW_ORDER[(VIEW_ORDER.indexOf(v) + 1) % VIEW_ORDER.length]);
      if (k === 't') setNight((v) => !v);
      if (k === 'm') setMuted((v) => !v);
      if (k === 'h') setHelp((v) => !v);
    };
    const onUp = (e: KeyboardEvent) => { keysRef.current[e.key.toLowerCase()] = false; };
    const onBlur = () => { keysRef.current = {}; };
    window.addEventListener('keydown', onDown);
    window.addEventListener('keyup', onUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onDown);
      window.removeEventListener('keyup', onUp);
      window.removeEventListener('blur', onBlur);
    };
  }, []);

  const onTelemetry = useCallback((t: Telemetry) => setTele(t), []);

  if (!build || !model || !report) return null;

  const gearText = tele.gear < 0 ? 'R' : tele.gear === 0 ? 'N' : String(tele.gear);

  return (
    <div className="workshop-root" onContextMenu={(e) => e.preventDefault()}>
      <div className="viewport-wrap" style={{ width: '100%' }}>
        <DriveScene
          model={model} report={report} viewMode={viewMode} keysRef={keysRef} night={night} muted={muted}
          onTelemetry={onTelemetry}
        />

        <div className="top-bar">
          <div className="breadcrumb">{model.manufacturer} {model.name} — 운전 · {VIEW_LABEL[viewMode]}</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn ghost sm" onClick={() => setViewMode((v) => VIEW_ORDER[(VIEW_ORDER.indexOf(v) + 1) % VIEW_ORDER.length])}>시점 (V)</button>
            <button className="btn ghost sm" onClick={() => setNight((v) => !v)}>{night ? '낮으로 (T)' : '밤으로 (T)'}</button>
            <button className="btn ghost sm" onClick={() => setMuted((v) => !v)}>{muted ? '소리 켜기 (M)' : '소리 끄기 (M)'}</button>
            <button className="btn ghost" onClick={() => setScreen('completion')}>완성 화면으로</button>
          </div>
        </div>

        {/* only outside views get a floating speed readout — inside the car the real gauge cluster does the job */}
        {viewMode !== 'interior' && (
          <div className="drive-readout">
            <span className="drive-speed">{Math.round(tele.speedKmh)}</span> km/h
            <span className="drive-gear">{gearText}</span>
            {tele.braking && <span className="drive-brake">BRAKE</span>}
          </div>
        )}

        {help && (
          <div className="hud-hint">
            <span><kbd>W/S</kbd>가속/후진</span>
            <span><kbd>A/D</kbd>조향</span>
            <span><kbd>Space</kbd>핸드브레이크</span>
            <span><kbd>Q/E</kbd>방향지시등</span>
            <span><kbd>L</kbd>전조등{report.electronics <= 40 ? ' (고장)' : ''}</span>
            <span><kbd>드래그</kbd>둘러보기</span>
            <span><kbd>R</kbd>제자리</span>
            <span><kbd>H</kbd>도움말 숨김</span>
          </div>
        )}
      </div>
    </div>
  );
}
