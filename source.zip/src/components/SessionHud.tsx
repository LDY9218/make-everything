import { useGameStore } from '../store/useGameStore';

// The card that tells the player what the current hand-work session wants:
// which phase, what to drag, how far along it is — plus the way out.
// Can be collapsed to a tiny chip when it feels in the way.
export default function SessionHud({
  onCancel, collapsed, onToggleCollapse,
}: {
  onCancel: () => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}) {
  const hud = useGameStore((s) => s.hud);
  const craft = useGameStore((s) => s.craftTarget);
  if (!craft) return null;
  if (collapsed) {
    return (
      <button className="session-hud-pill" onClick={onToggleCollapse} title="세션 창 다시 열기">
        {hud?.phase ?? '작업 중'} <span className="pill-expand">▾</span>
      </button>
    );
  }
  return (
    <div className="session-hud">
      <div className="session-hud-top">
        <div className="session-hud-title">{hud?.title ?? craft.label}</div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button className="btn ghost sm" onClick={onToggleCollapse} title="세션 창 접기">접기 ▴</button>
          <button className="btn ghost sm" onClick={onCancel}>작업 취소 (차고로)</button>
        </div>
      </div>
      {hud && (
        <>
          <div className="session-phase">{hud.phase}</div>
          <p className="session-hint">{hud.hint}</p>
          {hud.progress != null && (
            <div className="progress-track"><div className="progress-fill" style={{ width: `${Math.max(0, Math.min(100, hud.progress))}%` }} /></div>
          )}
          {hud.stats && <div className="session-stats">{hud.stats}</div>}
          {hud.actions && hud.actions.length > 0 && (
            <div className="session-actions">
              {hud.actions.map((a, i) => (
                <button key={i} className="btn accent sm" disabled={a.disabled} onClick={a.onClick}>{a.label}</button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
