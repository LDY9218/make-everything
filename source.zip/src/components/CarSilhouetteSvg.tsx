import type { CarModel } from '../types';

/**
 * Cheap, dependency-free side-profile silhouette generated purely from a
 * model's silhouette parameters, used for selection-card thumbnails.
 * Distinct per model since it is driven by actual length/height/hood/roof
 * ratios rather than a shared template image.
 */
export default function CarSilhouetteSvg({ model, color }: { model: CarModel; color?: string }) {
  const { length, height, hoodRatio, roofHeightRatio, rearSlope } = model.silhouette;
  const W = 200;
  const H = 100;
  const scale = (W * 0.86) / length;
  const bodyH = height * scale * 0.55;
  const baseY = H - 22;
  const bodyTop = baseY - bodyH;
  const bodyLen = length * scale;
  const startX = (W - bodyLen) / 2;
  const hoodLen = bodyLen * hoodRatio;
  const roofH = bodyH * roofHeightRatio;
  const cabinStart = startX + hoodLen;
  const cabinEnd = startX + bodyLen * (1 - rearSlope * 0.35);
  const fill = color ?? model.accentColor;

  const path = `
    M ${startX} ${baseY}
    L ${startX} ${bodyTop + bodyH * 0.35}
    Q ${startX} ${bodyTop} ${startX + hoodLen * 0.3} ${bodyTop + bodyH * 0.15}
    L ${cabinStart} ${bodyTop + bodyH * 0.15}
    Q ${cabinStart + 10} ${bodyTop - roofH} ${(cabinStart + cabinEnd) / 2} ${bodyTop - roofH}
    Q ${cabinEnd - 6} ${bodyTop - roofH} ${cabinEnd} ${bodyTop + bodyH * 0.1}
    L ${startX + bodyLen} ${bodyTop + bodyH * 0.4}
    L ${startX + bodyLen} ${baseY}
    Z
  `;

  const wheelR = 11;
  const wheelY = baseY + 3;
  const wheel1X = startX + bodyLen * 0.22;
  const wheel2X = startX + bodyLen * 0.8;

  return (
    <svg width="100%" height="100%" viewBox={`0 0 ${W} ${H}`}>
      <line x1={8} y1={baseY + 3} x2={W - 8} y2={baseY + 3} stroke="#e4e4e7" strokeWidth={1.5} />
      <path d={path} fill={fill} opacity={0.92} />
      <circle cx={wheel1X} cy={wheelY} r={wheelR} fill="#1a1a1a" />
      <circle cx={wheel1X} cy={wheelY} r={wheelR * 0.45} fill="#4a4a4a" />
      <circle cx={wheel2X} cy={wheelY} r={wheelR} fill="#1a1a1a" />
      <circle cx={wheel2X} cy={wheelY} r={wheelR * 0.45} fill="#4a4a4a" />
    </svg>
  );
}
