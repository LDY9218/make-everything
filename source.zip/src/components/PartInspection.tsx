import { useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { useGameStore } from '../store/useGameStore';
import PartMesh from '../scenes/PartMesh';

/** Inventory and honest inspection of recorded task outcomes. */
export default function PartInspection({ onClose }: { onClose: () => void }) {
  const parts = useGameStore(s => s.build?.parts);
  const selected = useGameStore(s => s.selectedPartId);
  const setSelected = useGameStore(s => s.setSelectedPart);
  const requestFocus = useGameStore(s => s.requestFocus);
  const [id, setId] = useState<string | null>(selected);
  const list = Object.values(parts ?? {});
  const part = list.find(p => p.id === id) ?? list[0];
  return <div className="inspect-backdrop" role="presentation" onClick={onClose}>
    <section className="inspect-panel" role="dialog" aria-modal="true" aria-label="부품 보관함과 검사" onClick={e => e.stopPropagation()}>
      <header><div><span className="inspect-kicker">WORKSHOP / PARTS</span><h2>부품 보관함</h2></div><button className="btn ghost" onClick={onClose}>닫기 ×</button></header>
      {list.length === 0 ? <p className="inspect-empty">아직 완성된 부품이 없어요. 제작 공정을 마치면 여기에서 확인할 수 있어요.</p> : <div className="inspect-content">
        <div className="inspect-list">{list.map(p => <button key={p.id} className={p.id === part?.id ? 'active' : ''} onClick={() => setId(p.id)}><span>{p.label}</span><small>{p.assembled ? '장착됨' : '보관 중'} · 품질 {p.qualityScore}</small></button>)}</div>
        {part && <div className="inspect-detail"><div className="inspect-preview"><Canvas camera={{position:[2,1.5,2.5], fov:35}} dpr={[1,1.5]}><ambientLight intensity={1.3}/><directionalLight position={[3,5,3]} intensity={2}/><PartMesh label={part.label} defId={part.defId}/><OrbitControls enablePan={false}/></Canvas><span>드래그하여 회전 · 휠로 확대</span></div>
          <h3>{part.label}</h3><p>품질 <strong>{part.qualityScore}점</strong> · {part.assembled ? '차량에 장착됨' : '작업장에 보관 중'}</p>
          <p className="inspect-note">미리보기는 부품 종류를 보여주는 모형입니다. 실제 주조 형상의 치수를 측정하는 검사는 아직 지원하지 않습니다.</p>
          <h4>기록된 작업 결과</h4>{part.errors.length ? <ul>{part.errors.map((e,i)=><li key={i}>{e}</li>)}</ul> : <p>기록된 오류가 없습니다.</p>}
          <button className="btn accent" onClick={() => { setSelected(part.id); requestFocus(part.position, 5); onClose(); }}>작업장에서 위치 보기</button>
        </div>}
      </div>}
    </section>
  </div>;
}
