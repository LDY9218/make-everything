import { useGameStore } from '../store/useGameStore';
import { getCarModel } from '../data/carModels';
import { getOptionsByIds } from '../data/carOptions';
import type { OptionCategory } from '../types';

const CATEGORY_LABEL: Record<OptionCategory, string> = {
  engine: '엔진', transmission: '변속기', brakes: '브레이크', wheels: '휠', tires: '타이어',
  suspension: '서스펜션', navigation: '내비게이션', dashboard: '계기판', audio: '오디오',
  seats: '시트', steeringWheel: '핸들', exteriorColor: '외장 색상', lighting: '조명',
  electronics: '전자장치', safety: '안전장치',
};

export default function OptionSelectScreen() {
  const setScreen = useGameStore((s) => s.setScreen);
  const selection = useGameStore((s) => s.selection);
  const toggleOption = useGameStore((s) => s.toggleOption);
  const confirmOptionsAndStartBuild = useGameStore((s) => s.confirmOptionsAndStartBuild);

  const model = selection.carModelId ? getCarModel(selection.carModelId) : undefined;
  if (!model) return null;

  const options = getOptionsByIds(model.availableOptionIds);
  const byCategory = new Map<OptionCategory, typeof options>();
  for (const opt of options) {
    const list = byCategory.get(opt.category) ?? [];
    list.push(opt);
    byCategory.set(opt.category, list);
  }

  const selectedCount = selection.selectedOptionIds.length;
  const extraMinutes = getOptionsByIds(selection.selectedOptionIds).reduce((s, o) => s + o.extraMinutes, 0);

  return (
    <div className="select-screen">
      <button className="back-btn" onClick={() => setScreen('modelSelect')}>← 모델 다시 선택</button>
      <div className="select-header">
        <h1 className="select-title">{model.name} 옵션 구성</h1>
        <p className="select-sub">{model.manufacturer} · 선택한 옵션은 실제 제작 과정에 추가됩니다. (중복 선택 가능)</p>
      </div>

      <div style={{ display: 'flex', gap: 48 }}>
        <div className="option-list scroll-col" style={{ maxHeight: '60vh', paddingRight: 12 }}>
          {Array.from(byCategory.entries()).map(([cat, opts]) => (
            <div key={cat}>
              <div className="category-heading">{CATEGORY_LABEL[cat]}</div>
              {opts.map((opt) => {
                const selected = selection.selectedOptionIds.includes(opt.id);
                return (
                  <div
                    key={opt.id}
                    className={`option-row ${selected ? 'selected' : ''}`}
                    onClick={() => toggleOption(opt.id)}
                  >
                    <div>
                      <div className="option-row-name">{opt.name}</div>
                      <div className="option-row-desc">{opt.description}</div>
                      <div className="meta-row">
                        <span className="meta-chip">난이도 {opt.difficulty}/5</span>
                        <span className="meta-chip">+{opt.extraMinutes}분</span>
                      </div>
                    </div>
                    <div className={`checkbox ${selected ? 'on' : ''}`}>
                      {selected && (
                        <svg width="12" height="12" viewBox="0 0 12 12"><path d="M1 6L4.5 9.5L11 2" stroke="#0a0a0a" strokeWidth="2" fill="none" /></svg>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        <div style={{ width: 260, flexShrink: 0 }}>
          <div className="panel" style={{ border: '1px solid var(--color-border)', borderRadius: 16, width: 260 }}>
            <div style={{ padding: 20 }}>
              <h3 className="panel-heading">선택 요약</h3>
              <div style={{ fontSize: 13, color: 'var(--color-text-soft)', marginBottom: 6 }}>선택한 옵션</div>
              <div style={{ fontSize: 24, fontWeight: 800, marginBottom: 14 }}>{selectedCount}개</div>
              <div style={{ fontSize: 13, color: 'var(--color-text-soft)', marginBottom: 6 }}>추가 제작 시간</div>
              <div style={{ fontSize: 24, fontWeight: 800, marginBottom: 20 }}>+{extraMinutes}분</div>
              <button className="btn accent" style={{ width: '100%' }} onClick={confirmOptionsAndStartBuild}>
                제작 시작하기
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
