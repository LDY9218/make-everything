import { clearMoulds, dropMould } from '../scenes/foundryKit';
import { expandUnits } from '../manufacturing/recipes';
import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { useGameStore } from '../store/useGameStore';
import { getCarModel } from '../data/carModels';
import Workshop3D from '../scenes/Workshop3D';
import StepInteractionPanel from '../manufacturing/StepInteractionPanel';
import { buildTaskTotals, cancelTask, stepTaskCounts, type UnitsMap } from '../manufacturing/assemblyLogic';
import SessionHud from './SessionHud';

export default function WorkshopScreen() {
  const build = useGameStore((s) => s.build);
  const setScreen = useGameStore((s) => s.setScreen);
  const activeStepId = useGameStore((s) => s.activeStepId);
  const setActiveStep = useGameStore((s) => s.setActiveStep);
  const resetStep = useGameStore((s) => s.resetStep);
  const clearStepParts = useGameStore((s) => s.clearStepParts);
  const selectedPartId = useGameStore((s) => s.selectedPartId);
  const setSelectedPart = useGameStore((s) => s.setSelectedPart);
  const removePart = useGameStore((s) => s.removePart);
  const updatePartTransform = useGameStore((s) => s.updatePartTransform);
  const undo = useGameStore((s) => s.undo);
  const redo = useGameStore((s) => s.redo);
  const saveToStorage = useGameStore((s) => s.saveToStorage);
  const abandonBuild = useGameStore((s) => s.abandonBuild);
  const toast = useGameStore((s) => s.toast);
  const craftTarget = useGameStore((s) => s.craftTarget);
  const fade = useGameStore((s) => s.fade);
  const sessionCollapsed = useGameStore((s) => s.hudCollapsed);
  const setSessionCollapsed = useGameStore((s) => s.setHudCollapsed);

  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [gizmoMode, setGizmoMode] = useState<'translate' | 'rotate'>('translate');
  const [hudCollapsed, setHudCollapsed] = useState(false);

  const model = build ? getCarModel(build.carModelId) : undefined;

  // autosave whenever the build mutates meaningfully
  useEffect(() => {
    if (!build) return;
    const t = setTimeout(() => saveToStorage(), 500);
    return () => clearTimeout(t);
  }, [build, saveToStorage]);

  // bug fix: switching to a new step while the HUD was left collapsed used
  // to leave the new step's panel hidden with no obvious way to tell it
  // was even there. Every step change now opens the HUD fresh.
  useEffect(() => {
    setHudCollapsed(false);
  }, [activeStepId]);

  // 전체 초기화: wipes the save and every bit of in-memory progress, then
  // drops back to the main menu so the player starts again from car select.
  const handleFullReset = () => {
    if (confirm('전체 초기화할까요?\n\n지금까지 만든 모든 부품과 진행 상황이 저장되지 않고 완전히 삭제되며 메인 화면으로 돌아갑니다. 되돌릴 수 없습니다.')) {
      clearMoulds();
      void abandonBuild();
    }
  };

  // keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      if (e.ctrlKey && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); return; }
      if (e.ctrlKey && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }

      if (!selectedPartId || !build) {
        if (e.key === 'Escape') setActiveStep(null);
        return;
      }
      const part = build.parts[selectedPartId];
      if (!part) return;

      if (e.key.toLowerCase() === 't') {
        const [x, y, z] = part.rotation;
        updatePartTransform(selectedPartId, part.position, [x + Math.PI / 12, y, z]);
      } else if (e.key.toLowerCase() === 'r') {
        const [x, y, z] = part.rotation;
        updatePartTransform(selectedPartId, part.position, [x, y + Math.PI / 12, z]);
      } else if (e.key === 'Escape') {
        setSelectedPart(null);
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        removePart(selectedPartId);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedPartId, build, undo, redo, updatePartTransform, removePart, setSelectedPart, setActiveStep]);

  const totals = useMemo(() => (build ? buildTaskTotals(build) : { done: 0, total: 0 }), [build]);

  if (!build || !model) return null;

  const activeStep = build.steps.find((s) => s.id === activeStepId);
  const activeState = activeStep ? build.stepStates[activeStep.id] : undefined;
  // Panels open for any selected step — even a previously-completed one — so
  // players who moved on can go back and rework it.
  const showStation = !!(activeStep && activeState);

  return (
    <div
      className="workshop-root"
      onContextMenu={(e) => e.preventDefault()}
      style={{ '--lw': leftOpen ? '320px' : '0px', '--rw': rightOpen ? '340px' : '0px' } as CSSProperties}
    >
      {/* the 3D view always fills the whole screen — panels float above it, so opening / closing them never resizes the canvas */}
      <div className="viewport-wrap">
        <Workshop3D gizmoMode={gizmoMode} />
      </div>

      {/* 전체 초기화: fixed at the very top right, above every panel */}
      <button className="btn danger sm abandon-btn" onClick={handleFullReset}>⟲ 전체 초기화</button>
      <div className="top-bar">
        <div className="breadcrumb">{model.manufacturer} {model.name} / 제작 공정</div>
      </div>

      {/* LEFT PANEL */}
      <aside className={`panel left ${leftOpen ? 'open' : 'closed'}`} aria-hidden={!leftOpen}>
        <div className="panel-inner">
          <h3 className="panel-heading">제작 중인 자동차</h3>
          <div className="car-card" style={{ cursor: 'default' }}>
            <p className="car-card-name">{model.name}</p>
            <p className="car-card-manufacturer">{model.manufacturer}</p>
            <div className="rating-row"><span>선택 옵션</span><span>{build.selectedOptionIds.length}개</span></div>
            <div className="rating-row"><span>총 공정</span><span>{build.steps.length}단계</span></div>
            <div className="rating-row">
              <span>완료 공정</span>
              <span>{build.steps.filter((s) => build.stepStates[s.id]?.status === 'completed').length}단계</span>
            </div>
            <div className="rating-row"><span>손으로 한 작업</span><span>{totals.done}/{totals.total}</span></div>
          </div>

          <h3 className="panel-heading" style={{ marginTop: 24 }}>3D 작업 도구</h3>
          <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
            <button className={`btn sm ${gizmoMode === 'translate' ? 'primary' : 'ghost'}`} onClick={() => setGizmoMode('translate')}>이동</button>
            <button className={`btn sm ${gizmoMode === 'rotate' ? 'primary' : 'ghost'}`} onClick={() => setGizmoMode('rotate')}>회전</button>
          </div>
          {selectedPartId && (
            <button className="btn danger sm" onClick={() => removePart(selectedPartId)}>선택 부품 삭제</button>
          )}

          <div style={{ marginTop: 28 }}>
            <button className="btn ghost" onClick={() => { if (confirm('메인 메뉴로 돌아갈까요? 진행 상황은 자동 저장됩니다.')) { saveToStorage(); setScreen('menu'); } }}>
              메인 메뉴로
            </button>
          </div>
        </div>
      </aside>

      {/* RIGHT PANEL: every hand-made task is its own step */}
      <aside className={`panel right ${rightOpen ? 'open' : 'closed'}`} aria-hidden={!rightOpen}>
        <div className="panel-inner">
          <h3 className="panel-heading">제작 과정</h3>
          <div className="total-steps">
            <span>전체 <b>{totals.total}</b>단계 중 <b>{totals.done}</b>단계 완료</span>
            <div className="progress-track"><div className="progress-fill" style={{ width: `${totals.total ? (totals.done / totals.total) * 100 : 0}%` }} /></div>
          </div>
          <div className="step-list">
            {build.steps.map((step) => {
              const st = build.stepStates[step.id];
              // free navigation: no locked state, every step is clickable
              const completed = st?.status === 'completed';
              const active = activeStepId === step.id;
              const counts = step.interaction === 'inspection'
                ? null
                : stepTaskCounts(step, (st?.data?.['units'] as UnitsMap | undefined) ?? {});
              return (
                <div
                  key={step.id}
                  className={`step-item ${active ? 'active' : ''} ${completed ? 'completed' : ''}`}
                  onClick={() => setActiveStep(step.id)}
                >
                  <div className="step-item-top">
                    <span className="step-num">{completed ? '✓' : step.order}</span>
                    <span className="step-title">{step.title}</span>
                  </div>
                  <p className="step-desc">{step.taskDescription}</p>
                  <div className="progress-track"><div className="progress-fill" style={{ width: `${st?.progress ?? 0}%` }} /></div>
                  <div className="meta-row">
                    {counts && <span className="meta-chip strong">{counts.done}/{counts.total} 단계</span>}
                    <span className="meta-chip">목표: {step.goal}</span>
                    {completed && <span className="meta-chip">품질 {st.qualityScore}점</span>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </aside>

      {/* panel toggles: siblings of the panels, positioned from the same CSS variables, so they can never be covered or clipped */}
      <button
        type="button"
        className="edge-toggle left"
        aria-label={leftOpen ? '왼쪽 창 접기' : '왼쪽 창 펴기'}
        aria-expanded={leftOpen}
        onClick={() => setLeftOpen((v) => !v)}
      >
        {leftOpen ? '‹ 접기' : '펴기 ›'}
      </button>
      <button
        type="button"
        className="edge-toggle right"
        aria-label={rightOpen ? '오른쪽 창 접기' : '오른쪽 창 펴기'}
        aria-expanded={rightOpen}
        onClick={() => setRightOpen((v) => !v)}
      >
        {rightOpen ? '접기 ›' : '‹ 펴기'}
      </button>

      {/* everything that floats over the 3D view lives between the two panels */}
      <div className="vp-stage">
        {toast && <div key={toast.id} className={`toast ${toast.tone}`}>{toast.text}</div>}
        {craftTarget && <SessionHud onCancel={cancelTask} collapsed={sessionCollapsed} onToggleCollapse={() => setSessionCollapsed(!sessionCollapsed)} />}
        {!craftTarget && (
          <div className="hud-hint">
            <span><kbd>휠</kbd>확대축소</span>
            <span><kbd>우클릭</kbd>회전</span>
            <span><kbd>좌클릭 드래그</kbd>화면 이동 / 부품 잡기</span>
            <span><kbd>T/R</kbd>회전</span>
          </div>
        )}

        {showStation && activeStep && !craftTarget && (
          <div className={`station-overlay ${hudCollapsed ? 'collapsed' : ''}`}>
            <div className="station-overlay-head">
              <span className="station-overlay-title">
                {activeStep.order}. {activeStep.title}
                <button className="hud-collapse-btn" onClick={() => setHudCollapsed((v) => !v)}>
                  {hudCollapsed ? '펼치기 ▲' : '접기 ▼'}
                </button>
              </span>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  className="btn danger sm"
                  onClick={() => {
                    if (confirm('이 단계에서 만든 것을 전부 버리고 처음부터 다시 할까요? (포기하고 초기화)')) {
                      useGameStore.getState().setCraftTarget(null);
                      expandUnits(activeStep.materials, activeStep.title).forEach(unit => dropMould(`${activeStep.id}:${unit.key}`));
                      clearStepParts(activeStep.id);
                      resetStep(activeStep.id);
                    }
                  }}
                >
                  포기하고 초기화
                </button>
                <button className="btn ghost sm" onClick={() => setActiveStep(null)}>닫기</button>
              </div>
            </div>
            {!hudCollapsed && <StepInteractionPanel step={activeStep} />}
          </div>
        )}
      </div>

      {/* walking-to-another-room veil */}
      <div className={`fade-veil ${fade ? 'on' : ''}`} />
    </div>
  );
}
