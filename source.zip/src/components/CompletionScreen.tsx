import { useMemo } from 'react';
import { useGameStore } from '../store/useGameStore';
import { getCarModel } from '../data/carModels';

function ConfettiPiece({ seed }: { seed: number }) {
  const left = (seed * 37) % 100;
  const delay = (seed % 10) * 0.15;
  const duration = 2.6 + (seed % 5) * 0.3;
  const colors = ['#f5c518', '#0a0a0a', '#2fae56', '#0a5ea8', '#b42318'];
  const color = colors[seed % colors.length];
  return (
    <div
      className="confetti-piece"
      style={{
        left: `${left}%`, width: 8, height: 14, background: color,
        animation: `fall ${duration}s ${delay}s ease-in forwards`,
        transform: `rotate(${(seed * 53) % 360}deg)`,
      }}
    />
  );
}

export default function CompletionScreen() {
  const build = useGameStore((s) => s.build);
  const report = useGameStore((s) => s.qualityReport);
  const setScreen = useGameStore((s) => s.setScreen);
  const model = build ? getCarModel(build.carModelId) : undefined;
  const confetti = useMemo(() => Array.from({ length: 60 }, (_, i) => i), []);

  if (!build || !model || !report) return null;

  return (
    <div className="completion-screen">
      <style>{`@keyframes fall { to { transform: translateY(110vh) rotate(400deg); opacity: 0.3; } }`}</style>
      {confetti.map((i) => <ConfettiPiece key={i} seed={i} />)}

      <div className="menu-subtitle">{model.manufacturer} {model.name}</div>
      <h1 className="completion-title">YOUR CAR IS COMPLETE.</h1>

      <div className="completion-stats">
        <div className="stat-box"><div className="stat-val">{report.overall}</div><div className="stat-label">종합 품질</div></div>
        <div className="stat-box"><div className="stat-val">{report.body}</div><div className="stat-label">차체 품질</div></div>
        <div className="stat-box"><div className="stat-val">{report.engine}</div><div className="stat-label">엔진 품질</div></div>
        <div className="stat-box"><div className="stat-val">{report.electronics}</div><div className="stat-label">전자장치 품질</div></div>
        <div className="stat-box"><div className="stat-val">{report.assembly}</div><div className="stat-label">조립 품질</div></div>
        <div className="stat-box"><div className="stat-val">{report.fuelEfficiency}</div><div className="stat-label">연비 (km/L)</div></div>
        <div className="stat-box"><div className="stat-val">{report.totalMinutes}</div><div className="stat-label">제작 시간(분)</div></div>
        <div className="stat-box"><div className="stat-val">{report.errorLog.length}</div><div className="stat-label">발생 오류</div></div>
      </div>

      <div style={{ maxWidth: 560, fontSize: 12.5, color: 'var(--color-text-soft)', marginBottom: 28 }}>
        {report.functioningFeatures.length > 0 && <p>정상 작동: {report.functioningFeatures.join(', ')}</p>}
        {report.brokenFeatures.length > 0 && <p style={{ color: '#b42318' }}>작동 불가: {report.brokenFeatures.join(', ')}</p>}
      </div>

      <div style={{ display: 'flex', gap: 14 }}>
        <button className="btn ghost" onClick={() => setScreen('menu')}>메인 메뉴로</button>
        <button className="btn accent" onClick={() => setScreen('drive')}>DRIVE YOUR CAR</button>
      </div>
    </div>
  );
}
