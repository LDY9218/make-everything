import { useGameStore } from '../store/useGameStore';
import { CAR_MODELS } from '../data/carModels';
import CarPreview3D from './CarPreview3D';

const BODY_LABEL: Record<string, string> = {
  hypercar: '하이퍼카', sportscar: '스포츠카', luxury: '고급 승용차', sedan: '세단', suv: 'SUV',
};

function Stars({ count }: { count: number }) {
  return (
    <div className="stars">
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} className={`star ${i < count ? 'filled' : ''}`} />
      ))}
    </div>
  );
}

export default function ModelSelectScreen() {
  const setScreen = useGameStore((s) => s.setScreen);
  const selectCarModel = useGameStore((s) => s.selectCarModel);

  return (
    <div className="select-screen">
      <button className="back-btn" onClick={() => setScreen('carSelect')}>← 뒤로</button>
      <div className="select-header">
        <h1 className="select-title">모델 선택</h1>
        <p className="select-sub">10개 모델 중 제작할 자동차를 선택하세요.</p>
      </div>
      <div className="model-grid">
        {CAR_MODELS.map((model) => (
          <div
            key={model.id}
            className="model-card"
            onClick={() => { selectCarModel(model.id); setScreen('optionSelect'); }}
          >
            <div className="model-thumb" style={{ padding: 0 }}>
              <CarPreview3D model={model} size={140} />
            </div>
            <div className="model-body-type">{BODY_LABEL[model.bodyType]}</div>
            <p className="car-card-name">{model.name}</p>
            <p className="car-card-manufacturer">{model.manufacturer}</p>
            <p className="option-row-desc" style={{ minHeight: 36 }}>{model.description}</p>
            <div className="rating-row">
              <span>난이도</span>
              <Stars count={model.difficulty} />
            </div>
            <div className="rating-row">
              <span>예상 시간</span>
              <Stars count={model.estimatedHours} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
