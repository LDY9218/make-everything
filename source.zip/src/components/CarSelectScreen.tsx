import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Grid, Environment } from '@react-three/drei';
import { useGameStore } from '../store/useGameStore';
import { CAR_MODELS } from '../data/carModels';
import CarPreview3D from './CarPreview3D';

function Stars({ count }: { count: number }) {
  return (
    <div className="stars">
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} className={`star ${i < count ? 'filled' : ''}`} />
      ))}
    </div>
  );
}

export default function CarSelectScreen() {
  const setScreen = useGameStore((s) => s.setScreen);
  const featured = CAR_MODELS[0];

  return (
    <div className="workshop-root">
      <div className="panel left">
        <div className="panel-inner">
          <h3 className="panel-heading">자동차 선택</h3>
          <div className="car-card" onClick={() => setScreen('modelSelect')}>
            <div className="car-card-thumb" style={{ padding: 0, overflow: 'hidden' }}>
              <CarPreview3D model={featured} size={160} />
            </div>
            <p className="car-card-name">{featured.name}</p>
            <p className="car-card-manufacturer">{featured.manufacturer}</p>
            <div className="rating-row">
              <span>난이도</span>
              <Stars count={featured.difficulty} />
            </div>
            <div className="rating-row">
              <span>제작 시간</span>
              <Stars count={featured.estimatedHours} />
            </div>
          </div>
          <div className="empty-slot">+ 더 많은 물품 (추가 예정)</div>
          <div className="empty-slot" style={{ height: 100 }} />
        </div>
      </div>

      <div className="viewport-wrap">
        <Canvas camera={{ position: [6, 4, 8], fov: 45 }} dpr={[1, 1.5]}>
          <Suspense fallback={null}>
            <color attach="background" args={['#f4f4f5']} />
            <ambientLight intensity={0.7} />
            <directionalLight position={[5, 8, 5]} intensity={1.2} castShadow />
            <Grid
              args={[60, 60]}
              cellColor="#e4e4e7"
              sectionColor="#d4d4d8"
              fadeDistance={30}
              infiniteGrid
              cellSize={0.5}
              sectionSize={2.5}
            />
            <Environment preset="city" />
          </Suspense>
        </Canvas>
        <div className="top-bar">
          <div className="breadcrumb">MAKE EVERYTHING / 자동차 선택</div>
          <button className="btn ghost" onClick={() => setScreen('menu')}>메인으로</button>
        </div>
        <div className="hud-hint">왼쪽 패널에서 제작할 자동차를 선택하세요</div>
      </div>
    </div>
  );
}
