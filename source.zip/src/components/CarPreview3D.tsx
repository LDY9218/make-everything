import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { ContactShadows } from '@react-three/drei';
import * as THREE from 'three';
import CarBodyMesh from '../scenes/CarBodyMesh';
import type { CarModel } from '../types';

/**
 * A small auto-rotating 3D preview of a car. Used in the model picker cards
 * and in the "현재 선택된 차" card so the player sees the thing they're
 * about to build, not a flat SVG silhouette.
 *
 * The canvas is intentionally tiny and uses a single light so dropping it
 * into every card in a grid doesn't burn frame rate.
 */
function Spinner({ model }: { model: CarModel }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (ref.current) ref.current.rotation.y = state.clock.elapsedTime * 0.45;
  });
  return (
    <group ref={ref} position={[0, 0, 0]}>
      <CarBodyMesh model={model} />
    </group>
  );
}

export default function CarPreview3D({ model, size = 180 }: { model: CarModel; size?: number }) {
  // pointerEvents:none so clicks fall through to the surrounding card
  // (R3F Canvas eats clicks by default). Low DPR + no shadows + no HDRi
  // Environment so 10 of these on one grid don't melt a low-end laptop.
  return (
    <div className="car-preview-3d" style={{ width: '100%', height: size, pointerEvents: 'none' }}>
      <Canvas
        dpr={1}
        shadows={false}
        frameloop="always"
        camera={{ position: [3.2, 1.9, 4.4], fov: 32, near: 0.1, far: 50 }}
        gl={{ antialias: false, toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.05, powerPreference: 'low-power' }}
        style={{ pointerEvents: 'none' }}
      >
        <Suspense fallback={null}>
          <color attach="background" args={['#1a1d24']} />
          <ambientLight intensity={0.65} />
          <directionalLight position={[3, 4, 2.5]} intensity={1.8} />
          <directionalLight position={[-3, 2.5, -2]} intensity={0.7} color="#9fd0ff" />
          <Spinner model={model} />
          <ContactShadows position={[0, 0.001, 0]} opacity={0.35} scale={5} blur={2.2} far={2} resolution={128} />
        </Suspense>
      </Canvas>
    </div>
  );
}
// r6a
