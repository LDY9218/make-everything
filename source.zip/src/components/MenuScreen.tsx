import { useEffect, useState } from 'react';
import { useGameStore, hasSavedBuild } from '../store/useGameStore';

export default function MenuScreen() {
  const setScreen = useGameStore((s) => s.setScreen);
  const loadFromStorage = useGameStore((s) => s.loadFromStorage);
  const [hasSave, setHasSave] = useState(false);

  useEffect(() => {
    hasSavedBuild().then(setHasSave);
  }, []);

  const handleContinue = async () => {
    const ok = await loadFromStorage();
    setScreen(ok ? 'workshop' : 'carSelect');
  };

  return (
    <div className="menu-screen">
      <div className="flashy-bg">
        <div className="flashy-sweep" />
        {[[10, 18, 0], [88, 22, 0.8], [22, 80, 1.4], [75, 70, 2.0], [50, 50, 0.4]].map(([x, y, delay], i) => (
          <div key={i} className="flashy-sparkle" style={{ left: `${x}%`, top: `${y}%`, animationDelay: `${delay}s` }} />
        ))}
      </div>
      <div style={{ textAlign: 'center', position: 'relative', zIndex: 1 }}>
        <h1 className="menu-title flashy">MAKE EVERYTHING</h1>
        <div className="menu-subtitle">3D Car Manufacturing Simulator</div>
      </div>
      <div className="menu-buttons" style={{ position: 'relative', zIndex: 1 }}>
        {hasSave ? (
          <button className="ribbon-btn start" onClick={handleContinue}>이어서 제작하기</button>
        ) : (
          <button className="ribbon-btn start" onClick={() => setScreen('carSelect')}>START</button>
        )}
        <button className="ribbon-btn tutorial" onClick={() => setScreen('tutorial')}>TUTORIAL</button>
      </div>
      {hasSave && (
        <button
          onClick={() => setScreen('carSelect')}
          style={{ fontSize: 12, color: 'var(--color-text-soft)', marginTop: -20, fontWeight: 600 }}
        >
          새 자동차로 다시 시작
        </button>
      )}
    </div>
  );
}
