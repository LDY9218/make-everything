import { useGameStore } from '../store/useGameStore';

const ITEMS: { title: string; desc: string }[] = [
  { title: '카메라 조작', desc: '마우스 휠로 확대/축소, 우클릭 드래그로 회전, 빈 공간에서 좌클릭 드래그로 이동합니다.' },
  { title: '부품 선택과 이동', desc: '부품을 클릭하면 이동/회전 기즈모가 나타납니다. 기즈모를 드래그해 정밀하게 배치하세요.' },
  { title: 'T / R 키', desc: '물체를 선택한 상태에서 T는 상하 방향 회전, R은 좌우 방향 회전입니다.' },
  { title: 'ESC / Delete', desc: 'ESC는 선택 해제 또는 현재 작업 취소, Delete는 선택된 부품 삭제입니다.' },
  { title: 'Ctrl+Z / Ctrl+Y', desc: '부품 배치를 실행 취소하거나 다시 실행할 수 있습니다.' },
  { title: '제작 순서', desc: '오른쪽 패널의 제작 과정을 순서대로 진행하세요. 이전 단계를 완료해야 다음 단계가 열립니다.' },
  { title: '품질과 오류', desc: '가공과 조립 품질은 그대로 완성차에 반영됩니다. 실수는 자동으로 고쳐지지 않습니다.' },
  { title: '운전 모드', desc: '차량을 완성하면 직접 운전할 수 있습니다. V로 시점 전환, WASD로 조작, Space로 제동합니다.' },
];

export default function TutorialScreen() {
  const setScreen = useGameStore((s) => s.setScreen);
  return (
    <div className="select-screen">
      <button className="back-btn" onClick={() => setScreen('menu')}>← 메인으로</button>
      <div className="select-header">
        <h1 className="select-title">TUTORIAL</h1>
        <p className="select-sub">조작법과 제작 흐름을 먼저 익혀보세요.</p>
      </div>
      <div className="model-grid">
        {ITEMS.map((item) => (
          <div key={item.title} className="model-card" style={{ cursor: 'default' }}>
            <div className="model-body-type">GUIDE</div>
            <h3 className="car-card-name" style={{ fontSize: 17 }}>{item.title}</h3>
            <p className="option-row-desc" style={{ marginTop: 8 }}>{item.desc}</p>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 36 }}>
        <button className="btn primary" onClick={() => setScreen('carSelect')}>제작 시작하기</button>
      </div>
    </div>
  );
}
