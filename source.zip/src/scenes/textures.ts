import * as THREE from 'three';

// ─────────────────────────────────────────────────────────────────────────
// Procedural canvas textures (no image assets, no network). Every texture is
// generated once and cached; each has a colour map and, where it matters, a
// bump map so walls, floors and benches catch the light like real surfaces.
// ─────────────────────────────────────────────────────────────────────────

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function canvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  return [c, ctx];
}

function toTexture(c: HTMLCanvasElement, repeatX = 1, repeatY = 1, srgb = true): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 8;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function speckle(ctx: CanvasRenderingContext2D, w: number, h: number, colors: string[], n: number, seed: number, maxSize = 2) {
  const r = rng(seed);
  for (let i = 0; i < n; i++) {
    ctx.fillStyle = colors[Math.floor(r() * colors.length)];
    ctx.globalAlpha = 0.1 + r() * 0.35;
    const s = 1 + Math.floor(r() * maxSize);
    ctx.fillRect(Math.floor(r() * w), Math.floor(r() * h), s, s);
  }
  ctx.globalAlpha = 1;
}

export interface TexSet { map: THREE.CanvasTexture; bump: THREE.CanvasTexture }
const cache: Record<string, TexSet> = {};

function make(key: string, build: () => { color: HTMLCanvasElement; bump: HTMLCanvasElement }, rx: number, ry: number): TexSet {
  const k = `${key}:${rx}:${ry}`;
  if (cache[k]) return cache[k];
  const { color, bump } = build();
  const set = { map: toTexture(color, rx, ry), bump: toTexture(bump, rx, ry, false) };
  cache[k] = set;
  return set;
}

export function brickTexture(rx = 4, ry = 2): TexSet {
  return make('brick', () => {
    const [c, ctx] = canvas(512, 512);
    const [b, bctx] = canvas(512, 512);
    ctx.fillStyle = '#4a2f27';
    ctx.fillRect(0, 0, 512, 512);
    bctx.fillStyle = '#000';
    bctx.fillRect(0, 0, 512, 512);
    const r = rng(11);
    const rows = 8;
    const bw = 128;
    const bh = 512 / rows;
    for (let y = 0; y < rows; y++) {
      const off = y % 2 ? bw / 2 : 0;
      for (let x = -1; x < 5; x++) {
        const px = x * bw + off;
        const shade = 70 + Math.floor(r() * 50);
        ctx.fillStyle = `rgb(${shade + 70}, ${shade * 0.55 + 20}, ${shade * 0.4 + 14})`;
        ctx.fillRect(px + 3, y * bh + 3, bw - 6, bh - 6);
        bctx.fillStyle = '#bbb';
        bctx.fillRect(px + 3, y * bh + 3, bw - 6, bh - 6);
      }
    }
    speckle(ctx, 512, 512, ['#2a1a14', '#8a5a44', '#6a3a2a', '#a06a50'], 9000, 12);
    speckle(bctx, 512, 512, ['#666', '#fff', '#999'], 6000, 13);
    return { color: c, bump: b };
  }, rx, ry);
}

export function stoneTileTexture(rx = 6, ry = 6): TexSet {
  return make('stone', () => {
    const [c, ctx] = canvas(512, 512);
    const [b, bctx] = canvas(512, 512);
    const r = rng(21);
    bctx.fillStyle = '#000';
    bctx.fillRect(0, 0, 512, 512);
    const n = 4;
    const s = 512 / n;
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        const g = 92 + Math.floor(r() * 36);
        ctx.fillStyle = `rgb(${g}, ${g}, ${g + 4})`;
        ctx.fillRect(x * s, y * s, s, s);
        bctx.fillStyle = '#c8c8c8';
        bctx.fillRect(x * s + 4, y * s + 4, s - 8, s - 8);
      }
    }
    speckle(ctx, 512, 512, ['#222', '#bbb', '#777', '#555'], 12000, 22, 3);
    speckle(bctx, 512, 512, ['#555', '#fff'], 8000, 23, 3);
    return { color: c, bump: b };
  }, rx, ry);
}

export function concreteTexture(rx = 8, ry = 8): TexSet {
  return make('concrete', () => {
    const [c, ctx] = canvas(512, 512);
    const [b, bctx] = canvas(512, 512);
    ctx.fillStyle = '#9a9da3';
    ctx.fillRect(0, 0, 512, 512);
    bctx.fillStyle = '#808080';
    bctx.fillRect(0, 0, 512, 512);
    speckle(ctx, 512, 512, ['#7a7d83', '#b4b7bc', '#6a6d72', '#a8abb0'], 26000, 31, 3);
    speckle(bctx, 512, 512, ['#555', '#aaa', '#fff', '#222'], 18000, 32, 3);
    // expansion joints
    ctx.strokeStyle = '#5d6065';
    ctx.lineWidth = 3;
    ctx.strokeRect(0, 0, 512, 512);
    bctx.strokeStyle = '#000';
    bctx.lineWidth = 4;
    bctx.strokeRect(0, 0, 512, 512);
    return { color: c, bump: b };
  }, rx, ry);
}

export function woodTexture(rx = 2, ry = 1): TexSet {
  return make('wood', () => {
    const [c, ctx] = canvas(512, 256);
    const [b, bctx] = canvas(512, 256);
    ctx.fillStyle = '#8b6a43';
    ctx.fillRect(0, 0, 512, 256);
    bctx.fillStyle = '#808080';
    bctx.fillRect(0, 0, 512, 256);
    const r = rng(41);
    const planks = 4;
    const ph = 256 / planks;
    for (let p = 0; p < planks; p++) {
      const base = 110 + Math.floor(r() * 40);
      ctx.fillStyle = `rgb(${base + 40}, ${base}, ${base * 0.55})`;
      ctx.fillRect(0, p * ph, 512, ph - 2);
      for (let i = 0; i < 60; i++) {
        const y = p * ph + r() * ph;
        ctx.strokeStyle = `rgba(60, 35, 15, ${0.1 + r() * 0.25})`;
        ctx.lineWidth = 0.6 + r() * 1.4;
        ctx.beginPath();
        ctx.moveTo(0, y);
        for (let x = 0; x <= 512; x += 64) ctx.lineTo(x, y + (r() - 0.5) * 3);
        ctx.stroke();
        bctx.strokeStyle = `rgba(0,0,0,${0.2 + r() * 0.3})`;
        bctx.beginPath();
        bctx.moveTo(0, y);
        bctx.lineTo(512, y + (r() - 0.5) * 2);
        bctx.stroke();
      }
      ctx.fillStyle = '#2b1a0c';
      ctx.fillRect(0, p * ph + ph - 2, 512, 2);
    }
    return { color: c, bump: b };
  }, rx, ry);
}

export function sandTexture(rx = 1, ry = 1): TexSet {
  return make('sand', () => {
    const [c, ctx] = canvas(512, 512);
    const [b, bctx] = canvas(512, 512);
    ctx.fillStyle = '#b79a6e';
    ctx.fillRect(0, 0, 512, 512);
    bctx.fillStyle = '#808080';
    bctx.fillRect(0, 0, 512, 512);
    speckle(ctx, 512, 512, ['#8d7550', '#d2b98a', '#a38660', '#c9ad7d', '#6f5b3f'], 60000, 51, 2);
    speckle(bctx, 512, 512, ['#444', '#ddd', '#999', '#fff'], 50000, 52, 2);
    return { color: c, bump: b };
  }, rx, ry);
}

export function metalPlateTexture(rx = 2, ry = 2): TexSet {
  return make('plate', () => {
    const [c, ctx] = canvas(512, 512);
    const [b, bctx] = canvas(512, 512);
    ctx.fillStyle = '#6a6e75';
    ctx.fillRect(0, 0, 512, 512);
    bctx.fillStyle = '#808080';
    bctx.fillRect(0, 0, 512, 512);
    const r = rng(61);
    for (let i = 0; i < 700; i++) {
      const y = r() * 512;
      ctx.strokeStyle = r() > 0.5 ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.09)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(512, y);
      ctx.stroke();
    }
    // diamond-plate studs
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        const cx = x * 64 + (y % 2 ? 32 : 0) + 16;
        const cy = y * 64 + 24;
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.beginPath(); ctx.ellipse(cx, cy, 14, 5, Math.PI / 4, 0, Math.PI * 2); ctx.fill();
        bctx.fillStyle = '#fff';
        bctx.beginPath(); bctx.ellipse(cx, cy, 14, 5, Math.PI / 4, 0, Math.PI * 2); bctx.fill();
      }
    }
    return { color: c, bump: b };
  }, rx, ry);
}

/** soft round sprite used by all particle systems */
let spriteTex: THREE.CanvasTexture | null = null;
export function softSprite(): THREE.CanvasTexture {
  if (spriteTex) return spriteTex;
  const [c, ctx] = canvas(64, 64);
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.35, 'rgba(255,255,255,0.55)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 64);
  spriteTex = new THREE.CanvasTexture(c);
  spriteTex.colorSpace = THREE.SRGBColorSpace;
  return spriteTex;
}
