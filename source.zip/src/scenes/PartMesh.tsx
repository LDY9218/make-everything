import { resolveShape, type ShapeKey } from './partShapes';

// Every manufactured part renders as a shape that actually matches what it
// is (resolved from its label — see partShapes.ts), not a generic block.

function Shape({ shapeKey, color, selected, errorState }: { shapeKey: ShapeKey; color: string; selected?: boolean; errorState?: boolean }) {
  const mat = { color: errorState ? '#c0392b' : selected ? '#f5c518' : color, emissive: errorState ? '#c0392b' : selected ? '#f5c518' : '#000000', emissiveIntensity: selected || errorState ? 0.3 : 0 };

  switch (shapeKey) {
    case 'panel':
      return (
        <mesh castShadow rotation={[0.08, 0, 0.03]}>
          <boxGeometry args={[0.85, 0.03, 0.55]} />
          <meshStandardMaterial {...mat} metalness={0.6} roughness={0.3} />
        </mesh>
      );
    case 'slab':
      return (
        <mesh castShadow>
          <boxGeometry args={[1.1, 0.07, 0.75]} />
          <meshStandardMaterial {...mat} metalness={0.5} roughness={0.5} />
        </mesh>
      );
    case 'block':
      return (
        <group>
          <mesh castShadow><boxGeometry args={[0.85, 0.55, 0.65]} /><meshStandardMaterial {...mat} metalness={0.4} roughness={0.6} /></mesh>
          {[-0.3, 0, 0.3].map((x) => (
            <mesh key={x} position={[x, 0.3, 0]} castShadow><cylinderGeometry args={[0.1, 0.1, 0.08, 10]} /><meshStandardMaterial {...mat} metalness={0.4} roughness={0.6} /></mesh>
          ))}
        </group>
      );
    case 'piston':
      return (
        <group rotation={[Math.PI / 2, 0, 0]}>
          <mesh castShadow><cylinderGeometry args={[0.12, 0.12, 0.2, 24]} /><meshStandardMaterial {...mat} metalness={0.85} roughness={0.22} /></mesh>
          {[0.06, 0.02, -0.02].map((y) => (
            <mesh key={y} position={[0, y, 0]}><torusGeometry args={[0.121, 0.006, 6, 24]} /><meshStandardMaterial color="#555" metalness={1} roughness={0.3} /></mesh>
          ))}
          <mesh position={[0, 0.101, 0]} rotation={[Math.PI / 2, 0, 0]}><circleGeometry args={[0.11, 24]} /><meshStandardMaterial color="#b9bcc2" metalness={1} roughness={0.2} /></mesh>
          <mesh position={[0, -0.04, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.028, 0.028, 0.26, 12]} /><meshStandardMaterial color="#8d9096" metalness={1} roughness={0.25} /></mesh>
        </group>
      );
    case 'shaft':
      return (
        <group rotation={[0, 0, Math.PI / 2]}>
          <mesh castShadow><cylinderGeometry args={[0.045, 0.045, 0.8, 16]} /><meshStandardMaterial {...mat} metalness={0.9} roughness={0.2} /></mesh>
          {[-0.28, -0.1, 0.1, 0.28].map((y, i) => (
            <mesh key={y} position={[i % 2 ? 0.05 : -0.05, y, 0]} castShadow><cylinderGeometry args={[0.09, 0.09, 0.05, 18]} /><meshStandardMaterial {...mat} metalness={0.9} roughness={0.25} /></mesh>
          ))}
        </group>
      );
    case 'turbo':
      return (
        <group>
          <mesh castShadow><sphereGeometry args={[0.2, 14, 14]} /><meshStandardMaterial {...mat} metalness={0.6} roughness={0.4} /></mesh>
          <mesh position={[0.22, 0, 0]} rotation={[0, 0, Math.PI / 2]} castShadow><coneGeometry args={[0.12, 0.2, 12]} /><meshStandardMaterial {...mat} metalness={0.6} roughness={0.4} /></mesh>
        </group>
      );
    case 'circuitBoard':
      return (
        <group>
          <mesh castShadow><boxGeometry args={[0.45, 0.025, 0.32]} /><meshStandardMaterial {...mat} metalness={0.1} roughness={0.7} /></mesh>
          {[[-0.1, 0.08], [0.08, -0.05], [0.0, 0.0]].map(([x, z], i) => (
            <mesh key={i} position={[x, 0.025, z]} castShadow><boxGeometry args={[0.06, 0.02, 0.06]} /><meshStandardMaterial color="#0a0a0a" /></mesh>
          ))}
        </group>
      );
    case 'chip':
      return (<mesh castShadow><boxGeometry args={[0.08, 0.02, 0.08]} /><meshStandardMaterial {...mat} /></mesh>);
    case 'airbag':
      return (<mesh castShadow><boxGeometry args={[0.35, 0.18, 0.3]} /><meshStandardMaterial {...mat} metalness={0} roughness={0.9} /></mesh>);
    case 'screw':
      return (
        <group rotation={[Math.PI / 2, 0, 0]}>
          <mesh position={[0, 0.06, 0]} castShadow><cylinderGeometry args={[0.04, 0.04, 0.025, 6]} /><meshStandardMaterial {...mat} metalness={0.9} roughness={0.22} /></mesh>
          <mesh position={[0, -0.01, 0]} castShadow><cylinderGeometry args={[0.014, 0.014, 0.12, 10]} /><meshStandardMaterial {...mat} metalness={0.9} roughness={0.25} /></mesh>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <mesh key={i} position={[0, -0.05 + i * 0.016, 0]}><torusGeometry args={[0.016, 0.004, 5, 10]} /><meshStandardMaterial {...mat} metalness={0.9} roughness={0.3} /></mesh>
          ))}
        </group>
      );
    case 'wire':
      return (
        <group>
          <mesh rotation={[0, 0, Math.PI / 2]} castShadow><cylinderGeometry args={[0.014, 0.014, 0.55, 8]} /><meshStandardMaterial {...mat} roughness={0.5} /></mesh>
          {[-0.285, 0.285].map((x) => (
            <mesh key={x} position={[x, 0, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.02, 0.02, 0.04, 8]} /><meshStandardMaterial color="#c58a3a" metalness={0.9} roughness={0.25} /></mesh>
          ))}
        </group>
      );
    case 'tire':
      return (<mesh rotation={[Math.PI / 2, 0, 0]} castShadow><torusGeometry args={[0.3, 0.1, 10, 20]} /><meshStandardMaterial {...mat} roughness={0.9} /></mesh>);
    case 'wheel':
      return (
        <group rotation={[Math.PI / 2, 0, 0]}>
          <mesh castShadow><cylinderGeometry args={[0.32, 0.32, 0.22, 20]} /><meshStandardMaterial {...mat} metalness={0.6} roughness={0.3} /></mesh>
          <mesh castShadow><cylinderGeometry args={[0.14, 0.14, 0.24, 6]} /><meshStandardMaterial color="#c6c6cc" metalness={0.8} roughness={0.2} /></mesh>
        </group>
      );
    case 'disc':
      return (<mesh rotation={[Math.PI / 2, 0, 0]} castShadow><cylinderGeometry args={[0.25, 0.25, 0.025, 24]} /><meshStandardMaterial {...mat} metalness={0.8} roughness={0.3} /></mesh>);
    case 'caliper':
      return (<mesh castShadow><boxGeometry args={[0.16, 0.14, 0.1]} /><meshStandardMaterial {...mat} metalness={0.3} roughness={0.5} /></mesh>);
    case 'coil':
      return (
        <group>
          {[0, 1, 2, 3, 4].map((i) => (
            <mesh key={i} position={[0, i * 0.09, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow><torusGeometry args={[0.08, 0.015, 6, 12]} /><meshStandardMaterial {...mat} metalness={0.7} roughness={0.3} /></mesh>
          ))}
        </group>
      );
    case 'beam':
      return (<mesh castShadow><boxGeometry args={[0.9, 0.08, 0.1]} /><meshStandardMaterial {...mat} metalness={0.5} roughness={0.5} /></mesh>);
    case 'seatFrame':
      return (<mesh castShadow><boxGeometry args={[0.5, 0.55, 0.45]} /><meshStandardMaterial {...mat} wireframe metalness={0.3} roughness={0.6} /></mesh>);
    case 'cushion':
      return (<mesh castShadow><boxGeometry args={[0.46, 0.5, 0.42]} /><meshStandardMaterial {...mat} roughness={0.9} /></mesh>);
    case 'cover':
      return (<mesh castShadow><boxGeometry args={[0.5, 0.55, 0.46]} /><meshStandardMaterial {...mat} roughness={0.6} /></mesh>);
    case 'steeringWheel':
      return (<mesh rotation={[Math.PI / 2, 0, 0]} castShadow><torusGeometry args={[0.16, 0.025, 10, 20]} /><meshStandardMaterial {...mat} roughness={0.6} /></mesh>);
    case 'strap':
      return (<mesh rotation={[0, 0, 0.5]} castShadow><boxGeometry args={[0.06, 0.6, 0.01]} /><meshStandardMaterial {...mat} roughness={0.8} /></mesh>);
    case 'speaker':
      return (<mesh rotation={[Math.PI / 2, 0, 0]} castShadow><cylinderGeometry args={[0.16, 0.16, 0.08, 20]} /><meshStandardMaterial {...mat} metalness={0.3} roughness={0.6} /></mesh>);
    case 'ampBox':
      return (<mesh castShadow><boxGeometry args={[0.3, 0.12, 0.22]} /><meshStandardMaterial {...mat} metalness={0.4} roughness={0.5} /></mesh>);
    case 'screen':
      return (<mesh castShadow><boxGeometry args={[0.32, 0.2, 0.025]} /><meshStandardMaterial {...mat} emissive="#1f6feb" emissiveIntensity={0.15} metalness={0.2} roughness={0.4} /></mesh>);
    case 'tube':
      return (<mesh rotation={[0, 0, Math.PI / 2]} castShadow><cylinderGeometry args={[0.02, 0.02, 0.5, 8]} /><meshStandardMaterial {...mat} roughness={0.7} /></mesh>);
    case 'hydraulicUnit':
      return (<mesh castShadow><boxGeometry args={[0.3, 0.25, 0.25]} /><meshStandardMaterial {...mat} metalness={0.5} roughness={0.4} /></mesh>);
    case 'gearbox':
      return (
        <group>
          <mesh castShadow><cylinderGeometry args={[0.2, 0.2, 0.12, 28]} /><meshStandardMaterial {...mat} metalness={0.85} roughness={0.28} /></mesh>
          {Array.from({ length: 16 }).map((_, i) => {
            const a = (i / 16) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.215, 0, Math.sin(a) * 0.215]} rotation={[0, -a, 0]} castShadow>
                <boxGeometry args={[0.05, 0.12, 0.045]} /><meshStandardMaterial {...mat} metalness={0.85} roughness={0.28} />
              </mesh>
            );
          })}
          <mesh><cylinderGeometry args={[0.06, 0.06, 0.14, 12]} /><meshStandardMaterial color="#222" metalness={0.8} roughness={0.4} /></mesh>
        </group>
      );
    case 'ingot':
      return (<mesh castShadow><boxGeometry args={[0.3, 0.18, 0.15]} /><meshStandardMaterial {...mat} metalness={0.5} roughness={0.5} /></mesh>);
    case 'can':
      return (<mesh rotation={[Math.PI / 2, 0, 0]} castShadow><cylinderGeometry args={[0.09, 0.09, 0.18, 14]} /><meshStandardMaterial {...mat} metalness={0.3} roughness={0.4} /></mesh>);
    case 'module':
      return (<mesh castShadow><boxGeometry args={[0.16, 0.1, 0.12]} /><meshStandardMaterial {...mat} metalness={0.3} roughness={0.5} /></mesh>);
    default:
      return (<mesh castShadow><boxGeometry args={[0.3, 0.3, 0.3]} /><meshStandardMaterial {...mat} metalness={0.3} roughness={0.6} /></mesh>);
  }
}

export default function PartMesh({ label, defId, selected, errorState }: { label?: string; defId: string; selected?: boolean; errorState?: boolean }) {
  const { key, color } = resolveShape(label ?? defId);
  return <Shape shapeKey={key} color={color} selected={selected} errorState={errorState} />;
}
