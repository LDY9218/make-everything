import { useEffect, useMemo, useRef, type MutableRefObject } from 'react';
import { useFrame } from '@react-three/fiber';
import { RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import type { CarLayout, DriveVisual } from './carLayout';

// ─────────────────────────────────────────────────────────────────────────
// The cabin you actually sit in: dashboard with a live gauge cluster
// (canvas texture), a steering wheel that turns with the front wheels,
// seats, centre console, pedals, door cards, headliner and rear-view mirror.
// Everything is positioned from the same CarLayout as the body shell.
// ─────────────────────────────────────────────────────────────────────────

const LEATHER = '#2a2522';
const DASH = '#17181b';
const STITCH = '#c9b27a';

function drawCluster(ctx: CanvasRenderingContext2D, w: number, h: number, dv: DriveVisual) {
  ctx.fillStyle = '#05070a';
  ctx.fillRect(0, 0, w, h);
  const dial = (cx: number, cy: number, r: number, max: number, major: number, minor: number, value: number, label: (v: number) => string, redFrom?: number) => {
    const a0 = (135 * Math.PI) / 180;
    const sweep = (270 * Math.PI) / 180;
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#1d2630';
    ctx.beginPath(); ctx.arc(cx, cy, r, a0, a0 + sweep); ctx.stroke();
    if (redFrom !== undefined) {
      ctx.strokeStyle = '#d9342b';
      ctx.lineWidth = 5;
      ctx.beginPath(); ctx.arc(cx, cy, r - 2, a0 + (redFrom / max) * sweep, a0 + sweep); ctx.stroke();
    }
    for (let v = 0; v <= max + 0.001; v += minor) {
      const a = a0 + (v / max) * sweep;
      const isMajor = Math.abs(v / major - Math.round(v / major)) < 0.001;
      const r1 = r - (isMajor ? 16 : 8);
      ctx.strokeStyle = isMajor ? '#e8eef5' : '#6c7886';
      ctx.lineWidth = isMajor ? 2.5 : 1.2;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
      ctx.lineTo(cx + Math.cos(a) * (r - 3), cy + Math.sin(a) * (r - 3));
      ctx.stroke();
      if (isMajor) {
        ctx.fillStyle = '#d9e2ec';
        ctx.font = 'bold 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(label(v), cx + Math.cos(a) * (r - 30), cy + Math.sin(a) * (r - 30));
      }
    }
    const av = a0 + (Math.min(value, max) / max) * sweep;
    ctx.strokeStyle = '#ff5a36';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(cx - Math.cos(av) * 12, cy - Math.sin(av) * 12);
    ctx.lineTo(cx + Math.cos(av) * (r - 14), cy + Math.sin(av) * (r - 14));
    ctx.stroke();
    ctx.fillStyle = '#10151b';
    ctx.beginPath(); ctx.arc(cx, cy, 9, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#aab5c2'; ctx.lineWidth = 2; ctx.stroke();
  };
  dial(w * 0.22, h * 0.55, h * 0.46, 340, 40, 20, dv.speedKmh, (v) => String(Math.round(v)));
  dial(w * 0.78, h * 0.55, h * 0.46, 9, 1, 0.5, dv.rpm / 1000, (v) => String(Math.round(v)), 7.2);

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#f2f6fa';
  ctx.font = 'bold 54px sans-serif';
  ctx.fillText(String(Math.round(dv.speedKmh)), w * 0.5, h * 0.42);
  ctx.fillStyle = '#7f8c9a';
  ctx.font = '15px sans-serif';
  ctx.fillText('km/h', w * 0.5, h * 0.6);
  ctx.fillStyle = '#ffcf4a';
  ctx.font = 'bold 34px sans-serif';
  ctx.fillText(dv.gear < 0 ? 'R' : dv.gear === 0 ? 'N' : `D${dv.gear}`, w * 0.5, h * 0.8);

  if (dv.indicator === 1) { ctx.fillStyle = Math.floor(performance.now() / 350) % 2 ? '#2fe36b' : '#0b3a1c'; ctx.font = 'bold 30px sans-serif'; ctx.fillText('◀', w * 0.4, h * 0.14); }
  if (dv.indicator === -1) { ctx.fillStyle = Math.floor(performance.now() / 350) % 2 ? '#2fe36b' : '#0b3a1c'; ctx.font = 'bold 30px sans-serif'; ctx.fillText('▶', w * 0.6, h * 0.14); }
  if (dv.headlights) { ctx.fillStyle = '#3aa0ff'; ctx.font = 'bold 22px sans-serif'; ctx.fillText('≡D', w * 0.5, h * 0.12); }
  if (dv.braking) { ctx.fillStyle = '#ff3b30'; ctx.font = 'bold 18px sans-serif'; ctx.fillText('(!)', w * 0.34, h * 0.9); }
}

function drawNav(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.fillStyle = '#0d1b2a';
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = '#1f4e79';
  ctx.lineWidth = 2;
  for (let i = 0; i < 9; i++) {
    ctx.beginPath(); ctx.moveTo(i * w / 8, 0); ctx.lineTo(i * w / 8 + (i % 2 ? 22 : -22), h); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i * h / 8); ctx.lineTo(w, i * h / 8 + (i % 3 ? 14 : -10)); ctx.stroke();
  }
  ctx.strokeStyle = '#4da3ff'; ctx.lineWidth = 6;
  ctx.beginPath(); ctx.moveTo(w * 0.15, h * 0.9); ctx.quadraticCurveTo(w * 0.4, h * 0.5, w * 0.8, h * 0.2); ctx.stroke();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.moveTo(w * 0.4, h * 0.52); ctx.lineTo(w * 0.45, h * 0.66); ctx.lineTo(w * 0.4, h * 0.62); ctx.lineTo(w * 0.35, h * 0.66); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#9fb3c8'; ctx.font = 'bold 16px sans-serif'; ctx.textAlign = 'left';
  ctx.fillText('MAKE EVERYTHING NAV', 10, 20);
}

function Seat({ x, z, sport, rear, color }: { x: number; z: number; sport: boolean; rear?: boolean; color: string }) {
  const y0 = 0.1;
  return (
    <group position={[x, 0, z]}>
      <RoundedBox args={[0.5, 0.13, 0.52]} radius={0.05} position={[0, y0 + 0.22, 0]} castShadow receiveShadow>
        <meshStandardMaterial color={color} roughness={0.62} />
      </RoundedBox>
      <group position={[0, y0 + 0.5, -0.24]} rotation={[-0.2, 0, 0]}>
        <RoundedBox args={[0.5, 0.58, 0.13]} radius={0.05} castShadow>
          <meshStandardMaterial color={color} roughness={0.62} />
        </RoundedBox>
        {sport && [1, -1].map((s) => (
          <RoundedBox key={s} args={[0.09, 0.5, 0.17]} radius={0.04} position={[s * 0.26, -0.02, 0.03]}>
            <meshStandardMaterial color={color} roughness={0.55} />
          </RoundedBox>
        ))}
        {!rear && (
          <RoundedBox args={[0.22, 0.2, 0.1]} radius={0.04} position={[0, 0.4, 0.0]} castShadow>
            <meshStandardMaterial color={color} roughness={0.62} />
          </RoundedBox>
        )}
        <mesh position={[0, 0.02, 0.07]}>
          <boxGeometry args={[0.012, 0.5, 0.004]} />
          <meshStandardMaterial color={STITCH} roughness={0.8} />
        </mesh>
      </group>
      {!rear && [0.18, -0.18].map((rx) => (
        <mesh key={rx} position={[rx, y0 + 0.07, 0]}>
          <boxGeometry args={[0.03, 0.04, 0.5]} />
          <meshStandardMaterial color="#8b8f95" metalness={0.9} roughness={0.35} />
        </mesh>
      ))}
    </group>
  );
}

export default function CarInterior({ layout, driveRef }: { layout: CarLayout; driveRef?: MutableRefObject<DriveVisual> }) {
  const { W, H, gc, beltY, zc, zrf, dx, seatZ, rearSeatZ, doorT, zt, seats2, bodyType } = layout;
  const cabinW = W - doorT * 2;
  const sport = seats2 || bodyType === 'sportscar';
  const wheelRot = useRef<THREE.Group>(null);

  const cluster = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 512; canvas.height = 192;
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return { canvas, tex, last: 0 };
  }, []);
  const nav = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 384; canvas.height = 230;
    const ctx = canvas.getContext('2d');
    if (ctx) drawNav(ctx, canvas.width, canvas.height);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);
  useEffect(() => () => { cluster.tex.dispose(); nav.dispose(); }, [cluster, nav]);

  useFrame((state) => {
    const dv = driveRef?.current;
    if (wheelRot.current) wheelRot.current.rotation.z = THREE.MathUtils.clamp((dv?.steer ?? 0) * 8, -2.8, 2.8);
    const t = state.clock.elapsedTime;
    if (t - cluster.last > 0.05) {
      cluster.last = t;
      const ctx = cluster.canvas.getContext('2d');
      if (ctx) {
        drawCluster(ctx, cluster.canvas.width, cluster.canvas.height, dv ?? { speedKmh: 0, rpm: 850, gear: 0, steer: 0, wheelSpin: 0, braking: false, headlights: false, reversing: false, indicator: 0, throttle: 0 });
        cluster.tex.needsUpdate = true;
      }
    }
  });

  const dashZ = zc - 0.28;
  const wheelZ = zc - 0.66;
  const wheelY = beltY - 0.1;
  const consoleFrom = zc - 0.5;
  const consoleTo = seats2 ? seatZ - 0.35 : rearSeatZ + 0.25;
  const consoleLen = Math.max(0.4, consoleFrom - consoleTo);

  return (
    <group>
      {/* cabin light so the interior never goes pitch black */}
      <pointLight position={[0, H - 0.25, (zc + zt) / 2]} intensity={1.8} distance={3.2} color="#fff1dd" />

      {/* ── dashboard ── */}
      <RoundedBox args={[cabinW, 0.3, 0.56]} radius={0.05} position={[0, beltY - 0.19, dashZ]} castShadow receiveShadow>
        <meshStandardMaterial color={DASH} roughness={0.7} />
      </RoundedBox>
      {/* soft-touch top pad + stitched seam */}
      <mesh position={[0, beltY - 0.036, dashZ]}>
        <boxGeometry args={[cabinW - 0.04, 0.012, 0.52]} />
        <meshStandardMaterial color="#0f1012" roughness={0.9} />
      </mesh>
      <mesh position={[0, beltY - 0.028, dashZ - 0.2]}>
        <boxGeometry args={[cabinW - 0.08, 0.004, 0.006]} />
        <meshStandardMaterial color={STITCH} roughness={0.8} />
      </mesh>
      {/* instrument hood */}
      <RoundedBox args={[0.5, 0.11, 0.3]} radius={0.04} position={[dx, beltY + 0.015, zc - 0.38]} castShadow>
        <meshStandardMaterial color="#101113" roughness={0.6} />
      </RoundedBox>
      {/* gauge cluster */}
      <mesh position={[dx, beltY + 0.015, zc - 0.532]} rotation={[0, Math.PI, 0.0]}>
        <planeGeometry args={[0.34, 0.127]} />
        <meshBasicMaterial map={cluster.tex} toneMapped={false} />
      </mesh>
      {/* centre screen */}
      <group position={[0, beltY + 0.055, zc - 0.33]} rotation={[0.18, Math.PI, 0]}>
        <RoundedBox args={[0.34, 0.215, 0.025]} radius={0.01}>
          <meshStandardMaterial color="#050505" roughness={0.3} metalness={0.6} />
        </RoundedBox>
        <mesh position={[0, 0, 0.0135]} rotation={[0, Math.PI, 0]}>
          <planeGeometry args={[0.31, 0.19]} />
          <meshBasicMaterial map={nav} toneMapped={false} />
        </mesh>
      </group>
      {/* air vents */}
      {[-0.42, -0.28, 0.28, 0.42].map((f, i) => (
        <group key={i} position={[f * cabinW, beltY - 0.14, zc - 0.565]}>
          <mesh><boxGeometry args={[0.13, 0.05, 0.012]} /><meshStandardMaterial color="#0a0a0b" roughness={0.5} metalness={0.5} /></mesh>
          {[-0.015, 0, 0.015].map((vy) => (
            <mesh key={vy} position={[0, vy, 0.008]}><boxGeometry args={[0.11, 0.004, 0.004]} /><meshStandardMaterial color="#8a8d92" metalness={1} roughness={0.3} /></mesh>
          ))}
        </group>
      ))}
      {/* trim strip */}
      <mesh position={[0, beltY - 0.2, zc - 0.565]}>
        <boxGeometry args={[cabinW - 0.1, 0.012, 0.006]} />
        <meshStandardMaterial color="#b8bcc2" metalness={1} roughness={0.2} />
      </mesh>

      {/* ── steering wheel ── */}
      <group position={[dx, wheelY, wheelZ]} rotation={[0.38, Math.PI, 0]}>
        {/* column shroud */}
        <mesh position={[0, -0.02, -0.12]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.045, 0.06, 0.24, 20]} />
          <meshStandardMaterial color="#0e0f11" roughness={0.6} />
        </mesh>
        <group ref={wheelRot}>
          <mesh castShadow>
            <torusGeometry args={[0.175, 0.018, 18, 56]} />
            <meshStandardMaterial color="#141416" roughness={0.55} />
          </mesh>
          <mesh position={[0, 0, 0.004]}>
            <torusGeometry args={[0.175, 0.004, 6, 56]} />
            <meshStandardMaterial color={STITCH} roughness={0.8} />
          </mesh>
          {/* 12 o'clock marker so you can read the steering angle */}
          <mesh position={[0, 0.175, 0.01]}>
            <boxGeometry args={[0.012, 0.03, 0.006]} />
            <meshStandardMaterial color="#e6a817" emissive="#e6a817" emissiveIntensity={0.4} />
          </mesh>
          {[0, 2.1, -2.1].map((a, i) => (
            <group key={i} rotation={[0, 0, a + Math.PI / 2]}>
              <mesh position={[0.09, 0, 0]}>
                <boxGeometry args={[0.18, 0.032, 0.014]} />
                <meshStandardMaterial color="#1a1b1e" roughness={0.45} metalness={0.4} />
              </mesh>
            </group>
          ))}
          <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0, 0.012]}>
            <cylinderGeometry args={[0.058, 0.07, 0.04, 28]} />
            <meshStandardMaterial color="#17181b" roughness={0.45} metalness={0.5} />
          </mesh>
          <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0, 0.034]}>
            <cylinderGeometry args={[0.03, 0.03, 0.006, 20]} />
            <meshStandardMaterial color="#c9ccd1" roughness={0.2} metalness={1} />
          </mesh>
        </group>
      </group>

      {/* ── pedals ── */}
      {[-0.1, 0.0, 0.1].map((px, i) => (
        <mesh key={i} position={[dx + px + 0.02, gc + 0.16 - i * 0.0, zc - 0.62]} rotation={[0.5, 0, 0]}>
          <boxGeometry args={[i === 0 ? 0.1 : 0.06, 0.12, 0.016]} />
          <meshStandardMaterial color="#2b2d31" roughness={0.4} metalness={0.8} />
        </mesh>
      ))}

      {/* ── centre console ── */}
      <RoundedBox args={[0.26, 0.26, consoleLen]} radius={0.04} position={[0, gc + 0.2, consoleFrom - consoleLen / 2]} castShadow receiveShadow>
        <meshStandardMaterial color="#111214" roughness={0.65} />
      </RoundedBox>
      <mesh position={[0, gc + 0.34, consoleFrom - 0.18]}>
        <cylinderGeometry args={[0.012, 0.012, 0.15, 10]} />
        <meshStandardMaterial color="#aeb2b8" metalness={1} roughness={0.2} />
      </mesh>
      <mesh position={[0, gc + 0.43, consoleFrom - 0.18]}>
        <sphereGeometry args={[0.032, 18, 14]} />
        <meshStandardMaterial color="#141416" roughness={0.45} />
      </mesh>
      {[0.07, -0.07].map((cx) => (
        <mesh key={cx} position={[cx, gc + 0.335, consoleFrom - 0.42]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.032, 20]} />
          <meshStandardMaterial color="#050505" roughness={0.8} />
        </mesh>
      ))}

      {/* ── seats ── */}
      <Seat x={dx} z={seatZ} sport={sport} color={LEATHER} />
      <Seat x={-dx} z={seatZ} sport={sport} color={LEATHER} />
      {!seats2 && (
        <>
          <Seat x={dx} z={rearSeatZ} sport={false} rear color={LEATHER} />
          <Seat x={-dx} z={rearSeatZ} sport={false} rear color={LEATHER} />
          <Seat x={0} z={rearSeatZ} sport={false} rear color={LEATHER} />
        </>
      )}
      {/* rear bulkhead / parcel shelf */}
      <mesh position={[0, beltY * 0.62, zt + 0.02]}>
        <boxGeometry args={[cabinW, beltY * 0.7, 0.03]} />
        <meshStandardMaterial color="#17181a" roughness={0.9} />
      </mesh>

      {/* ── door cards ── */}
      {[1, -1].map((sd) => {
        const len = zc - zt - 0.1;
        return (
          <group key={sd} position={[sd * (W / 2 - doorT - 0.012), 0, (zc + zt) / 2]}>
            <mesh position={[0, (gc + beltY) / 2, 0]}>
              <boxGeometry args={[0.022, beltY - gc - 0.06, len]} />
              <meshStandardMaterial color="#1c1d20" roughness={0.8} />
            </mesh>
            <RoundedBox args={[0.1, 0.06, 0.55]} radius={0.025} position={[-sd * 0.045, beltY - 0.11, 0.1]}>
              <meshStandardMaterial color={LEATHER} roughness={0.6} />
            </RoundedBox>
            <mesh position={[-sd * 0.01, beltY - 0.065, 0.55]}>
              <boxGeometry args={[0.02, 0.03, 0.14]} />
              <meshStandardMaterial color="#0b0b0c" roughness={0.4} metalness={0.5} />
            </mesh>
            <mesh position={[-sd * 0.012, beltY - 0.2, 0.2]}>
              <boxGeometry args={[0.014, 0.02, 0.2]} />
              <meshStandardMaterial color="#b8bcc2" metalness={1} roughness={0.2} />
            </mesh>
          </group>
        );
      })}

      {/* ── rear-view mirror ── */}
      <group position={[0, H - 0.16, zrf - 0.07]}>
        <mesh position={[0, 0.08, 0]}>
          <boxGeometry args={[0.02, 0.1, 0.02]} />
          <meshStandardMaterial color="#111" />
        </mesh>
        <RoundedBox args={[0.26, 0.065, 0.03]} radius={0.015}>
          <meshStandardMaterial color="#0d0e10" roughness={0.5} />
        </RoundedBox>
        <mesh position={[0, 0, -0.017]} rotation={[0, Math.PI, 0]}>
          <planeGeometry args={[0.24, 0.05]} />
          <meshStandardMaterial color="#9fb4c4" metalness={1} roughness={0.08} />
        </mesh>
      </group>
    </group>
  );
}
