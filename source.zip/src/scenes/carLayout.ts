import type { CarModel } from '../types';

// ─────────────────────────────────────────────────────────────────────────
// One place that decides where everything on a car sits: body profile,
// axles, glass, driver's eye... CarBodyMesh, CarInterior and the drive
// scene all read the same numbers so the cabin you sit in is the cabin you
// built. Car-local axes: +z forward (hood), +x = driver's left, y up from
// the ground, origin on the ground in the middle of the car.
// ─────────────────────────────────────────────────────────────────────────

export interface CarLayout {
  L: number; W: number; H: number;
  bodyType: CarModel['bodyType'];
  wheelR: number; tireW: number; rimR: number;
  gc: number;       // ground clearance
  beltY: number;    // top of the doors / hood line
  zc: number;       // cowl: where the windshield starts
  zrf: number;      // roof front edge
  zrr: number;      // roof rear edge
  zt: number;       // rear glass base / deck start
  axleF: number; axleR: number;
  trackX: number;   // x of wheel centres
  doorT: number;    // door slab thickness
  dx: number;       // driver x (left-hand drive)
  seats2: boolean;  // true → two seats only
  seatZ: number;    // front seat hip point z
  rearSeatZ: number;
  eye: [number, number, number];
  twoDoor: boolean;
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export function getCarLayout(model: CarModel): CarLayout {
  const { length: L, width: W, height: H, hoodRatio, roofHeightRatio, rearSlope, wheelbaseRatio } = model.silhouette;
  const bodyType = model.bodyType;
  const wheelR = clamp(H * 0.26, 0.29, 0.4);
  const tireW = clamp(W * 0.12, 0.22, 0.31);
  const gc = clamp(H * 0.11, 0.1, 0.2);
  const beltY = H * (1 - roofHeightRatio * 0.6);
  const hGlass = H - beltY;
  const zc = L / 2 - L * hoodRatio;
  const runW = hGlass * (2.2 - roofHeightRatio * 2.0);
  let zrf = zc - runW;
  const zt = -L / 2 + L * (0.06 + 0.12 * (1 - rearSlope));
  const runR = hGlass * (0.35 + rearSlope * 2.6);
  let zrr = zt + runR;
  if (zrf - zrr < 0.35) {
    // squeeze the glass runs so a roof of at least 35cm always remains
    const k = (zc - zt - 0.35) / (runW + runR);
    zrf = zc - runW * k;
    zrr = zt + runR * k;
  }
  const wheelbase = L * wheelbaseRatio;
  const seats2 = bodyType === 'hypercar' || bodyType === 'sportscar';
  const dx = W * 0.19;
  const seatZ = zc - (seats2 ? 1.0 : 1.15);
  const rearSeatZ = Math.max(seatZ - 0.92, zt + 0.32);
  const eyeY = H * 0.84;
  return {
    L, W, H, bodyType, wheelR, tireW, rimR: wheelR * 0.68, gc, beltY, zc, zrf, zrr, zt,
    axleF: wheelbase / 2, axleR: -wheelbase / 2,
    trackX: W / 2 - tireW / 2 + 0.04,
    doorT: 0.2,
    dx, seats2, seatZ, rearSeatZ,
    eye: [dx, eyeY, seatZ + 0.12],
    twoDoor: seats2,
  };
}

/** live values the drive scene writes every frame and the car meshes read */
export interface DriveVisual {
  speedKmh: number;
  rpm: number;
  gear: number;        // -1 reverse, 0 neutral, 1..n
  steer: number;       // -1..1, positive = left
  wheelSpin: number;   // radians, accumulated
  braking: boolean;
  headlights: boolean;
  reversing: boolean;
  indicator: number;   // -1 right, 0 off, 1 left
  throttle: number;
}

export function makeDriveVisual(): DriveVisual {
  return { speedKmh: 0, rpm: 900, gear: 1, steer: 0, wheelSpin: 0, braking: false, headlights: false, reversing: false, indicator: 0, throttle: 0 };
}
