import { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree, type ThreeEvent } from '@react-three/fiber';
import { Grid, OrbitControls, TransformControls, Environment, Html, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';
import { useGameStore } from '../store/useGameStore';
import { getCarModel } from '../data/carModels';
import CarBodyMesh from './CarBodyMesh';
import PartMesh from './PartMesh';
import CraftRig from './CraftRig';
import PathRig from './PathRig';
import GuideArrow from './GuideArrow';
import { BenchRoom, FoundryRoom } from './rooms';
import { brickTexture, concreteTexture, metalPlateTexture } from './textures';
import { BENCH_ORIGIN, getAssemblyTarget, getRingScale } from '../manufacturing/targets';
import { EMPTY_PROGRESS, expandUnits, getRecipe, unitDisplayName } from '../manufacturing/recipes';
import { nextTaskOf, tryPlaceByPartId, type UnitsMap } from '../manufacturing/assemblyLogic';

type GizmoMode = 'translate' | 'rotate';

const DRAG_Y = 0.95;

// ── parts: grab with the pointer, carry, drop onto the blue ring ─────────
function SelectablePart({ id, gizmoMode }: { id: string; gizmoMode: GizmoMode }) {
  const part = useGameStore((s) => s.build?.parts[id]);
  const selectedPartId = useGameStore((s) => s.selectedPartId);
  const setSelectedPart = useGameStore((s) => s.setSelectedPart);
  const updatePartTransform = useGameStore((s) => s.updatePartTransform);
  const pushHistory = useGameStore((s) => s.pushHistory);
  const groupRef = useRef<THREE.Group>(null);
  const controlsRef = useRef<any>(null);
  const orbitControls = useThree((s) => s.controls) as any;
  const [drag, setDrag] = useState(false);
  const dragRef = useRef(false);
  const endRef = useRef<() => void>(() => undefined);

  endRef.current = () => {
    if (!dragRef.current) return;
    dragRef.current = false;
    setDrag(false);
    if (orbitControls) orbitControls.enabled = true;
    document.body.style.cursor = 'auto';
    const g = groupRef.current;
    if (!g || !part) return;
    pushHistory();
    updatePartTransform(id, [g.position.x, 0.3, g.position.z], [0, g.rotation.y, 0]);
    tryPlaceByPartId(id);
  };

  useEffect(() => {
    if (!drag) return undefined;
    const up = () => endRef.current();
    window.addEventListener('pointerup', up);
    return () => window.removeEventListener('pointerup', up);
  }, [drag]);

  if (!part) return null;
  const isSelected = selectedPartId === id;
  const movable = !part.assembled;

  const onDown = (e: ThreeEvent<PointerEvent>) => {
    if (!movable) return;
    e.stopPropagation();
    dragRef.current = true;
    setDrag(true);
    setSelectedPart(id);
    if (orbitControls) orbitControls.enabled = false;
    document.body.style.cursor = 'grabbing';
    if (groupRef.current) groupRef.current.position.y = DRAG_Y;
  };

  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    setSelectedPart(id);
  };

  const s = part.assembled ? 0.62 : 1;

  return (
    <>
      <group
        ref={groupRef}
        position={part.position}
        rotation={part.rotation}
        scale={[part.scale[0] * s, part.scale[1] * s, part.scale[2] * s]}
        onClick={onClick}
        onPointerDown={onDown}
        onPointerOver={() => { if (movable) document.body.style.cursor = 'grab'; }}
        onPointerOut={() => { if (!dragRef.current) document.body.style.cursor = 'auto'; }}
      >
        <PartMesh defId={part.defId} label={part.label} selected={isSelected} errorState={part.qualityScore < 55} />
      </group>
      {drag && (
        <mesh
          position={[0, DRAG_Y, 0]}
          rotation={[-Math.PI / 2, 0, 0]}
          visible={false}
          onPointerMove={(e: ThreeEvent<PointerEvent>) => {
            if (groupRef.current) groupRef.current.position.set(e.point.x, DRAG_Y, e.point.z);
          }}
          onPointerUp={() => endRef.current()}
        >
          <planeGeometry args={[200, 200]} />
        </mesh>
      )}
      {isSelected && !movable && groupRef.current && (
        <TransformControls
          ref={controlsRef}
          object={groupRef.current}
          mode={gizmoMode}
          onMouseDown={() => { if (orbitControls) orbitControls.enabled = false; }}
          onMouseUp={() => {
            if (orbitControls) orbitControls.enabled = true;
            if (groupRef.current) {
              pushHistory();
              const p = groupRef.current.position;
              const r = groupRef.current.rotation;
              updatePartTransform(id, [p.x, p.y, p.z], [r.x, r.y, r.z]);
            }
          }}
        />
      )}
    </>
  );
}

function TargetRing({
  position, label, color = '#4da3ff', scale = 1, showLabel = true,
}: { position: [number, number, number]; label: string; color?: string; scale?: number; showLabel?: boolean }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (ref.current) {
      const k = 1 + Math.sin(state.clock.elapsedTime * 3 + position[0] * 4) * 0.06;
      ref.current.scale.set(k, k, 1);
    }
  });
  return (
    <group position={position} scale={scale}>
      <mesh ref={ref} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.26, 0.34, 40]} />
        <meshBasicMaterial color={color} transparent opacity={0.9} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0, 0.3, 0]}>
        <cylinderGeometry args={[0.3, 0.3, 0.6, 28, 1, true]} />
        <meshBasicMaterial color={color} transparent opacity={0.12} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
      {showLabel && (
        <Html center position={[0, 0.7, 0]} distanceFactor={10} style={{ pointerEvents: 'none' }}>
          <div className="target-label">{label}</div>
        </Html>
      )}
    </group>
  );
}

function TargetMarkers() {
  const build = useGameStore((s) => s.build);
  const activeStepId = useGameStore((s) => s.activeStepId);
  const craftTarget = useGameStore((s) => s.craftTarget);
  const step = build?.steps.find((s) => s.id === activeStepId);
  const stepState = step ? build?.stepStates[step.id] : undefined;
  const units = useMemo(() => (step ? expandUnits(step.materials, step.title) : []), [step]);

  if (!build || !step || !stepState || stepState.status === 'completed' || step.interaction === 'inspection') return null;
  if (craftTarget) return null;
  const progMap = (stepState.data?.['units'] as UnitsMap | undefined) ?? {};
  const scale = getRingScale(units.length);

  const place: JSX.Element[] = [];
  const work: JSX.Element[] = [];
  units.forEach((u) => {
    const recipe = getRecipe(u.label);
    const prog = progMap[u.key] ?? EMPTY_PROGRESS;
    const nt = nextTaskOf(recipe, prog);
    const t = getAssemblyTarget(u.ordinal, u.total, step.order);
    if (nt.kind === 'place') {
      place.push(<TargetRing key={u.key} position={t} label={unitDisplayName(u)} scale={scale} showLabel={place.length < 10} />);
    } else if (work.length < 8 && (nt.kind === 'fasten' || (nt.kind === 'fab' && !recipe.makesPart))) {
      work.push(<TargetRing key={u.key} position={t} label={`${unitDisplayName(u)}`} color="#f5a623" scale={scale} showLabel={work.length < 4} />);
    }
  });
  return <>{place}{work}</>;
}

// ── the camera director ──────────────────────────────────────────────────
// Outside a session the player flies the camera freely (and station buttons
// can glide it somewhere). While a hand-work session runs the SYSTEM owns the
// camera: the rigs ask for shots (top view first, then the side if there is
// something to do there) and the director glides to them. Orbit is locked, and
// the player's own pose comes back when the session ends.
function CameraDirector() {
  const controls = useThree((s) => s.controls) as any;
  const camera = useThree((s) => s.camera);
  const clock = useThree((s) => s.clock);
  const focus = useGameStore((s) => s.focus);
  const shot = useGameStore((s) => s.shot);
  const session = useGameStore((s) => !!s.craftTarget);
  const saved = useRef<{ p: THREE.Vector3; t: THREE.Vector3 } | null>(null);
  const goal = useRef<{ p: THREE.Vector3; t: THREE.Vector3; settled: boolean } | null>(null);
  const focusGoal = useRef<{ t: THREE.Vector3; c: THREE.Vector3; until: number } | null>(null);

  useEffect(() => {
    if (!controls) return;
    if (session) {
      saved.current = { p: camera.position.clone(), t: controls.target.clone() };
      // keep controls enabled so the wheel still zooms during the session,
      // but rotate/pan are locked by SessionAwareOrbit above
    } else if (saved.current) {
      camera.position.copy(saved.current.p);
      controls.target.copy(saved.current.t);
      controls.update();
      saved.current = null;
      goal.current = null;
      useGameStore.setState({ shot: null });
    }
  }, [session, controls, camera]);

  useEffect(() => {
    if (!shot || !session) return;
    const g = { p: new THREE.Vector3(...shot.pos), t: new THREE.Vector3(...shot.look), settled: false };
    goal.current = g;
    if (shot.snap && controls) {
      camera.position.copy(g.p);
      controls.target.copy(g.t);
      controls.update();
      g.settled = true;
    }
  }, [shot, session, controls, camera]);

  useEffect(() => {
    if (!focus || session) return;
    const t = new THREE.Vector3(...focus.pos);
    const dir = new THREE.Vector3(0.18, 0.62, 0.76).normalize().multiplyScalar(focus.dist);
    focusGoal.current = { t, c: t.clone().add(dir), until: clock.elapsedTime + 1.8 };
  }, [focus, clock, session]);

  useFrame((state, dt) => {
    if (!controls) return;
    if (session) {
      const g = goal.current;
      // glide to the requested shot the first time, then hand the camera over
      // to OrbitControls (wheel-zoom only) so the player can get closer.
      if (g && !g.settled) {
        const k = 1 - Math.pow(0.0006, Math.min(dt, 0.05));
        camera.position.lerp(g.p, k);
        controls.target.lerp(g.t, k);
        if (camera.position.distanceTo(g.p) < 0.08) g.settled = true;
        controls.update();
      }
      return;
    }
    const f = focusGoal.current;
    if (!f) return;
    if (state.clock.elapsedTime > f.until) { focusGoal.current = null; return; }
    const k = 1 - Math.pow(0.002, dt);
    controls.target.lerp(f.t, k);
    camera.position.lerp(f.c, k);
    controls.update();
  });
  return null;
}

// ── Right-drag rotates; during hand work left-drag is reserved for tools.
function SessionAwareOrbit() {
  const session = useGameStore((s) => !!s.craftTarget);
  // outside a session: the player flies freely with LMB-pan and RMB-rotate.
  // inside a session: right-drag ROTATE, WHEEL ZOOM. PAN disabled so the
  // camera can't wander to another workbench during the task.
  return (
    <OrbitControls
      makeDefault
      mouseButtons={{
        LEFT: THREE.MOUSE.PAN,
        MIDDLE: THREE.MOUSE.DOLLY,
        RIGHT: THREE.MOUSE.ROTATE,
      }}
      enableRotate
      enablePan={!session}
      enableZoom
      zoomSpeed={0.9}
      minDistance={session ? 1.2 : 1.5}
      maxDistance={session ? 14 : 32}
      maxPolarAngle={Math.PI / 2 - 0.02}
      enableDamping
      dampingFactor={0.12}
    />
  );
}

// ── the active hand-work session (in its own room) ───────────────────────
function TaskRig() {
  const craftTarget = useGameStore((s) => s.craftTarget);
  if (!craftTarget) return null;
  const spec = craftTarget.spec;
  const finish = (q: number, e: string[], extra?: { carveQuality?: number }) => {
    craftTarget.onDone(q, e, extra);
  };
  if (spec.kind === 'cast') {
    return (
      <>
        <FoundryRoom />
        <CraftRig
          key={craftTarget.id}
          craftId={craftTarget.id}
          label={craftTarget.label}
          spec={spec}
          unitKey={craftTarget.unitKey ?? 'x'}
          mold={craftTarget.mold ?? null}
          onComplete={finish}
        />
      </>
    );
  }
  return (
    <>
      {!spec.atTarget && <BenchRoom />}
      <PathRig
        key={craftTarget.id}
        rigId={craftTarget.id}
        title={craftTarget.label}
        spec={spec}
        origin={craftTarget.origin ?? BENCH_ORIGIN}
        onComplete={(q, e) => finish(q, e)}
      />
    </>
  );
}

// ── the garage itself ────────────────────────────────────────────────────
function Garage() {
  const floor = useMemo(() => concreteTexture(14, 14), []);
  const wall = useMemo(() => brickTexture(12, 1.2), []);
  const plate = useMemo(() => metalPlateTexture(1, 1), []);
  const lamps: [number, number][] = [[-8, -6], [0, -6], [8, -6], [-8, 4], [0, 4], [8, 4], [-8, 12], [0, 12], [8, 12]];
  return (
    <group>
      {/* concrete floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.015, 0]} receiveShadow>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial map={floor.map} bumpMap={floor.bump} bumpScale={1.5} color="#c4c7cd" roughness={0.72} metalness={0.08} />
      </mesh>
      {/* work bay marking around the car */}
      {[
        { p: [0, 0.002, 3.3], s: [7.4, 0.12] }, { p: [0, 0.002, -3.3], s: [7.4, 0.12] },
        { p: [3.7, 0.002, 0], s: [0.12, 6.7] }, { p: [-3.7, 0.002, 0], s: [0.12, 6.7] },
      ].map((l, i) => (
        <mesh key={i} rotation={[-Math.PI / 2, 0, 0]} position={l.p as [number, number, number]}>
          <planeGeometry args={l.s as [number, number]} />
          <meshStandardMaterial color="#f5c518" roughness={0.6} />
        </mesh>
      ))}
      {/* walls */}
      <mesh position={[0, 5, -18]} receiveShadow>
        <boxGeometry args={[60, 10, 0.4]} />
        <meshStandardMaterial color="#d7dade" roughness={0.9} />
      </mesh>
      <mesh position={[-22, 5, 0]} receiveShadow>
        <boxGeometry args={[0.4, 10, 60]} />
        <meshStandardMaterial color="#cfd3d8" roughness={0.9} />
      </mesh>
      <mesh position={[22, 5, 0]} receiveShadow>
        <boxGeometry args={[0.4, 10, 60]} />
        <meshStandardMaterial color="#cfd3d8" roughness={0.9} />
      </mesh>
      {/* brick wainscot along the back wall */}
      <mesh position={[0, 0.8, -17.78]} receiveShadow>
        <boxGeometry args={[60, 1.6, 0.1]} />
        <meshStandardMaterial map={wall.map} bumpMap={wall.bump} bumpScale={2} color="#caa592" roughness={0.9} />
      </mesh>
      {/* steel plate tool benches along the side walls */}
      {[-18, 18].map((x) => (
        <mesh key={x} position={[x > 0 ? 21 : -21, 0.5, 0]} castShadow receiveShadow>
          <boxGeometry args={[1.2, 1.0, 14]} />
          <meshStandardMaterial map={plate.map} bumpMap={plate.bump} color="#8a8f98" metalness={0.6} roughness={0.5} />
        </mesh>
      ))}
      {/* wall stripe + tool cabinets along the back wall */}
      <mesh position={[0, 1.6, -17.75]}>
        <boxGeometry args={[60, 0.25, 0.1]} />
        <meshStandardMaterial color="#f5c518" roughness={0.6} />
      </mesh>
      {Array.from({ length: 8 }).map((_, i) => (
        <group key={i} position={[-14 + i * 4, 0, -16.8]}>
          <mesh position={[0, 0.9, 0]} castShadow receiveShadow>
            <boxGeometry args={[3, 1.8, 1.2]} />
            <meshStandardMaterial color={i % 2 ? '#b42318' : '#2f3a46'} metalness={0.5} roughness={0.45} />
          </mesh>
          {[0.35, 0.8, 1.25].map((y) => (
            <mesh key={y} position={[0, y, 0.61]}>
              <boxGeometry args={[2.6, 0.38, 0.03]} />
              <meshStandardMaterial color="#1c232b" metalness={0.6} roughness={0.35} />
            </mesh>
          ))}
        </group>
      ))}
      {/* columns */}
      {[-14, 14].map((x) => [-10, 8].map((z) => (
        <mesh key={`${x}${z}`} position={[x, 4, z]} castShadow receiveShadow>
          <boxGeometry args={[0.7, 8, 0.7]} />
          <meshStandardMaterial color="#b9bdc4" roughness={0.7} />
        </mesh>
      )))}
      {/* ceiling lamps */}
      {lamps.map(([x, z], i) => (
        <group key={i} position={[x, 8.6, z]}>
          <mesh>
            <boxGeometry args={[2.8, 0.12, 0.5]} />
            <meshStandardMaterial color="#fff6dc" emissive="#fff0c8" emissiveIntensity={2.2} toneMapped={false} />
          </mesh>
          <mesh position={[0, 0.3, 0]}>
            <boxGeometry args={[3.0, 0.1, 0.7]} />
            <meshStandardMaterial color="#2a2d33" metalness={0.6} roughness={0.4} />
          </mesh>
        </group>
      ))}
      {/* oil drums & crates for set dressing */}
      {[[-17, -12], [-15.5, -13], [17, -12], [16, 10]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.55, z]} castShadow receiveShadow>
          <cylinderGeometry args={[0.45, 0.45, 1.1, 24]} />
          <meshStandardMaterial color={i % 2 ? '#2f5d9e' : '#a6321f'} metalness={0.6} roughness={0.4} />
        </mesh>
      ))}
    </group>
  );
}

function SceneContent({ gizmoMode }: { gizmoMode: GizmoMode }) {
  const build = useGameStore((s) => s.build);
  const setSelectedPart = useGameStore((s) => s.setSelectedPart);
  const model = build ? getCarModel(build.carModelId) : undefined;
  const partIds = build ? Object.keys(build.parts) : [];
  // the garage lights must not leak into the far-away rooms while a session runs
  const session = useGameStore((st) => !!st.craftTarget);

  return (
    <>
      <color attach="background" args={['#c9ced6']} />
      <fog attach="fog" args={['#c9ced6', 38, 90]} />
      <ambientLight intensity={0.35} />
      <hemisphereLight args={['#ffffff', '#8e9199', 0.5]} />
      <directionalLight
        position={[9, 15, 8]}
        intensity={session ? 0 : 2.1}
        castShadow
        shadow-mapSize={[4096, 4096]}
        shadow-camera-left={-18}
        shadow-camera-right={18}
        shadow-camera-top={18}
        shadow-camera-bottom={-18}
        shadow-camera-near={1}
        shadow-camera-far={60}
        shadow-bias={-0.0004}
        shadow-normalBias={0.04}
      />
      <directionalLight position={[-8, 6, -6]} intensity={session ? 0 : 0.5} color="#bcd4ff" />
      <pointLight position={[-5, 4, 3]} intensity={session ? 0 : 18} distance={14} color="#ffb070" />
      <pointLight position={[3.4, 3.4, 5.4]} intensity={session ? 0 : 16} distance={10} color="#fff4e0" />

      <Garage />
      <Grid
        args={[80, 80]}
        cellColor="#b4b8bf"
        sectionColor="#9ea3ab"
        fadeDistance={40}
        infiniteGrid
        cellSize={0.5}
        sectionSize={2.5}
        position={[0, 0.001, 0]}
      />
      <ContactShadows position={[0, 0.003, 0]} opacity={0.6} scale={14} blur={2.4} far={3} resolution={1024} />
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, -0.02, 0]}
        onClick={() => setSelectedPart(null)}
        visible={false}
      >
        <planeGeometry args={[200, 200]} />
      </mesh>

      {model && <CarBodyMesh model={model} ghost />}
      {partIds.map((id) => (
        <SelectablePart key={id} id={id} gizmoMode={gizmoMode} />
      ))}
      <TargetMarkers />
      <TaskRig />
      <GuideArrow />
      <CameraDirector />
      <Environment preset="warehouse" />
    </>
  );
}

export default function Workshop3D({ gizmoMode }: { gizmoMode: GizmoMode }) {
  return (
    <Canvas
      camera={{ position: [7, 5, 9], fov: 42, near: 0.1, far: 200 }}
      dpr={[1, 2]}
      shadows="soft"
      gl={{ antialias: true, powerPreference: 'high-performance', toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.05 }}
    >
      <Suspense fallback={null}>
        <SceneContent gizmoMode={gizmoMode} />
        <SessionAwareOrbit />
      </Suspense>
    </Canvas>
  );
}
