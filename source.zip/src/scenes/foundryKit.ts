import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { GW, GH, NV, BLOCK_W, BLOCK_D, vx, vz, type CarveField } from '../manufacturing/moldCarve';
import { carvedField, newField } from '../manufacturing/moldCarve';
import { useGameStore, type SessionHud } from '../store/useGameStore';
import { sandTexture } from './textures';

// ─────────────────────────────────────────────────────────────────────────
// Shared helpers for the hand-work sessions: the in-memory mould store,
// the heightfield mesh used by every foundry stage, and camera-shot helpers.
// ─────────────────────────────────────────────────────────────────────────

/** carved moulds live here between the foundry tasks of one unit (the quality is also persisted in the save) */
const moulds = new Map<string, CarveField>();
let mouldEpoch = 0;
export const getMouldEpoch = () => mouldEpoch;

export function getMould(unitKey: string, shape: string, savedQuality: number | null): CarveField {
  const hit = moulds.get(unitKey);
  if (hit) return hit;
  const f = savedQuality != null ? carvedField(shape, savedQuality) : newField(shape);
  try { const saved = localStorage.getItem('mould:' + unitKey); if (saved) { const d = JSON.parse(saved); if (d.length === NV) f.d.set(d); } } catch { /* storage unavailable */ }
  moulds.set(unitKey, f);
  return f;
}
export function putMould(unitKey: string, f: CarveField) { moulds.set(unitKey, f); try { localStorage.setItem('mould:' + unitKey, JSON.stringify(Array.from(f.d))); } catch { /* storage unavailable */ } }
export function dropMould(unitKey: string) { moulds.delete(unitKey); try { localStorage.removeItem('mould:' + unitKey); } catch { /* storage unavailable */ } }
export function clearMoulds() { mouldEpoch++; moulds.clear(); try { for (let i = localStorage.length - 1; i >= 0; i--) { const k = localStorage.key(i); if (k?.startsWith('mould:')) localStorage.removeItem(k); } } catch { /* storage unavailable */ } }

// ── heightfield mesh ─────────────────────────────────────────────────────

export function makeHeightGeometry(): THREE.BufferGeometry {
  const g = new THREE.BufferGeometry();
  const pos = new Float32Array(NV * 3);
  const col = new Float32Array(NV * 3);
  const uv = new Float32Array(NV * 2);
  for (let j = 0; j <= GH; j++) {
    for (let i = 0; i <= GW; i++) {
      const k = j * (GW + 1) + i;
      pos[k * 3] = vx(i);
      pos[k * 3 + 2] = vz(j);
      uv[k * 2] = (i / GW) * 3;
      uv[k * 2 + 1] = (j / GH) * 2;
    }
  }
  const idx: number[] = [];
  for (let j = 0; j < GH; j++) {
    for (let i = 0; i < GW; i++) {
      const a = j * (GW + 1) + i;
      const b = a + 1;
      const c = a + (GW + 1);
      const d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  }
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setAttribute('aGlow', new THREE.BufferAttribute(new Float32Array(NV), 1));
  g.setIndex(idx);
  return g;
}

export const SAND_RGB: [number, number, number] = [0.5, 0.4, 0.28];

/** grain noise so the sand never looks like a flat colour */
export function grain(k: number): number {
  const x = Math.sin(k * 12.9898) * 43758.5453;
  return 0.9 + (x - Math.floor(x)) * 0.2;
}

/** vertex-coloured material with a per-vertex glow channel (molten metal glows, sand does not) */
export function makeHeightMaterial(): THREE.MeshStandardMaterial {
  const t = sandTexture(1, 1);
  const m = new THREE.MeshStandardMaterial({ vertexColors: true, bumpMap: t.bump, bumpScale: 2.2, roughness: 0.9, metalness: 0.12 });
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nattribute float aGlow;\nvarying float vGlow;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvGlow = aGlow;');
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying float vGlow;')
      .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\nif (vGlow < -0.5) discard;\ntotalEmissiveRadiance += vec3(1.0, 0.4, 0.1) * vGlow * 2.4;');
  };
  return m;
}

/** writes heights and colours for every vertex, then recomputes the normals once */
export function paintHeight(
  g: THREE.BufferGeometry,
  height: (k: number) => number,
  colour: (k: number, out: [number, number, number]) => void,
  glow?: (k: number) => number,
) {
  const pos = g.getAttribute('position') as THREE.BufferAttribute;
  const col = g.getAttribute('color') as THREE.BufferAttribute;
  const gl = g.getAttribute('aGlow') as THREE.BufferAttribute;
  const out: [number, number, number] = [0, 0, 0];
  for (let k = 0; k < NV; k++) {
    pos.setY(k, height(k));
    colour(k, out);
    col.setXYZ(k, out[0], out[1], out[2]);
    gl.setX(k, glow ? glow(k) : 0);
  }
  pos.needsUpdate = true;
  col.needsUpdate = true;
  gl.needsUpdate = true;
  g.computeVertexNormals();
}

export const CARVE_DEPTH = 0.26;

/** world-space point of a grid vertex relative to the block centre */
export function cellWorld(k: number): [number, number] {
  const i = k % (GW + 1);
  const j = Math.floor(k / (GW + 1));
  return [vx(i), vz(j)];
}

export { BLOCK_W, BLOCK_D };

// ── camera shots ─────────────────────────────────────────────────────────

type V3 = [number, number, number];

/** straight-down view; the tiny +z offset keeps OrbitControls' azimuth stable (no flip at the pole) */
export function shotTop(origin: V3, focusY: number, height: number, dx = 0, dz = 0, snap = false) {
  useGameStore.getState().setShot(
    [origin[0] + dx, origin[1] + focusY + height, origin[2] + dz + height * 0.045],
    [origin[0] + dx, origin[1] + focusY, origin[2] + dz],
    snap,
  );
}

/** low side view looking along -z */
export function shotSide(origin: V3, focusY: number, dist: number, elev = 0.25, dx = 0, snap = false) {
  useGameStore.getState().setShot(
    [origin[0] + dx, origin[1] + focusY + dist * elev, origin[2] + dist],
    [origin[0] + dx, origin[1] + focusY, origin[2]],
    snap,
  );
}

/** three-quarter view */
export function shotAngle(origin: V3, focusY: number, dist: number, snap = false) {
  useGameStore.getState().setShot(
    [origin[0] + dist * 0.55, origin[1] + focusY + dist * 0.7, origin[2] + dist * 0.75],
    [origin[0], origin[1] + focusY, origin[2]],
    snap,
  );
}

/** pushes the session HUD card whenever `key` changes; clears it when the stage unmounts */
export function useHud(key: string, make: () => SessionHud) {
  const setHud = useGameStore((s) => s.setHud);
  const mk = useRef(make);
  mk.current = make;
  useEffect(() => { setHud(mk.current()); }, [key, setHud]);
  useEffect(() => () => setHud(null), [setHud]);
}
// r5c
// r5d
