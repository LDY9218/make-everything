import { forwardRef, useImperativeHandle, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { softSprite } from './textures';

// ─────────────────────────────────────────────────────────────────────────
// Particles: one Points object per effect type (sparks, smoke, dust...).
// Imperative API so rigs can fire bursts from event handlers or emit a
// stream from useFrame. Particle state lives in typed arrays (no React state).
// ─────────────────────────────────────────────────────────────────────────

export interface EmitOpts {
  /** initial speed */
  speed?: number;
  /** random cone/sphere spread 0..1 */
  spread?: number;
  /** base direction (normalised internally) */
  dir?: [number, number, number];
  gravity?: number;
  life?: number;
  size?: number;
  /** size multiplier reached at end of life */
  grow?: number;
  color?: [number, number, number];
  drag?: number;
}

export interface ParticleAPI {
  emit: (pos: [number, number, number], count?: number, opts?: EmitOpts) => void;
}

const VERT = /* glsl */ `
attribute float aSize;
attribute float aAlpha;
attribute vec3 aColor;
varying float vAlpha;
varying vec3 vColor;
void main() {
  vAlpha = aAlpha;
  vColor = aColor;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_PointSize = aSize * (320.0 / max(0.1, -mv.z));
  gl_Position = projectionMatrix * mv;
}
`;
const FRAG = /* glsl */ `
uniform sampler2D uMap;
varying float vAlpha;
varying vec3 vColor;
void main() {
  vec4 t = texture2D(uMap, gl_PointCoord);
  gl_FragColor = vec4(vColor, vAlpha * t.a);
  if (gl_FragColor.a < 0.01) discard;
}
`;

export const Particles = forwardRef<ParticleAPI, { max?: number; additive?: boolean }>(function Particles({ max = 400, additive = true }, ref) {
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(max * 3), 3));
    g.setAttribute('aSize', new THREE.BufferAttribute(new Float32Array(max), 1));
    g.setAttribute('aAlpha', new THREE.BufferAttribute(new Float32Array(max), 1));
    g.setAttribute('aColor', new THREE.BufferAttribute(new Float32Array(max * 3), 3));
    return g;
  }, [max]);
  const mat = useMemo(() => new THREE.ShaderMaterial({
    uniforms: { uMap: { value: softSprite() } },
    vertexShader: VERT,
    fragmentShader: FRAG,
    transparent: true,
    depthWrite: false,
    blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
  }), [additive]);

  const st = useRef({
    vel: new Float32Array(max * 3),
    life: new Float32Array(max),
    maxLife: new Float32Array(max),
    size0: new Float32Array(max),
    grow: new Float32Array(max),
    grav: new Float32Array(max),
    drag: new Float32Array(max),
    col: new Float32Array(max * 3),
    head: 0,
  });

  useImperativeHandle(ref, () => ({
    emit(pos, count = 1, o = {}) {
      const s = st.current;
      const p = geo.getAttribute('position') as THREE.BufferAttribute;
      for (let n = 0; n < count; n++) {
        const i = s.head;
        s.head = (s.head + 1) % max;
        const spread = o.spread ?? 1;
        const speed = (o.speed ?? 1) * (0.5 + Math.random() * 0.7);
        const d = o.dir ?? [0, 1, 0];
        const dl = Math.hypot(d[0], d[1], d[2]) || 1;
        s.vel[i * 3] = (d[0] / dl + (Math.random() - 0.5) * 2 * spread) * speed;
        s.vel[i * 3 + 1] = (d[1] / dl + (Math.random() - 0.5) * 2 * spread) * speed;
        s.vel[i * 3 + 2] = (d[2] / dl + (Math.random() - 0.5) * 2 * spread) * speed;
        s.life[i] = s.maxLife[i] = (o.life ?? 0.8) * (0.6 + Math.random() * 0.6);
        s.size0[i] = (o.size ?? 0.1) * (0.7 + Math.random() * 0.6);
        s.grow[i] = o.grow ?? 1;
        s.grav[i] = o.gravity ?? 0;
        s.drag[i] = o.drag ?? 0;
        const c = o.color ?? [1, 0.7, 0.3];
        s.col[i * 3] = c[0];
        s.col[i * 3 + 1] = c[1];
        s.col[i * 3 + 2] = c[2];
        p.setXYZ(i, pos[0], pos[1], pos[2]);
      }
      p.needsUpdate = true;
    },
  }), [geo, max]);

  useFrame((_, dt0) => {
    const dt = Math.min(dt0, 0.05);
    const s = st.current;
    const p = geo.getAttribute('position') as THREE.BufferAttribute;
    const sz = geo.getAttribute('aSize') as THREE.BufferAttribute;
    const al = geo.getAttribute('aAlpha') as THREE.BufferAttribute;
    const co = geo.getAttribute('aColor') as THREE.BufferAttribute;
    let any = false;
    for (let i = 0; i < max; i++) {
      if (s.life[i] <= 0) {
        if (al.getX(i) !== 0) { al.setX(i, 0); any = true; }
        continue;
      }
      any = true;
      s.life[i] -= dt;
      const k = Math.max(0, s.life[i] / s.maxLife[i]);
      s.vel[i * 3 + 1] += s.grav[i] * dt;
      const dr = 1 - Math.min(1, s.drag[i] * dt);
      s.vel[i * 3] *= dr; s.vel[i * 3 + 1] *= dr; s.vel[i * 3 + 2] *= dr;
      p.setXYZ(i, p.getX(i) + s.vel[i * 3] * dt, p.getY(i) + s.vel[i * 3 + 1] * dt, p.getZ(i) + s.vel[i * 3 + 2] * dt);
      al.setX(i, k);
      sz.setX(i, s.size0[i] * (1 + (s.grow[i] - 1) * (1 - k)));
      co.setXYZ(i, s.col[i * 3], s.col[i * 3 + 1], s.col[i * 3 + 2]);
    }
    if (any) {
      p.needsUpdate = true; sz.needsUpdate = true; al.needsUpdate = true; co.needsUpdate = true;
    }
  });

  return <points geometry={geo} material={mat} frustumCulled={false} />;
});
