// Tiny WebAudio sound kit — all sounds are synthesised, no audio files.
// Every call is wrapped in try/catch: sound is a bonus, never a requirement.

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;
let noiseBuf: AudioBuffer | null = null;

function ensure(): AudioContext | null {
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = 0.7;
      master.connect(ctx.destination);
      const len = ctx.sampleRate * 1.5;
      noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

export function setMuted(m: boolean) {
  muted = m;
  if (master) master.gain.value = m ? 0 : 0.7;
}

export function unlockAudio() {
  ensure();
}

function noiseBurst(dur: number, freq: number, q: number, gain: number, type: BiquadFilterType = 'bandpass', decay = true) {
  const c = ensure();
  if (!c || !master || !noiseBuf || muted) return;
  try {
    const src = c.createBufferSource();
    src.buffer = noiseBuf;
    const f = c.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = c.createGain();
    const t = c.currentTime;
    g.gain.setValueAtTime(gain, t);
    if (decay) g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    else g.gain.setValueAtTime(gain, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(master);
    src.start(t, Math.random());
    src.stop(t + dur + 0.05);
  } catch { /* ignore */ }
}

function tone(freq: number, dur: number, gain: number, type: OscillatorType = 'sine', slideTo?: number) {
  const c = ensure();
  if (!c || !master || muted) return;
  try {
    const o = c.createOscillator();
    const g = c.createGain();
    const t = c.currentTime;
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(master);
    o.start(t);
    o.stop(t + dur + 0.05);
  } catch { /* ignore */ }
}

export const sfx = {
  ok() { tone(660, 0.12, 0.12, 'triangle'); setTimeout(() => tone(990, 0.16, 0.1, 'triangle'), 80); },
  bad() { tone(160, 0.22, 0.14, 'sawtooth', 90); },
  done() { [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => tone(f, 0.22, 0.1, 'triangle'), i * 90)); },
  tick() { tone(1200, 0.04, 0.05, 'square'); },
  clank() { noiseBurst(0.18, 2400, 6, 0.35); tone(420, 0.2, 0.12, 'square', 300); },
  thud() { tone(90, 0.25, 0.3, 'sine', 45); noiseBurst(0.1, 300, 1, 0.2, 'lowpass'); },
  hiss() { noiseBurst(1.1, 6500, 0.7, 0.22, 'highpass'); },
  pour() { noiseBurst(0.5, 900, 1.2, 0.1, 'bandpass'); },
  crack() { noiseBurst(0.25, 3200, 3, 0.4); noiseBurst(0.12, 800, 2, 0.3); },
  scrape(level: number) { if (level > 0.05) noiseBurst(0.07, 1800 + level * 2400, 2.5, Math.min(0.2, 0.03 + level * 0.12)); },
  whoosh() { noiseBurst(0.35, 1400, 0.8, 0.12); },
  zap() { noiseBurst(0.08, 5200, 4, 0.12); },
};
