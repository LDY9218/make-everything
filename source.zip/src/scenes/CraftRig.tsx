import { useEffect, useMemo, useRef, useState } from 'react';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';
import type { CastSpec } from '../manufacturing/recipes';
import { FORGE_ORIGIN } from '../manufacturing/targets';
import { useGameStore } from '../store/useGameStore';
import {
  NV, newField, scrape, carveStats, pieceHeights, flowOrder, newCool, blow, coolTick, coolProgress, polish, polishProgress,
  type CarveField, GW, GH, vx, vz,
} from '../manufacturing/moldCarve';
import { FURNACE_POS, BLOCK_Y as TABLE_Y, TANK_POS } from './rooms';
import {
  CARVE_DEPTH, SAND_RGB, getMould, grain, makeHeightGeometry, makeHeightMaterial, paintHeight, putMould,
  shotAngle, shotTop, BLOCK_W, BLOCK_D, useHud,
} from './foundryKit';
import { Particles, type ParticleAPI } from './fx';
import { sfx } from './sfx';
import { sandTexture } from './textures';

// ─────────────────────────────────────────────────────────────────────────
// The foundry. One cast part = five separate hand jobs, each its own step in
// its own session inside the foundry room:
//   carve  — scrape the sand block; material only goes away where, and as much
//            as, the scraper actually travelled. Not finished until it is cut.
//   melt   — drag the ingots into the crucible, pump the bellows to the right heat
//   pour   — dip the ladle, pour into the sprue; spilling costs quality
//   cool   — sweep the blower evenly (uneven chill cracks the metal), then
//            brush the sand off the casting
//   finish — carry it with the tongs into the quench tank, then polish it
// ─────────────────────────────────────────────────────────────────────────

type V3 = [number, number, number];
const O = FORGE_ORIGIN;
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

interface Ctx {
  shape: string;
  unitKey: string;
  ingots: number;
  mold: { quality: number; errors: string[] } | null;
  title: string;
  done: (quality: number, errors: string[], extra?: { carveQuality?: number }) => void;
}

// ── small shared bits ────────────────────────────────────────────────────

/** stop dragging even when the pointer is released outside the catcher plane */
function useWindowUp(active: boolean, up: () => void) {
  const ref = useRef(up);
  ref.current = up;
  useEffect(() => {
    if (!active) return undefined;
    const f = () => ref.current();
    window.addEventListener('pointerup', f);
    return () => window.removeEventListener('pointerup', f);
  }, [active]);
}

const local = (p: THREE.Vector3): [number, number] => [p.x - O[0], p.z - O[2]];

function SandBlock({ withBase = true }: { withBase?: boolean }) {
  const t = useMemo(() => sandTexture(2, 1), []);
  const m = <meshStandardMaterial map={t.map} bumpMap={t.bump} bumpScale={2} roughness={0.95} />;
  return (
    <group>
      {[[0, -BLOCK_D / 2], [0, BLOCK_D / 2]].map(([x, z], i) => (
        <mesh key={i} position={[x, -0.15, z]} castShadow receiveShadow><boxGeometry args={[BLOCK_W, 0.3, 0.02]} />{m}</mesh>
      ))}
      {[-BLOCK_W / 2, BLOCK_W / 2].map((x) => (
        <mesh key={x} position={[x, -0.15, 0]} castShadow receiveShadow><boxGeometry args={[0.02, 0.3, BLOCK_D]} />{m}</mesh>
      ))}
      {withBase && <mesh position={[0, -0.45, 0]} receiveShadow><boxGeometry args={[BLOCK_W, 0.3, BLOCK_D]} />{m}</mesh>}
    </group>
  );
}

function CatchPlane({
  y = 0.02, w = 9, d = 7, onDown, onMove, onUp,
}: {
  y?: number; w?: number; d?: number;
  onDown?: (x: number, z: number) => void; onMove?: (x: number, z: number) => void; onUp?: () => void;
}) {
  // stopPropagation so the OrbitControls underneath never gets this drag
  // (otherwise the camera would rotate while the player is scraping)
  return (
    <mesh
      position={[0, y, 0]}
      rotation={[-Math.PI / 2, 0, 0]}
      visible={false}
      onPointerDown={(e: ThreeEvent<PointerEvent>) => { e.stopPropagation(); const [x, z] = local(e.point); onDown?.(x, z); }}
      onPointerMove={(e: ThreeEvent<PointerEvent>) => { const [x, z] = local(e.point); onMove?.(x, z); }}
      onPointerUp={(e: ThreeEvent<PointerEvent>) => { e.stopPropagation(); onUp?.(); }}
    >
      <planeGeometry args={[w, d]} />
    </mesh>
  );
}

function colourOfHeat(t: number, out: [number, number, number]) {
  // 0 = cold steel, 0.5 = dull red, 1 = yellow-orange
  if (t < 0.5) {
    const k = clamp01(t / 0.5);
    out[0] = lerp(0.48, 0.5, k); out[1] = lerp(0.5, 0.1, k); out[2] = lerp(0.54, 0.05, k);
  } else {
    const k = clamp01((t - 0.5) / 0.5);
    out[0] = lerp(0.5, 1, k); out[1] = lerp(0.1, 0.62, k); out[2] = lerp(0.05, 0.16, k);
  }
}

function sandColour(k: number, out: [number, number, number]) {
  const g = grain(k);
  out[0] = SAND_RGB[0] * g; out[1] = SAND_RGB[1] * g; out[2] = SAND_RGB[2] * g;
}

function edgeMap(f: CarveField): Uint8Array {
  const e = new Uint8Array(NV);
  const W = 97;
  for (let k = 0; k < NV; k++) {
    if (!f.mask[k]) continue;
    const i = k % W;
    const j = Math.floor(k / W);
    const nb = [i > 0 ? k - 1 : -1, i < W - 1 ? k + 1 : -1, j > 0 ? k - W : -1, j < 64 ? k + W : -1];
    if (nb.some((n) => n >= 0 && !f.mask[n])) e[k] = 1;
  }
  return e;
}

// ═════════════════════════════════════════════════════════════════════════
// 1. CARVE
// ═════════════════════════════════════════════════════════════════════════
function CarveStage({ ctx }: { ctx: Ctx }) {
  const field = useMemo(() => newField(ctx.shape), [ctx.shape]);
  const edge = useMemo(() => edgeMap(field), [field]);
  const geo = useMemo(makeHeightGeometry, []);
  const mat = useMemo(makeHeightMaterial, []);
  const dust = useRef<ParticleAPI>(null);
  const tool = useRef<THREE.Group>(null);
  const s = useRef({ down: false, last: null as [number, number] | null, dirty: true, tick: 0, angle: false, finished: false });
  const [down, setDown] = useState(false);
  const [stats, setStats] = useState({ fill: 0, over: 0, quality: 0 });
  const [angle, setAngle] = useState(false);
  const setGuide = useGameStore((st) => st.setGuide);
  const fadeGuide = useGameStore((st) => st.fadeGuide);
  const guideKeyRef = useRef<string | null>(null);

  useEffect(() => { shotTop(O, TABLE_Y, 6.2, 0, 0, true); }, []);
  useWindowUp(down, () => { s.current.down = false; s.current.last = null; setDown(false); });

  const repaint = () => paintHeight(
    geo,
    (k) => -CARVE_DEPTH * field.d[k],
    (k, out) => {
      sandColour(k, out);
      const dep = field.d[k];
      if (field.mask[k]) {
        const g = grain(k);
        const e = edge[k] ? 0.55 : 1;
        out[0] = lerp(0.85, 0.2, dep) * g * e; out[1] = lerp(0.55, 0.13, dep) * g * e; out[2] = lerp(0.1, 0.06, dep) * g * e;
      } else if (dep > 0.04) {
        const k2 = field.forgive[k] ? 0.4 : 1;
        const bad = clamp01(dep * 1.6) * k2;
        out[0] = lerp(out[0], field.forgive[k] ? 0.2 : 0.7, bad); out[1] = lerp(out[1], field.forgive[k] ? 0.13 : 0.1, bad); out[2] = lerp(out[2], field.forgive[k] ? 0.06 : 0.07, bad);
      }
    },
  );

  const strokeTo = (x: number, z: number) => {
    const st = s.current;
    if (tool.current) tool.current.position.set(x, 0.2 - CARVE_DEPTH * 0.3, z);
    if (!st.down) return;
    if (!st.last) { st.last = [x, z]; return; }
    const dx = x - st.last[0];
    const dz = z - st.last[1];
    const dist = Math.hypot(dx, dz);
    if (dist < 0.004) return;
    const n = Math.max(1, Math.ceil(dist / 0.03));
    for (let i = 1; i <= n; i++) scrape(field, st.last[0] + (dx * i) / n, st.last[1] + (dz * i) / n, dist / n);
    st.last = [x, z];
    st.dirty = true;
    sfx.scrape(Math.min(1, dist * 20));
    dust.current?.emit([x, TABLE_Y + 0.05, z], 2, {
      speed: 0.5, spread: 0.7, gravity: -1.6, life: 0.55, size: 0.07, grow: 1.6, color: [0.78, 0.66, 0.46],
    });
  };

  // find the deepest-unfilled cavity cell → where the guide arrow should point
  const pickGuideTarget = (): { pos: [number, number, number]; key: string } | null => {
    let bestK = -1; let bestScore = -1;
    for (let k = 0; k < NV; k++) {
      if (!field.mask[k]) continue;
      // under-carved cells have d < 0.85; the lowest d (most work left) wins
      if (field.d[k] >= 0.85) continue;
      const score = 1 - field.d[k];
      if (score > bestScore) { bestScore = score; bestK = k; }
    }
    if (bestK < 0) return null;
    const i = bestK % (GW + 1);
    const j = Math.floor(bestK / (GW + 1));
    const bucketI = Math.floor(i / 8);
    const bucketJ = Math.floor(j / 8);
    return { pos: [O[0] + vx(i), TABLE_Y + 0.05, O[2] + vz(j)], key: `carve-${bucketI}-${bucketJ}` };
  };

  useFrame(() => {
    const st = s.current;
    st.tick++;
    if (st.dirty && st.tick % 2 === 0) { repaint(); st.dirty = false; }
    if (st.tick % 10 === 0) {
      const c = carveStats(field);
      setStats((p) => (Math.abs(p.fill - c.fill) > 0.005 || Math.abs(p.over - c.over) > 0.005 ? c : p));
    }
    if (st.tick % 30 === 0 && !st.finished) {
      // every half second, pick the spot that still needs the most work
      const next = pickGuideTarget();
      if (!next) {
        if (guideKeyRef.current) { fadeGuide(guideKeyRef.current); guideKeyRef.current = null; }
      } else if (next.key !== guideKeyRef.current) {
        // the old bucket is done → fade it; show the new one
        if (guideKeyRef.current) fadeGuide(guideKeyRef.current);
        guideKeyRef.current = next.key;
        setGuide({ pos: next.pos, key: next.key, label: '여기를 긁으세요' });
      }
    }
  });

  // clear the guide when this stage goes away
  useEffect(() => () => setGuide(null), [setGuide]);

  const ready = stats.fill >= 0.9;
  const finish = () => {
    if (!ready || s.current.finished) return;
    s.current.finished = true;
    const c = carveStats(field);
    putMould(ctx.unitKey, field);
    const errs: string[] = [];
    if (c.over > 0.04) errs.push(`틀 바깥을 ${(c.over * 100).toFixed(0)}% 만큼 잘못 파냄`);
    if (c.fill < 0.98) errs.push(`틀 안쪽 ${((1 - c.fill) * 100).toFixed(0)}% 덜 파짐`);
    sfx.done();
    ctx.done(c.quality, errs, { carveQuality: c.quality });
  };

  useHud(`carve-${Math.round(stats.fill * 50)}-${Math.round(stats.over * 50)}-${angle}-${ready}`, () => ({
    title: ctx.title,
    phase: '1/5 · 모래 틀 조각',
    hint: ready
      ? '충분히 파였습니다. 남은 얼룩을 더 다듬거나 [틀 확정]을 누르세요.'
      : '금색 윤곽 안쪽을 마우스를 누른 채 긁어서 파세요. 많이 긁은 곳일수록 깊게 파입니다. 윤곽 밖을 파면 빨갛게 표시되고 감점됩니다.',
    progress: Math.round(stats.fill * 100),
    stats: `파낸 정도 ${Math.round(stats.fill * 100)}% (90% 이상 필요) · 윤곽 밖 ${Math.round(stats.over * 100)}%`,
    actions: [
      { label: angle ? '위에서 보기' : '비스듬히 보기', onClick: () => { setAngle((v) => { const nv = !v; if (nv) shotAngle(O, TABLE_Y, 5.2); else shotTop(O, TABLE_Y, 6.2); return nv; }); } },
      { label: ready ? '틀 확정 ▶' : `틀 확정 (${Math.round(stats.fill * 100)}%)`, disabled: !ready, onClick: finish },
    ],
  }));

  return (
    <group>
      <group position={[0, TABLE_Y, 0]}>
        <SandBlock />
        <mesh geometry={geo} material={mat} receiveShadow castShadow />
        <group ref={tool} position={[0, 0.3, 0]} rotation={[0.5, 0, -0.35]} scale={down ? 1.08 : 1}>
          <mesh position={[0, 0.14, 0]} castShadow><coneGeometry args={[0.05, 0.28, 8]} /><meshStandardMaterial color="#c9c9d0" metalness={0.9} roughness={0.25} /></mesh>
          <mesh position={[0, 0.5, 0]} castShadow><cylinderGeometry args={[0.04, 0.045, 0.45, 10]} /><meshStandardMaterial color="#7a4a1a" roughness={0.8} /></mesh>
        </group>
        <CatchPlane
          y={0.04}
          onDown={(x, z) => { s.current.down = true; s.current.last = [x, z]; setDown(true); }}
          onMove={strokeTo}
          onUp={() => { s.current.down = false; s.current.last = null; setDown(false); }}
        />
      </group>
      <Particles ref={dust} max={300} additive={false} />
    </group>
  );
}

// ═════════════════════════════════════════════════════════════════════════
// 2. MELT
// ═════════════════════════════════════════════════════════════════════════
const TRAY: V3 = [FURNACE_POS[0], 0.9, FURNACE_POS[2] + 2.6];
const CRUC: V3 = [FURNACE_POS[0], 1.66, FURNACE_POS[2]];
const BELLOWS: V3 = [FURNACE_POS[0] - 2.5, 0.55, FURNACE_POS[2] + 0.1];

function MeltStage({ ctx }: { ctx: Ctx }) {
  const n = Math.max(1, Math.min(4, ctx.ingots));
  const refs = useRef<(THREE.Group | null)[]>([]);
  const sim = useRef({
    heat: 0, hold: 0, overs: 0, inside: new Set<number>(), drag: -1, pump: false, side: 0, bz: 0, finished: false, tick: 0, errors: [] as string[],
  });
  const handle = useRef<THREE.Group>(null);
  const bodyRef = useRef<THREE.Mesh>(null);
  const molten = useRef<THREE.Mesh>(null);
  const glow = useRef<THREE.PointLight>(null);
  const fire = useRef<ParticleAPI>(null);
  const smoke = useRef<ParticleAPI>(null);
  const [ui, setUi] = useState({ heat: 0, inCount: 0, hold: 0 });
  const [dragging, setDragging] = useState(false);

  const setGuide = useGameStore((st) => st.setGuide);
  const fadeGuide = useGameStore((st) => st.fadeGuide);
  const guideKeyRef = useRef<string | null>(null);

  useEffect(() => { shotTop(O, 1.2, 7.2, FURNACE_POS[0] - 0.9, FURNACE_POS[2] + 1.0, true); }, []);
  useEffect(() => () => setGuide(null), [setGuide]);
  useWindowUp(dragging, () => { releaseAll(); });

  const slot = (i: number): V3 => [TRAY[0] - 0.9 + i * 0.6, TRAY[1] + 0.1, TRAY[2]];

  function releaseAll() {
    const st = sim.current;
    if (st.drag >= 0) {
      const g = refs.current[st.drag];
      if (g) {
        const d = Math.hypot(g.position.x - CRUC[0], g.position.z - CRUC[2]);
        if (d < 0.6) {
          st.inside.add(st.drag);
          g.visible = false;
          sfx.clank();
          fire.current?.emit([CRUC[0], CRUC[1] + 0.1, CRUC[2]], 18, { speed: 1.6, spread: 0.8, gravity: -3, life: 0.7, size: 0.08, color: [1, 0.7, 0.25] });
        } else {
          const p = slot(st.drag);
          g.position.set(p[0], p[1], p[2]);
        }
      }
      st.drag = -1;
    }
    st.pump = false;
    setDragging(false);
  }

  const onPlaneMove = (x: number, z: number) => {
    const st = sim.current;
    if (st.drag >= 0) {
      const g = refs.current[st.drag];
      if (g) g.position.set(x, 2.3, z);
    }
    if (st.pump) {
      const bz = Math.max(0, Math.min(1.2, z - (BELLOWS[2] - 0.6)));
      st.bz = bz;
      if (bz > 1.0 && st.side === 0) { st.side = 1; pumpOnce(); }
      if (bz < 0.2 && st.side === 1) { st.side = 0; pumpOnce(); }
    }
  };

  function pumpOnce() {
    const st = sim.current;
    sfx.whoosh();
    st.heat += st.inside.size > 0 ? 0.075 : 0.03;
    fire.current?.emit([CRUC[0], CRUC[1] + 0.05, CRUC[2]], 14, { speed: 1.4, spread: 0.5, gravity: 1.2, life: 0.8, size: 0.14, grow: 0.3, color: [1, 0.5, 0.12], dir: [0, 1, 0] });
  }

  useFrame((state, dt0) => {
    const dt = Math.min(dt0, 0.05);
    const st = sim.current;
    st.tick++;
    st.heat = Math.max(0, st.heat - 0.045 * dt);
    const all = st.inside.size >= n;
    if (all && st.heat >= 0.95 && st.heat <= 1.22) st.hold += dt;
    else st.hold = Math.max(0, st.hold - dt * 0.6);
    if (st.heat > 1.28) {
      st.overs++;
      st.errors.push('도가니를 과열시킴 (탄소 손실)');
      st.heat = 1.05;
      sfx.bad();
    }
    if (all && st.hold >= 2.5 && !st.finished) {
      st.finished = true;
      sfx.pour();
      const q = Math.max(35, 100 - st.overs * 10);
      window.setTimeout(() => ctx.done(q, st.errors.slice()), 700);
    }
    // visuals
    if (handle.current) handle.current.position.z = BELLOWS[2] - 0.6 + st.bz;
    if (bodyRef.current) bodyRef.current.scale.z = 1 - st.bz * 0.45;
    const h = clamp01(st.heat / 1.1);
    if (molten.current) {
      molten.current.visible = st.inside.size > 0;
      const m = molten.current.material as THREE.MeshStandardMaterial;
      m.color.setRGB(lerp(0.45, 1, h), lerp(0.45, 0.62, h), lerp(0.5, 0.2, h));
      m.emissive.setRGB(1, 0.42, 0.1);
      m.emissiveIntensity = h * h * 3;
      molten.current.scale.set(1, 0.6 + st.inside.size * 0.5, 1);
    }
    if (glow.current) glow.current.intensity = 4 + h * 40;
    if (h > 0.3) {
      fire.current?.emit([CRUC[0] + (Math.random() - 0.5) * 0.4, CRUC[1] + 0.15, CRUC[2] + (Math.random() - 0.5) * 0.4], h > 0.7 ? 2 : 1, {
        speed: 0.5, spread: 0.2, gravity: 1.5, life: 0.7, size: 0.1, grow: 0.2, color: [1, 0.45, 0.1], dir: [0, 1, 0],
      });
    }
    if (st.tick % 3 === 0 && h > 0.15) {
      smoke.current?.emit([FURNACE_POS[0], 4.2, FURNACE_POS[2] - 0.6], 1, {
        speed: 0.5, spread: 0.2, gravity: 0.6, life: 2.2, size: 0.3, grow: 3, color: [0.3, 0.3, 0.32], dir: [0, 1, 0],
      });
    }
    if (st.tick % 6 === 0) {
      const next = { heat: Math.round(st.heat * 40) / 40, inCount: st.inside.size, hold: Math.round(st.hold * 4) / 4 };
      setUi((p) => (p.heat !== next.heat || p.inCount !== next.inCount || p.hold !== next.hold ? next : p));
    }
    if (st.tick % 20 === 0 && !st.finished) {
      // find the lowest-index ingot still on the tray, or the bellows if all in, or the crucible when holding
      let target: { pos: [number, number, number]; key: string; label: string } | null = null;
      if (st.inside.size < n) {
        for (let i = 0; i < n; i++) {
          if (!st.inside.has(i)) {
            const p = slot(i);
            target = { pos: [p[0], p[1] + 0.3, p[2]], key: `melt-ingot-${i}`, label: '쇠 덩어리를 도가니로' };
            break;
          }
        }
      } else if (st.heat < 0.95) {
        target = { pos: [BELLOWS[0], BELLOWS[1] + 0.9, BELLOWS[2] - 0.3 + st.bz], key: 'melt-bellows', label: '풀무질' };
      } else if (st.heat >= 0.95 && st.heat <= 1.22) {
        target = { pos: [CRUC[0], CRUC[1] + 0.9, CRUC[2]], key: 'melt-hold', label: '온도 유지' };
      }
      if (!target) {
        if (guideKeyRef.current) { fadeGuide(guideKeyRef.current); guideKeyRef.current = null; }
      } else if (target.key !== guideKeyRef.current) {
        if (guideKeyRef.current) fadeGuide(guideKeyRef.current);
        guideKeyRef.current = target.key;
        setGuide({ pos: target.pos, key: target.key, label: target.label });
      }
    }
  });

  const temp = Math.round(20 + ui.heat * 1250);
  const msg = ui.inCount < n
    ? `재료 ${ui.inCount}/${n} — 쇠 덩어리를 잡아 도가니(불 위의 항아리)로 끌어다 넣으세요.`
    : ui.heat < 0.95
      ? '풀무 손잡이를 앞뒤로 끝까지 반복해서 밀고 당겨 온도를 올리세요.'
      : ui.heat > 1.22
        ? '너무 뜨겁습니다! 잠시 쉬세요.'
        : '적정 온도! 이 상태를 유지하세요.';
  useHud(`melt-${ui.heat}-${ui.inCount}-${ui.hold}`, () => ({
    title: ctx.title,
    phase: '2/5 · 재료 용해',
    hint: msg,
    progress: Math.min(100, Math.round((ui.hold / 2.5) * 100)),
    stats: `온도 ${temp}℃ (적정 1,400~1,600℃ 구간을 2.5초 유지) · 투입 ${ui.inCount}/${n}`,
  }));

  return (
    <group>
      {/* ingot tray + ingots */}
      <mesh position={[TRAY[0], TRAY[1] - 0.05, TRAY[2]]} receiveShadow castShadow><boxGeometry args={[2.8, 0.1, 0.8]} /><meshStandardMaterial color="#3a3a3e" metalness={0.7} roughness={0.5} /></mesh>
      {Array.from({ length: n }).map((_, i) => (
        <group
          key={i}
          ref={(g) => { refs.current[i] = g; }}
          position={slot(i)}
          onPointerDown={(e: ThreeEvent<PointerEvent>) => {
            if (sim.current.inside.has(i)) return;
            e.stopPropagation();
            sim.current.drag = i;
            setDragging(true);
            const g = refs.current[i];
            if (g) g.position.y = 2.3;
          }}
        >
          <mesh castShadow><boxGeometry args={[0.5, 0.16, 0.26]} /><meshStandardMaterial color="#9a9ca2" metalness={0.9} roughness={0.35} /></mesh>
          <mesh position={[0, 0.085, 0]}><boxGeometry args={[0.42, 0.02, 0.18]} /><meshStandardMaterial color="#c0c2c8" metalness={0.95} roughness={0.2} /></mesh>
        </group>
      ))}

      {/* crucible contents */}
      <mesh ref={molten} position={[CRUC[0], CRUC[1] + 0.12, CRUC[2]]} visible={false}>
        <cylinderGeometry args={[0.32, 0.3, 0.22, 28]} />
        <meshStandardMaterial color="#888" metalness={0.8} roughness={0.35} />
      </mesh>
      <pointLight ref={glow} position={[CRUC[0], CRUC[1] + 0.6, CRUC[2]]} color="#ff7a2a" intensity={4} distance={7} />

      {/* bellows */}
      <group position={BELLOWS}>
        <mesh position={[0, -0.25, 0]} castShadow><boxGeometry args={[0.7, 0.5, 1.9]} /><meshStandardMaterial color="#4a3a2a" roughness={0.9} /></mesh>
        <mesh ref={bodyRef} position={[0, 0.1, 0]} castShadow><boxGeometry args={[0.5, 0.3, 1.2]} /><meshStandardMaterial color="#6a3a22" roughness={0.85} /></mesh>
        {[-0.55, -0.3, -0.05, 0.2, 0.45].map((z) => (
          <mesh key={z} position={[0, 0.1, z]}><boxGeometry args={[0.56, 0.34, 0.04]} /><meshStandardMaterial color="#2a2a2e" metalness={0.5} roughness={0.5} /></mesh>
        ))}
      </group>
      <group
        ref={handle}
        position={[BELLOWS[0], BELLOWS[1] + 0.55, BELLOWS[2] - 0.6]}
        onPointerDown={(e: ThreeEvent<PointerEvent>) => { e.stopPropagation(); sim.current.pump = true; setDragging(true); }}
      >
        <mesh castShadow><boxGeometry args={[0.16, 0.16, 0.5]} /><meshStandardMaterial color="#d4a017" roughness={0.5} metalness={0.3} /></mesh>
        <mesh position={[0, -0.2, 0]}><cylinderGeometry args={[0.04, 0.04, 0.4, 8]} /><meshStandardMaterial color="#aaa" metalness={0.9} roughness={0.3} /></mesh>
      </group>

      <CatchPlane y={2.0} w={16} d={12} onMove={onPlaneMove} onUp={releaseAll} />
      <Particles ref={fire} max={500} additive />
      <Particles ref={smoke} max={120} additive={false} />
    </group>
  );
}

// ═════════════════════════════════════════════════════════════════════════
// 3. POUR
// ═════════════════════════════════════════════════════════════════════════
const POT: [number, number] = [-2.55, 1.35];

function PourStage({ ctx }: { ctx: Ctx }) {
  const field = useMemo(() => getMould(ctx.unitKey, ctx.shape, ctx.mold?.quality ?? null), [ctx.unitKey, ctx.shape, ctx.mold]);
  const geo = useMemo(makeHeightGeometry, []);
  const mat = useMemo(makeHeightMaterial, []);
  const flow = useMemo(() => flowOrder(field), [field]);
  const ladle = useRef<THREE.Group>(null);
  const stream = useRef<THREE.Mesh>(null);
  const sparks = useRef<ParticleAPI>(null);
  const st = useRef({ x: 0, z: 0, down: false, metal: 0, fill: 0, spill: 0, dirty: true, tick: 0, finished: false, over: false });
  const [ui, setUi] = useState({ fill: 0, metal: 0, spill: 0 });
  const [down, setDown] = useState(false);
  const setGuide = useGameStore((g) => g.setGuide);
  const fadeGuide = useGameStore((g) => g.fadeGuide);
  const guideKeyRef = useRef<string | null>(null);

  useEffect(() => { shotTop(O, TABLE_Y, 6.2, -0.3, 0.2, true); }, []);
  useEffect(() => () => setGuide(null), [setGuide]);
  useWindowUp(down, () => { st.current.down = false; setDown(false); });

  const repaint = () => {
    const thr = st.current.fill * flow.max * 1.001;
    const filled = (k: number) => st.current.fill > 0 && flow.order[k] <= thr;
    paintHeight(
      geo,
      (k) => (filled(k) ? -0.03 : -CARVE_DEPTH * field.d[k]),
      (k, out) => {
        sandColour(k, out);
        if (filled(k)) { out[0] = 1; out[1] = 0.6; out[2] = 0.18; }
        else if (field.mask[k]) { const g = grain(k); out[0] = 0.2 * g; out[1] = 0.13 * g; out[2] = 0.06 * g; }
        else if (field.d[k] > 0.04) {
          const b = clamp01(field.d[k] * 1.4); out[0] = lerp(out[0], 0.2, b); out[1] = lerp(out[1], 0.13, b); out[2] = lerp(out[2], 0.06, b);
        }
      },
      (k) => (filled(k) ? 1 : 0),
    );
  };

  useFrame((_, dt0) => {
    const dt = Math.min(dt0, 0.05);
    const s = st.current;
    s.tick++;
    const nearPot = Math.hypot(s.x - POT[0], s.z - POT[1]) < 0.5;
    const nearSprue = Math.hypot(s.x - field.sprue[0], s.z - field.sprue[1]) < 0.22;
    let pouring = false;
    if (s.finished) pouring = false;
    else if (s.down && s.metal > 0.01) {
      pouring = true;
      s.metal = Math.max(0, s.metal - 0.5 * dt);
      if (nearSprue) {
        s.fill = Math.min(1, s.fill + 0.2 * dt);
        s.dirty = true;
        if (s.tick % 5 === 0) sfx.pour();
      } else if (!nearPot) {
        s.spill += dt;
        sparks.current?.emit([s.x, TABLE_Y + 0.05, s.z], 2, { speed: 1.4, spread: 0.9, gravity: -4, life: 0.5, size: 0.07, color: [1, 0.55, 0.15] });
      }
    } else if (nearPot && !s.down) {
      s.metal = Math.min(1, s.metal + 1.4 * dt);
    }
    if (ladle.current) {
      ladle.current.position.set(s.x, 0.62, s.z);
      ladle.current.rotation.z = pouring ? -0.7 : 0;
    }
    if (stream.current) {
      stream.current.visible = pouring;
      stream.current.position.set(s.x, 0.3, s.z);
    }
    if (s.dirty && s.tick % 2 === 0) { repaint(); s.dirty = false; }
    if (s.fill >= 1 && !s.finished) {
      s.finished = true;
      const q = Math.max(30, Math.round(100 - s.spill * 8));
      const errs = s.spill > 0.4 ? [`쇳물을 ${s.spill.toFixed(1)}초 동안 바닥에 흘림`] : [];
      sfx.hiss();
      window.setTimeout(() => ctx.done(q, errs), 900);
    }
    if (s.tick % 5 === 0) {
      const nx = { fill: Math.round(s.fill * 100), metal: Math.round(s.metal * 20) / 20, spill: Math.round(s.spill * 4) / 4 };
      setUi((p) => (p.fill !== nx.fill || p.metal !== nx.metal || p.spill !== nx.spill ? nx : p));
    }
    if (s.tick % 20 === 0 && !s.finished) {
      let target: { pos: [number, number, number]; key: string; label: string } | null = null;
      if (s.metal < 0.3) {
        target = { pos: [O[0] + POT[0], TABLE_Y + 0.9, O[2] + POT[1]], key: 'pour-pot', label: '여기서 쇳물 뜨기' };
      } else {
        target = { pos: [O[0] + field.sprue[0], TABLE_Y + 0.8, O[2] + field.sprue[1]], key: 'pour-sprue', label: '여기로 부어요' };
      }
      if (target.key !== guideKeyRef.current) {
        if (guideKeyRef.current) fadeGuide(guideKeyRef.current);
        guideKeyRef.current = target.key;
        setGuide({ pos: target.pos, key: target.key, label: target.label });
      }
    }
  });

  useHud(`pour-${ui.fill}-${ui.metal}-${ui.spill}`, () => ({
    title: ctx.title,
    phase: '3/5 · 쇳물 주입',
    hint: ui.metal < 0.05
      ? '국자가 비었습니다. 왼쪽 아래의 쇳물 항아리 위에서 마우스 버튼을 떼고 기다리면 쇳물을 뜹니다.'
      : '국자를 파란 주입구 위로 옮긴 뒤 마우스를 누르고 있으면 쇳물이 흘러듭니다. 다른 곳에 부으면 쏟아져 감점됩니다.',
    progress: ui.fill,
    stats: `채움 ${ui.fill}% · 국자 ${Math.round(ui.metal * 100)}% · 흘린 시간 ${ui.spill.toFixed(1)}초`,
  }));

  return (
    <group>
      <group position={[0, TABLE_Y, 0]}>
        <SandBlock />
        <mesh geometry={geo} material={mat} receiveShadow castShadow />
        {/* sprue marker */}
        <mesh position={[field.sprue[0], 0.03, field.sprue[1]]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.14, 0.2, 32]} />
          <meshBasicMaterial color="#4da3ff" transparent opacity={0.9} side={THREE.DoubleSide} />
        </mesh>
        {/* portable crucible with molten metal */}
        <group position={[POT[0], 0, POT[1]]}>
          <mesh position={[0, 0.2, 0]} castShadow><cylinderGeometry args={[0.38, 0.28, 0.45, 24, 1, true]} /><meshStandardMaterial color="#2a2522" side={THREE.DoubleSide} roughness={0.9} /></mesh>
          <mesh position={[0, 0.38, 0]}><cylinderGeometry args={[0.34, 0.34, 0.03, 24]} /><meshStandardMaterial color="#ffb25a" emissive="#ff6a1a" emissiveIntensity={2.6} toneMapped={false} /></mesh>
          <pointLight position={[0, 0.8, 0]} color="#ff7a2a" intensity={9} distance={4} />
        </group>
        {/* ladle */}
        <group ref={ladle} position={[0, 0.62, 0]}>
          <mesh position={[0, 0.02, 0]} castShadow><sphereGeometry args={[0.15, 18, 12, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2]} /><meshStandardMaterial color="#33363b" metalness={0.8} roughness={0.4} side={THREE.DoubleSide} /></mesh>
          <mesh position={[0, 0.03, 0]}><cylinderGeometry args={[0.135, 0.135, 0.01, 18]} /><meshStandardMaterial color="#ffb25a" emissive="#ff6a1a" emissiveIntensity={ui.metal > 0.05 ? 2.4 : 0} toneMapped={false} /></mesh>
          <mesh position={[0.7, 0.35, 0]} rotation={[0, 0, 0.4]} castShadow><cylinderGeometry args={[0.025, 0.025, 1.5, 8]} /><meshStandardMaterial color="#6a4a2a" roughness={0.8} /></mesh>
        </group>
        <mesh ref={stream} visible={false}>
          <cylinderGeometry args={[0.025, 0.035, 0.6, 8]} />
          <meshStandardMaterial color="#ffc070" emissive="#ff7a20" emissiveIntensity={3} toneMapped={false} />
        </mesh>
        <CatchPlane
          y={0.5}
          onDown={(x, z) => { st.current.x = x; st.current.z = z; st.current.down = true; setDown(true); }}
          onMove={(x, z) => { st.current.x = x; st.current.z = z; }}
          onUp={() => { st.current.down = false; setDown(false); }}
        />
      </group>
      <Particles ref={sparks} max={300} additive />
    </group>
  );
}

// ═════════════════════════════════════════════════════════════════════════
// 4. COOL (blower) + SHAKEOUT (brush the sand off)
// ═════════════════════════════════════════════════════════════════════════
function CoolStage({ ctx }: { ctx: Ctx }) {
  const field = useMemo(() => getMould(ctx.unitKey, ctx.shape, ctx.mold?.quality ?? null), [ctx.unitKey, ctx.shape, ctx.mold]);
  const cool = useMemo(() => newCool(field), [field]);
  const relief = useMemo(() => pieceHeights(field), [field]);
  const cover = useMemo(() => new Float32Array(NV), []);
  const geo = useMemo(makeHeightGeometry, []);
  const mat = useMemo(makeHeightMaterial, []);
  const wind = useRef<ParticleAPI>(null);
  const dust = useRef<ParticleAPI>(null);
  const tool = useRef<THREE.Group>(null);
  const s = useRef({
    phase: 'cool' as 'cool' | 'shake', x: 0, z: 0, down: false, last: null as [number, number] | null,
    stress: 0, cracks: 0, dirty: true, tick: 0, finished: false, errors: [] as string[],
  });
  const [ui, setUi] = useState({ phase: 'cool' as 'cool' | 'shake', p: 0, cracks: 0, hot: 1 });
  const [down, setDown] = useState(false);
  const setGuide = useGameStore((g) => g.setGuide);
  const fadeGuide = useGameStore((g) => g.fadeGuide);
  const guideKeyRef = useRef<string | null>(null);

  useEffect(() => { shotTop(O, TABLE_Y, 6.2, 0, 0, true); }, []);
  useEffect(() => () => setGuide(null), [setGuide]);
  useWindowUp(down, () => { s.current.down = false; s.current.last = null; setDown(false); });

  const repaint = () => {
    const shake = s.current.phase === 'shake';
    paintHeight(
      geo,
      (k) => {
        if (!field.mask[k]) return -CARVE_DEPTH * field.d[k];
        return shake ? lerp(-0.03, relief[k] * 0.14 - 0.03, cover[k]) : -0.03;
      },
      (k, out) => {
        sandColour(k, out);
        if (field.mask[k]) {
          const t = cool.t[k];
          if (!shake) colourOfHeat(t, out);
          else {
            const m: [number, number, number] = [0, 0, 0];
            colourOfHeat(t, m);
            const g = grain(k);
            out[0] = lerp(0.2 * g, m[0], cover[k]); out[1] = lerp(0.13 * g, m[1], cover[k]); out[2] = lerp(0.06 * g, m[2], cover[k]);
            if (cover[k] < 0.5) { out[0] = lerp(out[0], SAND_RGB[0] * g, 1 - cover[k] * 2); out[1] = lerp(out[1], SAND_RGB[1] * g, 1 - cover[k] * 2); out[2] = lerp(out[2], SAND_RGB[2] * g, 1 - cover[k] * 2); }
          }
        } else if (field.d[k] > 0.04) {
          const b = clamp01(field.d[k] * 1.4); out[0] = lerp(out[0], 0.2, b); out[1] = lerp(out[1], 0.13, b); out[2] = lerp(out[2], 0.06, b);
        }
      },
      (k) => (field.mask[k] && s.current.phase === 'cool' ? Math.pow(cool.t[k], 1.4) : 0),
    );
  };

  const moveTo = (x: number, z: number) => {
    const st = s.current;
    st.x = x; st.z = z;
    if (tool.current) tool.current.position.set(x, 0.35, z);
    if (st.phase === 'shake' && st.down) {
      if (!st.last) { st.last = [x, z]; return; }
      const dist = Math.hypot(x - st.last[0], z - st.last[1]);
      if (dist > 0.004) {
        polish(cover, field, x, z, dist, 0.13, 4.5);
        st.last = [x, z];
        st.dirty = true;
        sfx.scrape(Math.min(1, dist * 16));
        dust.current?.emit([x, TABLE_Y + 0.08, z], 2, { speed: 0.6, spread: 0.8, gravity: -1.5, life: 0.6, size: 0.08, grow: 1.8, color: [0.78, 0.66, 0.46] });
      }
    }
  };

  useFrame((_, dt0) => {
    const dt = Math.min(dt0, 0.05);
    const st = s.current;
    st.tick++;
    if (st.phase === 'cool') {
      coolTick(cool, field, dt);
      if (st.down) {
        const stress = blow(cool, field, st.x, st.z, dt);
        st.stress += stress;
        if (st.tick % 3 === 0) {
          wind.current?.emit([st.x, TABLE_Y + 0.35, st.z], 2, { speed: 0.8, spread: 0.5, gravity: -0.5, life: 0.5, size: 0.14, grow: 1.6, color: [0.7, 0.85, 1], dir: [0, -0.4, 0] });
        }
        if (st.stress > 0.9) {
          st.stress = 0;
          st.cracks++;
          st.errors.push('급냉으로 주물에 균열이 생김');
          sfx.crack();
        }
      }
      st.dirty = true;
      const p = coolProgress(cool, field);
      if (p >= 0.97) { st.phase = 'shake'; st.down = false; st.last = null; setDown(false); sfx.ok(); st.dirty = true; }
    } else if (!st.finished && polishProgress(cover, field) >= 0.92) {
      st.finished = true;
      sfx.done();
      const q = Math.max(30, 100 - st.cracks * 14);
      window.setTimeout(() => ctx.done(q, st.errors.slice()), 700);
    }
    if (st.dirty && st.tick % 3 === 0) { repaint(); st.dirty = false; }
    if (st.tick % 8 === 0) {
      const p = st.phase === 'cool' ? coolProgress(cool, field) : polishProgress(cover, field);
      let hot = 0;
      for (let k = 0; k < NV; k += 11) if (field.mask[k] && cool.t[k] > hot) hot = cool.t[k];
      const nx = { phase: st.phase, p: Math.round(p * 100), cracks: st.cracks, hot: Math.round(hot * 10) / 10 };
      setUi((q) => (q.phase !== nx.phase || q.p !== nx.p || q.cracks !== nx.cracks || q.hot !== nx.hot ? nx : q));
    }
    // guide: hottest mask cell while cooling, least-covered while shaking
    if (st.tick % 25 === 0 && !st.finished) {
      let bestK = -1; let bestScore = -1;
      for (let k = 0; k < NV; k += 3) {
        if (!field.mask[k]) continue;
        const score = st.phase === 'cool' ? cool.t[k] : (1 - cover[k]);
        if (score > bestScore) { bestScore = score; bestK = k; }
      }
      if (bestK >= 0 && bestScore > 0.05) {
        const i = bestK % (GW + 1);
        const j = Math.floor(bestK / (GW + 1));
        const bI = Math.floor(i / 10);
        const bJ = Math.floor(j / 10);
        const key = `${st.phase}-${bI}-${bJ}`;
        if (key !== guideKeyRef.current) {
          if (guideKeyRef.current) fadeGuide(guideKeyRef.current);
          guideKeyRef.current = key;
          setGuide({ pos: [O[0] + vx(i), TABLE_Y + 0.1, O[2] + vz(j)], key, label: st.phase === 'cool' ? '여기를 식혀요' : '여기를 털어요' });
        }
      } else if (guideKeyRef.current) {
        fadeGuide(guideKeyRef.current);
        guideKeyRef.current = null;
      }
    }
  });

  useHud(`cool-${ui.phase}-${ui.p}-${ui.cracks}`, () => ({
    title: ctx.title,
    phase: ui.phase === 'cool' ? '4/5 · 송풍 냉각' : '4/5 · 형틀 해체 (모래 털기)',
    hint: ui.phase === 'cool'
      ? '마우스를 누른 채 송풍기를 천천히 골고루 움직이세요. 한 곳만 급하게 식히면 균열이 갑니다.'
      : '붓으로 주물 위의 모래를 문질러 털어내세요.',
    progress: ui.p,
    stats: ui.phase === 'cool' ? `냉각 ${ui.p}% · 균열 ${ui.cracks}회` : `모래 제거 ${ui.p}% (92% 이상 필요)`,
  }));

  return (
    <group>
      <group position={[0, TABLE_Y, 0]}>
        <SandBlock />
        <mesh geometry={geo} material={mat} receiveShadow castShadow />
        <group ref={tool} position={[0, 0.35, 0]}>
          {ui.phase === 'cool' ? (
            <group rotation={[0.4, 0, 0]}>
              <mesh position={[0, 0.2, 0]} castShadow><cylinderGeometry args={[0.16, 0.22, 0.5, 18]} /><meshStandardMaterial color="#2f6fa8" roughness={0.4} metalness={0.4} /></mesh>
              <mesh position={[0, 0.0, 0]}><cylinderGeometry args={[0.1, 0.16, 0.14, 18]} /><meshStandardMaterial color="#222" /></mesh>
              <mesh position={[0, 0.55, 0.15]} rotation={[0.6, 0, 0]}><cylinderGeometry args={[0.04, 0.04, 0.5, 8]} /><meshStandardMaterial color="#222" /></mesh>
            </group>
          ) : (
            <group rotation={[0.3, 0, 0]}>
              <mesh position={[0, 0.02, 0]} castShadow><boxGeometry args={[0.36, 0.1, 0.12]} /><meshStandardMaterial color="#c7a15a" roughness={0.95} /></mesh>
              <mesh position={[0, 0.3, 0]} castShadow><cylinderGeometry args={[0.03, 0.03, 0.5, 8]} /><meshStandardMaterial color="#6a4a2a" roughness={0.8} /></mesh>
            </group>
          )}
        </group>
        <CatchPlane
          y={0.3}
          onDown={(x, z) => { s.current.down = true; s.current.last = [x, z]; s.current.x = x; s.current.z = z; setDown(true); }}
          onMove={moveTo}
          onUp={() => { s.current.down = false; s.current.last = null; setDown(false); }}
        />
      </group>
      <Particles ref={wind} max={160} additive />
      <Particles ref={dust} max={240} additive={false} />
    </group>
  );
}

// ═════════════════════════════════════════════════════════════════════════
// 5. FINISH (quench in the tank, then polish)
// ═════════════════════════════════════════════════════════════════════════
const PIECE_REST: V3 = [0, TABLE_Y + 0.06, 0];

function FinishStage({ ctx }: { ctx: Ctx }) {
  const field = useMemo(() => getMould(ctx.unitKey, ctx.shape, ctx.mold?.quality ?? null), [ctx.unitKey, ctx.shape, ctx.mold]);
  const relief = useMemo(() => pieceHeights(field), [field]);
  const cover = useMemo(() => new Float32Array(NV), []);
  const geo = useMemo(makeHeightGeometry, []);
  const mat = useMemo(() => { const m = makeHeightMaterial(); m.side = THREE.DoubleSide; m.metalness = 0.55; m.roughness = 0.45; return m; }, []);
  const emptyGeo = useMemo(makeHeightGeometry, []);
  const emptyMat = useMemo(makeHeightMaterial, []);
  const piece = useRef<THREE.Group>(null);
  const steam = useRef<ParticleAPI>(null);
  const dust = useRef<ParticleAPI>(null);
  const tool = useRef<THREE.Group>(null);
  const s = useRef({
    phase: 'quench' as 'quench' | 'polish', grab: false, x: 0, z: 0, dip: 0, dirty: true, tick: 0, hissed: false, finished: false,
    last: null as [number, number] | null, down: false, early: 0,
    // dropped=true means the casting is in the tank on its own (the player
    // let go of the tongs). pieceY lerps down to the submerged position so
    // it visibly falls into the water.
    dropped: false, pieceY: PIECE_REST[1],
  });
  const [ui, setUi] = useState({ phase: 'quench' as 'quench' | 'polish', p: 0, over: false });
  const [dragging, setDragging] = useState(false);
  const setGuide = useGameStore((g) => g.setGuide);
  const fadeGuide = useGameStore((g) => g.fadeGuide);
  const guideKeyRef = useRef<string | null>(null);

  useEffect(() => { shotTop(O, TABLE_Y, 7.2, 2.1, 0.7, true); }, []);
  useEffect(() => () => setGuide(null), [setGuide]);
  useWindowUp(dragging, () => {
    const st = s.current;
    const wasGrab = st.grab;
    st.grab = false; st.down = false; st.last = null; setDragging(false);
    // same 떨어뜨리기 behavior for pointer-up events that happen outside the catch plane
    if (st.phase === 'quench' && piece.current && wasGrab) {
      if (inTank(st.x, st.z)) {
        st.dropped = true;
        piece.current.position.x = TANK_POS[0]; piece.current.position.z = TANK_POS[2];
      } else if (st.dip < 1.6) {
        piece.current.position.set(PIECE_REST[0], PIECE_REST[1], PIECE_REST[2]);
        st.pieceY = PIECE_REST[1];
        st.dip = 0;
      }
    }
  });

  // the piece shape = cavity mask + anything the player over-carved into
  // the sand. relief[] already encodes both, so we trust it for every
  // "does this cell have metal here" check.
  const paintPiece = () => paintHeight(
    geo,
    (k) => (relief[k] > 0.08 ? relief[k] * 0.14 : -0.02),
    (k, out) => {
      if (relief[k] <= 0.08) { out[0] = out[1] = out[2] = 0.3; return; }
      const sh = s.current.phase === 'polish' ? cover[k] : 0;
      const base = lerp(0.36, 0.82, sh);
      const g = grain(k) * 0.12 + 0.94;
      out[0] = base * g; out[1] = (base + 0.01) * g; out[2] = (base + 0.04) * g;
    },
    (k) => (relief[k] > 0.08 ? 0 : -1),
  );
  const paintEmpty = () => paintHeight(
    emptyGeo,
    (k) => -CARVE_DEPTH * (field.mask[k] ? 1 : field.d[k]),
    (k, out) => { sandColour(k, out); if (field.mask[k]) { const g = grain(k); out[0] = 0.2 * g; out[1] = 0.13 * g; out[2] = 0.06 * g; } },
  );

  useEffect(() => { paintPiece(); paintEmpty(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const inTank = (x: number, z: number) => Math.abs(x - TANK_POS[0]) < 0.9 && Math.abs(z - TANK_POS[2]) < 0.65;

  // "떨어뜨리기" — once the player releases the tongs over the tank, the
  // casting falls into the water on its own and stays submerged while the
  // 1.6s hold timer runs. Pulling it out early means grabbing again before
  // the timer fills.
  const onMove = (x: number, z: number) => {
    const st = s.current;
    st.x = x; st.z = z;
    if (st.phase === 'quench' && st.grab && piece.current) {
      const t = inTank(x, z);
      piece.current.position.set(x, t ? 1.3 : 1.5, z);
    }
    if (st.phase === 'polish') {
      if (tool.current) tool.current.position.set(x, TABLE_Y + 0.3, z);
      if (st.down) {
        if (!st.last) { st.last = [x, z]; return; }
        const dist = Math.hypot(x - st.last[0], z - st.last[1]);
        if (dist > 0.004) {
          polish(cover, field, x, z, dist, 0.11, 4);
          st.last = [x, z];
          st.dirty = true;
          sfx.scrape(Math.min(1, dist * 16));
          dust.current?.emit([x, TABLE_Y + 0.12, z], 2, { speed: 1.4, spread: 0.8, gravity: -3, life: 0.35, size: 0.04, color: [1, 0.85, 0.5] });
        }
      }
    }
  };

  useFrame((_, dt0) => {
    const dt = Math.min(dt0, 0.05);
    const st = s.current;
    st.tick++;
    if (st.phase === 'quench') {
      // in-tank = currently held in tank OR already dropped into tank
      const inside = inTank(st.x, st.z);
      const t = (st.grab && inside) || st.dropped;
      // falling animation: when dropped, lerp Y down to the submerged level;
      // when grabbed over the tank, lerp to the just-above-water level
      if (piece.current) {
        const tgt = st.dropped ? 0.75 : st.grab ? (inside ? 1.3 : 1.5) : PIECE_REST[1];
        st.pieceY += (tgt - st.pieceY) * Math.min(1, dt * (st.dropped ? 8 : 10));
        piece.current.position.y = st.pieceY;
      }
      if (t) {
        if (!st.hissed) { st.hissed = true; sfx.hiss(); }
        st.dip += dt;
        if (st.tick % 2 === 0) steam.current?.emit([st.x, 1.0, st.z], 2, { speed: 0.7, spread: 0.5, gravity: 0.5, life: 1.4, size: 0.2, grow: 3, color: [0.85, 0.9, 0.95], dir: [0, 1, 0] });
      } else if (st.hissed && st.dip < 1.6 && !st.dropped) { st.hissed = false; st.early++; }
      if (st.dip >= 1.6) {
        st.phase = 'polish';
        st.grab = false;
        st.dropped = false;
        setDragging(false);
        if (piece.current) piece.current.position.set(PIECE_REST[0], PIECE_REST[1], PIECE_REST[2]);
        st.pieceY = PIECE_REST[1];
        st.dirty = true;
        sfx.ok();
        shotTop(O, TABLE_Y, 6.2, 0, 0);
      }
    } else if (!st.finished && polishProgress(cover, field) >= 0.9) {
      st.finished = true;
      sfx.done();
      const q = Math.max(40, Math.round(100 - st.early * 4));
      window.setTimeout(() => ctx.done(q, st.early > 2 ? ['담금질 중 수조에서 자주 꺼내 균일하지 못함'] : []), 700);
    }
    if (st.dirty && st.tick % 3 === 0) { paintPiece(); st.dirty = false; }
    if (st.tick % 8 === 0) {
      const p = st.phase === 'quench' ? Math.min(1, st.dip / 1.6) : polishProgress(cover, field);
      const nx = { phase: st.phase, p: Math.round(p * 100), over: st.grab && inTank(st.x, st.z) };
      setUi((q) => (q.phase !== nx.phase || q.p !== nx.p || q.over !== nx.over ? nx : q));
    }
    if (st.tick % 25 === 0 && !st.finished) {
      let target: { pos: [number, number, number]; key: string; label: string } | null = null;
      if (st.phase === 'quench') {
        if (!st.grab) {
          target = { pos: [O[0] + PIECE_REST[0], PIECE_REST[1] + 0.3, O[2] + PIECE_REST[2]], key: 'fin-piece', label: '집게로 잡기' };
        } else {
          target = { pos: [O[0] + TANK_POS[0], 1.2, O[2] + TANK_POS[2]], key: 'fin-tank', label: '수조로' };
        }
      } else {
        let bestK = -1; let bestScore = -1;
        for (let k = 0; k < NV; k += 4) {
          if (!field.mask[k]) continue;
          const score = 1 - cover[k];
          if (score > bestScore) { bestScore = score; bestK = k; }
        }
        if (bestK >= 0 && bestScore > 0.08) {
          const i = bestK % (GW + 1);
          const j = Math.floor(bestK / (GW + 1));
          const bI = Math.floor(i / 10);
          const bJ = Math.floor(j / 10);
          target = { pos: [O[0] + vx(i), TABLE_Y + 0.25, O[2] + vz(j)], key: `polish-${bI}-${bJ}`, label: '여기를 연마' };
        }
      }
      if (!target) {
        if (guideKeyRef.current) { fadeGuide(guideKeyRef.current); guideKeyRef.current = null; }
      } else if (target.key !== guideKeyRef.current) {
        if (guideKeyRef.current) fadeGuide(guideKeyRef.current);
        guideKeyRef.current = target.key;
        setGuide({ pos: target.pos, key: target.key, label: target.label });
      }
    }
  });

  useHud(`fin-${ui.phase}-${ui.p}-${ui.over}`, () => ({
    title: ctx.title,
    phase: ui.phase === 'quench' ? '5/5 · 담금질' : '5/5 · 표면 연마',
    hint: ui.phase === 'quench'
      ? '집게로 주물을 잡아 오른쪽 수조 위까지 옮긴 뒤 마우스를 놓아 떨어뜨리세요. 수조 안에서 1.6초 유지되면 다음으로 넘어갑니다.'
      : '줄/연마 도구로 주물 표면을 문질러 반짝이게 하세요. 구석구석 닦을수록 밝아집니다.',
    progress: ui.p,
    stats: ui.phase === 'quench' ? `담금 ${ui.p}%${ui.over ? ' · 수조 안' : ''}` : `연마 ${ui.p}% (90% 이상 필요)`,
  }));

  const polishing = ui.phase === 'polish';
  return (
    <group>
      {/* the sand block with the empty mould stays on the table during quench */}
      {!polishing && (
        <group position={[0, TABLE_Y, 0]}>
          <SandBlock />
          <mesh geometry={emptyGeo} material={emptyMat} receiveShadow />
        </group>
      )}
      {polishing && (
        <mesh position={[0, TABLE_Y + 0.02, 0]} receiveShadow castShadow><boxGeometry args={[BLOCK_W, 0.04, BLOCK_D]} /><meshStandardMaterial color="#4a4d55" metalness={0.8} roughness={0.35} /></mesh>
      )}
      {/* the casting itself (tongs carry it) */}
      <group
        ref={piece}
        position={PIECE_REST}
        onPointerDown={(e: ThreeEvent<PointerEvent>) => {
          if (s.current.phase !== 'quench') return;
          e.stopPropagation();
          s.current.grab = true;
          setDragging(true);
          piece.current?.position.setY(1.5);
        }}
      >
        <mesh geometry={geo} material={mat} castShadow receiveShadow />
        {!polishing && (
          <mesh position={[0.9, 0.5, 0]} rotation={[0, 0, -0.6]}><boxGeometry args={[1.6, 0.04, 0.05]} /><meshStandardMaterial color="#888" metalness={0.9} roughness={0.3} /></mesh>
        )}
      </group>
      {polishing && (
        <group ref={tool} position={[0, TABLE_Y + 0.3, 0]} rotation={[0, 0, 0.3]}>
          <mesh position={[0.05, 0, 0]} castShadow><boxGeometry args={[0.42, 0.05, 0.1]} /><meshStandardMaterial color="#8a8a90" metalness={0.8} roughness={0.55} /></mesh>
          <mesh position={[0.4, 0.04, 0]} castShadow><boxGeometry args={[0.2, 0.08, 0.08]} /><meshStandardMaterial color="#7a4a1a" roughness={0.8} /></mesh>
        </group>
      )}
      <CatchPlane
        y={1.2}
        w={16}
        d={12}
        onDown={(x, z) => { if (s.current.phase === 'polish') { s.current.down = true; s.current.last = [x, z]; setDragging(true); } }}
        onMove={onMove}
        onUp={() => {
          const st = s.current;
          const wasGrab = st.grab;
          st.grab = false; st.down = false; st.last = null; setDragging(false);
          if (st.phase === 'quench' && piece.current && wasGrab) {
            if (inTank(st.x, st.z)) {
              // released over tank → "떨어뜨렸다". Let it fall in and stay.
              st.dropped = true;
              // snap horizontally to tank centre so it actually lands in it
              piece.current.position.x = TANK_POS[0]; piece.current.position.z = TANK_POS[2];
            } else if (st.dip < 1.6) {
              // released outside the tank → tongs put it back on the bench
              piece.current.position.set(PIECE_REST[0], PIECE_REST[1], PIECE_REST[2]);
              st.pieceY = PIECE_REST[1];
              st.dip = 0;
            }
          }
        }}
      />
      <Particles ref={steam} max={200} additive={false} />
      <Particles ref={dust} max={160} additive />
    </group>
  );
}

// ═════════════════════════════════════════════════════════════════════════

export default function CraftRig({
  craftId, label, spec, unitKey, mold, onComplete,
}: {
  craftId: string;
  label: string;
  spec: CastSpec;
  unitKey: string;
  mold: { quality: number; errors: string[] } | null;
  onComplete: (quality: number, errors: string[], extra?: { carveQuality?: number }) => void;
}) {
  const doneRef = useRef(onComplete);
  doneRef.current = onComplete;
  const called = useRef(false);
  const ctx: Ctx = {
    shape: spec.shape,
    unitKey,
    ingots: spec.ingots,
    mold,
    title: label,
    done: (q, e, x) => {
      if (called.current) return;
      called.current = true;
      doneRef.current(q, e, x);
    },
  };
  return (
    <group key={craftId} position={O}>
      {spec.stage === 'carve' && <CarveStage ctx={ctx} />}
      {spec.stage === 'melt' && <MeltStage ctx={ctx} />}
      {spec.stage === 'pour' && <PourStage ctx={ctx} />}
      {spec.stage === 'cool' && <CoolStage ctx={ctx} />}
      {spec.stage === 'finish' && <FinishStage ctx={ctx} />}
    </group>
  );
}
// r5b
// r5c
// r5d
