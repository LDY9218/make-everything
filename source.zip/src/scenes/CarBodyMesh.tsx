import { useMemo, useRef, type MutableRefObject } from 'react';
import { useFrame } from '@react-three/fiber';
import { RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import { toCreasedNormals } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { CarModel } from '../types';
import { getCarLayout, type CarLayout, type DriveVisual } from './carLayout';
import CarInterior from './CarInterior';

/**
 * Procedural car built from the model's silhouette numbers (see
 * carLayout.ts): separate lower-body, door slabs, greenhouse glass, roof,
 * pillars, lathe-turned tires, spoked rims, brake discs and calipers,
 * lights, mirrors, grille, exhaust... In the workshop it renders ghosted;
 * in the drive scene it is solid and animated through `driveRef`.
 */

const Y_AXIS = new THREE.Vector3(0, 1, 0);

function profileGeometry(build: (s: THREE.Shape) => void, width: number, bevel = 0.035): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  build(shape);
  const depth = Math.max(0.01, width - bevel * 2);
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 5, curveSegments: 20, steps: 1,
  });
  geo.translate(0, 0, -depth / 2);
  geo.rotateY(-Math.PI / 2); // shape x → world z (forward), extrusion → world x
  geo.deleteAttribute('uv');
  return toCreasedNormals(geo, Math.PI / 4);
}

/** a box whose long axis runs from a to b */
function Beam({ a, b, t = 0.06, d = 0.06, material }: { a: [number, number, number]; b: [number, number, number]; t?: number; d?: number; material: THREE.Material }) {
  const { pos, quat, len } = useMemo(() => {
    const va = new THREE.Vector3(...a);
    const vb = new THREE.Vector3(...b);
    const dir = vb.clone().sub(va);
    const l = dir.length();
    return {
      pos: va.clone().add(vb).multiplyScalar(0.5),
      quat: new THREE.Quaternion().setFromUnitVectors(Y_AXIS, dir.normalize()),
      len: l,
    };
  }, [a, b]);
  return (
    <mesh position={pos} quaternion={quat} material={material} castShadow>
      <boxGeometry args={[t, len, d]} />
    </mesh>
  );
}

// ── wheels ───────────────────────────────────────────────────────────────

function useTireGeometry(wheelR: number, tireW: number, rimR: number) {
  return useMemo(() => {
    const hw = tireW / 2;
    const pts: THREE.Vector2[] = [];
    const add = (r: number, y: number) => pts.push(new THREE.Vector2(r, y));
    add(rimR * 0.98, -hw * 0.86);
    add(rimR + (wheelR - rimR) * 0.35, -hw * 0.98);
    add(wheelR * 0.955, -hw);
    add(wheelR * 0.99, -hw * 0.82);
    add(wheelR, -hw * 0.5);
    add(wheelR, hw * 0.5);
    add(wheelR * 0.99, hw * 0.82);
    add(wheelR * 0.955, hw);
    add(rimR + (wheelR - rimR) * 0.35, hw * 0.98);
    add(rimR * 0.98, hw * 0.86);
    const geo = new THREE.LatheGeometry(pts, 56);
    geo.rotateX(Math.PI / 2); // lathe axis Y → wheel axis Z
    return toCreasedNormals(geo, Math.PI / 3);
  }, [wheelR, tireW, rimR]);
}

function Wheel({
  layout, x, z, side, front, driveRef, ghost,
}: {
  layout: CarLayout; x: number; z: number; side: 1 | -1; front: boolean;
  driveRef?: MutableRefObject<DriveVisual>; ghost?: boolean;
}) {
  const { wheelR, tireW, rimR } = layout;
  const steerRef = useRef<THREE.Group>(null);
  const spinRef = useRef<THREE.Group>(null);
  const tireGeo = useTireGeometry(wheelR, tireW, rimR);
  const spokes = layout.bodyType === 'hypercar' || layout.bodyType === 'sportscar' ? 10 : 5;
  const faceZ = tireW * 0.34;

  useFrame(() => {
    const dv = driveRef?.current;
    if (!dv) return;
    if (steerRef.current && front) steerRef.current.rotation.y = dv.steer * 0.5;
    if (spinRef.current) spinRef.current.rotation.z = dv.wheelSpin * side;
  });

  const tireMat = (
    <meshStandardMaterial color={ghost ? '#444' : '#101010'} roughness={0.88} metalness={0.02} transparent={!!ghost} opacity={ghost ? 0.6 : 1} />
  );

  return (
    <group position={[x, wheelR, z]}>
      <group ref={steerRef}>
        <group rotation={[0, side * (Math.PI / 2), 0]}>
          <group ref={spinRef}>
            <mesh geometry={tireGeo} castShadow receiveShadow>{tireMat}</mesh>
            {!ghost && (
              <>
                {/* barrel */}
                <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
                  <cylinderGeometry args={[rimR, rimR, tireW * 0.82, 40, 1, true]} />
                  <meshStandardMaterial color="#9ea2a8" metalness={0.95} roughness={0.22} side={THREE.DoubleSide} />
                </mesh>
                {/* face: spokes */}
                {Array.from({ length: spokes }).map((_, i) => (
                  <group key={i} rotation={[0, 0, (i / spokes) * Math.PI * 2]}>
                    <mesh position={[rimR * 0.5, 0, faceZ]} castShadow>
                      <boxGeometry args={[rimR * 0.82, rimR * (spokes > 5 ? 0.11 : 0.2), 0.028]} />
                      <meshStandardMaterial color="#c4c8ce" metalness={0.95} roughness={0.18} />
                    </mesh>
                  </group>
                ))}
                {/* hub + cap + lug nuts */}
                <mesh position={[0, 0, faceZ]} rotation={[Math.PI / 2, 0, 0]}>
                  <cylinderGeometry args={[rimR * 0.26, rimR * 0.26, 0.04, 28]} />
                  <meshStandardMaterial color="#b8bcc2" metalness={0.95} roughness={0.2} />
                </mesh>
                <mesh position={[0, 0, faceZ + 0.025]} rotation={[Math.PI / 2, 0, 0]}>
                  <cylinderGeometry args={[rimR * 0.12, rimR * 0.12, 0.02, 20]} />
                  <meshStandardMaterial color="#202226" metalness={0.8} roughness={0.3} />
                </mesh>
                {Array.from({ length: 5 }).map((_, i) => {
                  const a = (i / 5) * Math.PI * 2;
                  return (
                    <mesh key={i} position={[Math.cos(a) * rimR * 0.2, Math.sin(a) * rimR * 0.2, faceZ + 0.02]} rotation={[Math.PI / 2, 0, 0]}>
                      <cylinderGeometry args={[0.012, 0.012, 0.02, 6]} />
                      <meshStandardMaterial color="#8d9096" metalness={1} roughness={0.2} />
                    </mesh>
                  );
                })}
                {/* brake disc */}
                <mesh position={[0, 0, -tireW * 0.18]} rotation={[Math.PI / 2, 0, 0]}>
                  <cylinderGeometry args={[rimR * 0.9, rimR * 0.9, 0.03, 40]} />
                  <meshStandardMaterial color="#5c5f65" metalness={0.9} roughness={0.35} />
                </mesh>
                <mesh position={[0, 0, -tireW * 0.18 + 0.016]} rotation={[Math.PI / 2, 0, 0]}>
                  <cylinderGeometry args={[rimR * 0.34, rimR * 0.34, 0.012, 24]} />
                  <meshStandardMaterial color="#2c2e32" metalness={0.8} roughness={0.5} />
                </mesh>
              </>
            )}
          </group>
          {/* caliper doesn't spin */}
          {!ghost && (
            <mesh position={[side * rimR * 0.62, rimR * 0.1, -tireW * 0.18]} castShadow>
              <boxGeometry args={[rimR * 0.34, rimR * 0.62, 0.11]} />
              <meshStandardMaterial color="#b3261e" metalness={0.5} roughness={0.35} />
            </mesh>
          )}
        </group>
      </group>
    </group>
  );
}

// ── the car ──────────────────────────────────────────────────────────────

export default function CarBodyMesh({
  model, ghost, driveRef, interior = false, paintColor,
}: {
  model: CarModel; ghost?: boolean; driveRef?: MutableRefObject<DriveVisual>; interior?: boolean; paintColor?: string;
}) {
  const lay = useMemo(() => getCarLayout(model), [model]);
  const { L, W, H, gc, beltY, zc, zrf, zrr, zt, wheelR, trackX, axleF, axleR, doorT } = lay;
  const color = paintColor ?? model.accentColor;

  const geos = useMemo(() => {
    const front = profileGeometry((s) => {
      s.moveTo(zc, gc);
      s.lineTo(zc, beltY);
      s.quadraticCurveTo((zc + L / 2) / 2, beltY * 1.005, L / 2 - 0.3, beltY * 0.88);
      s.quadraticCurveTo(L / 2 - 0.02, beltY * 0.82, L / 2, beltY * 0.6);
      s.lineTo(L / 2, gc + 0.14);
      s.quadraticCurveTo(L / 2, gc, L / 2 - 0.16, gc);
      s.lineTo(zc, gc);
    }, W, 0.05);
    const rear = profileGeometry((s) => {
      s.moveTo(zt, gc);
      s.lineTo(zt, beltY * 0.985);
      s.quadraticCurveTo(-L / 2 + 0.35, beltY * 1.0, -L / 2 + 0.04, beltY * 0.9);
      s.quadraticCurveTo(-L / 2, beltY * 0.86, -L / 2, beltY * 0.66);
      s.lineTo(-L / 2, gc + 0.16);
      s.quadraticCurveTo(-L / 2, gc, -L / 2 + 0.18, gc);
      s.lineTo(zt, gc);
    }, W, 0.05);
    const glassHalf = W / 2 - 0.17;
    const glass = profileGeometry((s) => {
      s.moveTo(zc, beltY);
      s.lineTo(zrf, H - 0.045);
      s.lineTo(zrr, H - 0.045);
      s.lineTo(zt, beltY);
      s.lineTo(zc, beltY);
    }, glassHalf * 2, 0.012);
    return { front, rear, glass };
  }, [L, W, H, gc, beltY, zc, zrf, zrr, zt]);

  const paint = useMemo(() => new THREE.MeshPhysicalMaterial({
    color,
    metalness: ghost ? 0.1 : 0.62,
    roughness: ghost ? 0.4 : 0.28,
    clearcoat: ghost ? 0 : 1,
    clearcoatRoughness: 0.12,
    envMapIntensity: 1.25,
    opacity: ghost ? 0.2 : 1,
    transparent: !!ghost,
    depthWrite: !ghost,
  }), [color, ghost]);

  const glassMat = useMemo(() => new THREE.MeshPhysicalMaterial({
    color: '#0b1218', metalness: 0.15, roughness: 0.04, transmission: 0, opacity: ghost ? 0.12 : 0.42,
    transparent: true, envMapIntensity: 2.2, depthWrite: false,
  }), [ghost]);
  const darkMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#0d0e10', roughness: 0.55, metalness: 0.3 }), []);
  const trimMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#16181b', roughness: 0.4, metalness: 0.6 }), []);
  const chromeMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#d4d7dc', roughness: 0.12, metalness: 1 }), []);

  const lights = useMemo(() => ({
    head: new THREE.MeshStandardMaterial({ color: '#e8f0f8', emissive: new THREE.Color('#fff8e0'), emissiveIntensity: 0.04, roughness: 0.08, metalness: 0.3, toneMapped: false }),
    tail: new THREE.MeshStandardMaterial({ color: '#7a0d0d', emissive: new THREE.Color('#ff1a1a'), emissiveIntensity: 0.25, roughness: 0.2, metalness: 0.2, toneMapped: false }),
    rev: new THREE.MeshStandardMaterial({ color: '#f4f4f4', emissive: new THREE.Color('#ffffff'), emissiveIntensity: 0, toneMapped: false }),
    indL: new THREE.MeshStandardMaterial({ color: '#ffb020', emissive: new THREE.Color('#ff9a00'), emissiveIntensity: 0, toneMapped: false }),
    indR: new THREE.MeshStandardMaterial({ color: '#ffb020', emissive: new THREE.Color('#ff9a00'), emissiveIntensity: 0, toneMapped: false }),
  }), []);

  useFrame((state) => {
    const dv = driveRef?.current;
    if (!dv) return;
    lights.head.emissiveIntensity = dv.headlights ? 5 : 0.04;
    lights.tail.emissiveIntensity = dv.braking ? 5 : dv.headlights ? 1.4 : 0.25;
    lights.rev.emissiveIntensity = dv.reversing ? 4 : 0;
    const blink = Math.sin(state.clock.elapsedTime * 9) > 0 ? 3.5 : 0;
    lights.indL.emissiveIntensity = dv.indicator === 1 ? blink : 0;
    lights.indR.emissiveIntensity = dv.indicator === -1 ? blink : 0;
  });

  const outer = W / 2 - 0.17;
  const midZ = (zc + zt) / 2;
  const doorLen = zc - zt;
  const sporty = lay.bodyType === 'hypercar' || lay.bodyType === 'sportscar';
  const noseY = beltY * 0.66;
  const tailY = beltY * 0.74;

  return (
    <group>
      {/* ── lower body ── */}
      <mesh geometry={geos.front} material={paint} castShadow receiveShadow />
      <mesh geometry={geos.rear} material={paint} castShadow receiveShadow />
      {[1, -1].map((sd) => (
        <mesh key={sd} position={[sd * (W / 2 - doorT / 2), (gc + beltY) / 2, midZ]} material={paint} castShadow receiveShadow>
          <boxGeometry args={[doorT, beltY - gc, doorLen]} />
        </mesh>
      ))}

      {/* ── greenhouse (glass, pillars, roof) ── */}
      <mesh geometry={geos.glass} material={glassMat} renderOrder={2} />
      {!ghost && (
        <>
          {[1, -1].map((sd) => (
            <group key={sd}>
              <Beam a={[sd * outer, beltY, zc]} b={[sd * outer, H - 0.045, zrf]} t={0.07} d={0.08} material={paint} />
              <Beam a={[sd * outer, beltY, zt]} b={[sd * outer, H - 0.045, zrr]} t={0.07} d={sporty ? 0.2 : 0.12} material={paint} />
              {!lay.twoDoor && (
                <Beam a={[sd * outer, beltY, (zrf + zrr) / 2]} b={[sd * outer, H - 0.045, (zrf + zrr) / 2]} t={0.07} d={0.08} material={paint} />
              )}
              {/* side-window frame rail */}
              <Beam a={[sd * outer, H - 0.045, zrf]} b={[sd * outer, H - 0.045, zrr]} t={0.07} d={0.05} material={paint} />
              {/* door shut-lines + handles */}
              <mesh position={[sd * (W / 2 + 0.004), (gc + beltY) / 2, midZ]} material={darkMat}>
                <boxGeometry args={[0.006, beltY - gc - 0.1, 0.012]} />
              </mesh>
              <mesh position={[sd * (W / 2 + 0.012), beltY - 0.13, midZ - doorLen * 0.18]} material={chromeMat}>
                <boxGeometry args={[0.02, 0.025, 0.16]} />
              </mesh>
              {/* side mirrors */}
              <group position={[sd * (W / 2 + 0.07), beltY + 0.05, zc - 0.22]}>
                <mesh material={paint} castShadow><boxGeometry args={[0.13, 0.09, 0.15]} /></mesh>
                <mesh position={[0, 0, -0.078]} material={glassMat}><boxGeometry args={[0.11, 0.075, 0.004]} /></mesh>
                <mesh position={[-sd * 0.05, -0.04, 0.02]} material={darkMat}><boxGeometry args={[0.07, 0.03, 0.05]} /></mesh>
              </group>
            </group>
          ))}
          {/* roof: rounded slab (bulges up from the belt line for a soft arch) */}
          <RoundedBox
            args={[outer * 2 + 0.07, 0.11, zrf - zrr + 0.1]}
            radius={0.055}
            smoothness={5}
            position={[0, H + 0.005, (zrf + zrr) / 2]}
            material={paint}
            castShadow
          />
          <mesh position={[0, H - 0.062, (zrf + zrr) / 2]}>
            <boxGeometry args={[outer * 2 - 0.02, 0.012, zrf - zrr + 0.02]} />
            <meshStandardMaterial color="#cdc6b8" roughness={0.95} />
          </mesh>
          {/* windshield/rear header (body colour lip) */}
          <Beam a={[-outer, H - 0.045, zrf]} b={[outer, H - 0.045, zrf]} t={0.05} d={0.07} material={paint} />
          <Beam a={[-outer, H - 0.045, zrr]} b={[outer, H - 0.045, zrr]} t={0.05} d={0.07} material={paint} />
        </>
      )}

      {/* ── hood / trunk details ── */}
      {!ghost && (
        <>
          {/* hood centre crease + cut line */}
          <mesh position={[0, beltY * 1.002 + 0.002, (zc + L / 2) / 2]} material={darkMat}>
            <boxGeometry args={[W - 0.1, 0.004, 0.008]} />
          </mesh>
          <mesh position={[0, beltY * 1.002 + 0.002, zc + 0.02]} material={darkMat}>
            <boxGeometry args={[W - 0.1, 0.004, 0.012]} />
          </mesh>
          {sporty && (
            <>
              {[-0.22, 0.22].map((x) => (
                <mesh key={x} position={[x, beltY * 0.985 + 0.01, zc + (L / 2 - zc) * 0.45]} material={darkMat}>
                  <boxGeometry args={[0.2, 0.01, 0.5]} />
                </mesh>
              ))}
            </>
          )}

          {/* grille + splitter + intakes */}
          <mesh position={[0, noseY - 0.1, L / 2 + 0.012]} material={darkMat}>
            <boxGeometry args={[W * 0.46, 0.17, 0.03]} />
          </mesh>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[0, noseY - 0.16 + i * 0.035, L / 2 + 0.03]} material={trimMat}>
              <boxGeometry args={[W * 0.44, 0.01, 0.012]} />
            </mesh>
          ))}
          <mesh position={[0, gc + 0.05, L / 2 - 0.1]} material={darkMat}>
            <boxGeometry args={[W * 0.94, 0.035, 0.34]} />
          </mesh>
          {[1, -1].map((sd) => (
            <mesh key={sd} position={[sd * W * 0.37, gc + 0.2, L / 2 + 0.012]} material={darkMat}>
              <boxGeometry args={[W * 0.16, 0.12, 0.03]} />
            </mesh>
          ))}
          {/* license plates */}
          <mesh position={[0, gc + 0.2, L / 2 + 0.018]}>
            <boxGeometry args={[0.46, 0.14, 0.012]} />
            <meshStandardMaterial color="#f3f1e6" roughness={0.5} />
          </mesh>
          <mesh position={[0, gc + 0.3, -L / 2 - 0.018]}>
            <boxGeometry args={[0.46, 0.14, 0.012]} />
            <meshStandardMaterial color="#f3f1e6" roughness={0.5} />
          </mesh>

          {/* headlights */}
          {[1, -1].map((sd) => (
            <group key={sd}>
              <RoundedBox args={[W * 0.2, 0.095, 0.06]} radius={0.03} position={[sd * W * 0.33, noseY + 0.05, L / 2 - 0.005]} material={lights.head} />
              <mesh position={[sd * W * 0.33, noseY + 0.05, L / 2 + 0.02]} material={darkMat}>
                <boxGeometry args={[W * 0.2, 0.012, 0.02]} />
              </mesh>
              {/* indicator */}
              <mesh position={[sd * W * 0.44, noseY - 0.04, L / 2 - 0.008]} material={sd === 1 ? lights.indL : lights.indR}>
                <boxGeometry args={[0.07, 0.04, 0.03]} />
              </mesh>
            </group>
          ))}

          {/* tail lights */}
          {[1, -1].map((sd) => (
            <RoundedBox key={sd} args={[W * 0.26, 0.085, 0.05]} radius={0.025} position={[sd * W * 0.34, tailY + 0.06, -L / 2 + 0.004]} material={lights.tail} />
          ))}
          <mesh position={[0, tailY + 0.06, -L / 2 + 0.004]} material={lights.tail}>
            <boxGeometry args={[W * 0.2, 0.03, 0.04]} />
          </mesh>
          <mesh position={[W * 0.2, gc + 0.34, -L / 2 - 0.004]} material={lights.rev}>
            <boxGeometry args={[0.08, 0.04, 0.03]} />
          </mesh>

          {/* rear diffuser, exhaust tips, spoiler */}
          <mesh position={[0, gc + 0.07, -L / 2 + 0.12]} material={darkMat}>
            <boxGeometry args={[W * 0.7, 0.07, 0.3]} />
          </mesh>
          {[1, -1].map((sd) => (
            <mesh key={sd} position={[sd * W * 0.24, gc + 0.12, -L / 2 - 0.03]} rotation={[Math.PI / 2, 0, 0]} material={chromeMat}>
              <cylinderGeometry args={[0.05, 0.05, 0.14, 24, 1, true]} />
            </mesh>
          ))}
          {sporty && (
            <group position={[0, beltY * 1.0 + 0.12, -L / 2 + 0.34]}>
              <mesh material={paint} castShadow><boxGeometry args={[W * 0.86, 0.025, 0.3]} /></mesh>
              {[1, -1].map((sd) => (
                <mesh key={sd} position={[sd * W * 0.3, -0.07, 0.02]} material={darkMat}><boxGeometry args={[0.03, 0.13, 0.12]} /></mesh>
              ))}
            </group>
          )}

          {/* side skirts */}
          {[1, -1].map((sd) => (
            <mesh key={sd} position={[sd * (W / 2 + 0.004), gc + 0.05, midZ]} material={darkMat}>
              <boxGeometry args={[0.02, 0.07, doorLen * 0.8]} />
            </mesh>
          ))}
        </>
      )}

      {/* ── wheel arch liners (dark discs behind each tyre) ── */}
      {!ghost && ([[axleF, 1], [axleR, 1], [axleF, -1], [axleR, -1]] as [number, number][]).map(([z, sd], i) => (
        <mesh key={i} position={[sd * (W / 2 + 0.003), wheelR, z]} rotation={[0, 0, Math.PI / 2]} material={darkMat}>
          <cylinderGeometry args={[wheelR + 0.055, wheelR + 0.055, 0.006, 40]} />
        </mesh>
      ))}

      {/* ── wheels ── */}
      <Wheel layout={lay} x={trackX} z={axleF} side={1} front driveRef={driveRef} ghost={ghost} />
      <Wheel layout={lay} x={-trackX} z={axleF} side={-1} front driveRef={driveRef} ghost={ghost} />
      <Wheel layout={lay} x={trackX} z={axleR} side={1} front={false} driveRef={driveRef} ghost={ghost} />
      <Wheel layout={lay} x={-trackX} z={axleR} side={-1} front={false} driveRef={driveRef} ghost={ghost} />

      {/* ── floor + interior ── */}
      {!ghost && (
        <mesh position={[0, gc + 0.03, midZ]}>
          <boxGeometry args={[W - doorT * 2, 0.06, doorLen]} />
          <meshStandardMaterial color="#1b1b1d" roughness={0.95} />
        </mesh>
      )}
      {interior && <CarInterior layout={lay} driveRef={driveRef} />}
    </group>
  );
}
