import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { useGameStore } from '../store/useGameStore';

/**
 * 3D guide arrow. Each stage writes to `guide` in the store what the player
 * should look at next; this component draws a bouncing yellow arrow above it.
 * When the stage calls `fadeGuide(key)`, the arrow fades out over 0.6s after
 * a 3-second celebration pause — so the player sees the arrow leave AFTER they
 * finish the current micro-task, not while they're still doing it.
 */
const FADE_DELAY_MS = 3000;
const FADE_MS = 600;

export default function GuideArrow() {
  const guide = useGameStore((s) => s.guide);
  const group = useRef<THREE.Group>(null);
  const body = useRef<THREE.Mesh>(null);
  const head = useRef<THREE.Mesh>(null);
  const ring = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!guide || !group.current) return;
    const t = state.clock.elapsedTime;
    // bob up and down, slow spin
    const bob = Math.sin(t * 3.6) * 0.07;
    group.current.position.set(guide.pos[0], guide.pos[1] + 1.2 + bob, guide.pos[2]);
    group.current.rotation.y = t * 0.9;
    // fade out after fadingSince + delay
    let a = 1;
    if (guide.fadingSince != null) {
      const dt = Date.now() - guide.fadingSince - FADE_DELAY_MS;
      if (dt > 0) a = Math.max(0, 1 - dt / FADE_MS);
    }
    if (body.current) (body.current.material as THREE.MeshBasicMaterial).opacity = a;
    if (head.current) (head.current.material as THREE.MeshBasicMaterial).opacity = a;
    if (ring.current) (ring.current.material as THREE.MeshBasicMaterial).opacity = a * 0.7;
    group.current.scale.setScalar(a > 0 ? 1 : 0);
  });

  if (!guide) return null;
  return (
    <group ref={group} position={[guide.pos[0], guide.pos[1] + 1.2, guide.pos[2]]}>
      {/* vertical stem pointing down */}
      <mesh ref={body} position={[0, 0.25, 0]}>
        <cylinderGeometry args={[0.055, 0.055, 0.6, 12]} />
        <meshBasicMaterial color="#ffd21a" transparent depthTest={false} depthWrite={false} toneMapped={false} />
      </mesh>
      {/* arrow head */}
      <mesh ref={head} position={[0, -0.14, 0]} rotation={[Math.PI, 0, 0]}>
        <coneGeometry args={[0.18, 0.34, 16]} />
        <meshBasicMaterial color="#ffd21a" transparent depthTest={false} depthWrite={false} toneMapped={false} />
      </mesh>
      {/* halo ring on the ground */}
      <mesh ref={ring} position={[0, -(guide.pos[1]) - 0.95, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.18, 0.28, 32]} />
        <meshBasicMaterial color="#ffd21a" transparent opacity={0.7} depthTest={false} depthWrite={false} toneMapped={false} />
      </mesh>
      {guide.label && (
        <Html center position={[0, 0.65, 0]} distanceFactor={10} style={{ pointerEvents: 'none' }}>
          <div className="guide-label">{guide.label}</div>
        </Html>
      )}
    </group>
  );
}
