import { useEffect, useMemo, useRef } from 'react';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { brickTexture, concreteTexture, stoneTileTexture, woodTexture, metalPlateTexture } from './textures';
import { FORGE_ORIGIN, BENCH_ORIGIN } from '../manufacturing/targets';

// ─────────────────────────────────────────────────────────────────────────
// Two separate spaces far away from the garage. Whenever the player makes
// something the camera is taken there: the foundry for anything cast, the
// workshop for everything that is filed / drilled / sewn / soldered.
// ─────────────────────────────────────────────────────────────────────────

/** table height in the foundry (work surface of the sand mould) */
export const TABLE_Y = 0.92;
/** surface of the sand block: stands on the table so the carved cavity is never hidden by the table top */
export const BLOCK_Y = TABLE_Y + 0.3;
export const FURNACE_POS: [number, number, number] = [-4.6, 0, -1.2];
export const TANK_POS: [number, number, number] = [4.6, 0, 1.4];

type V3 = [number, number, number];

/** a shadow-casting directional light that really aims at the room (its target is added to the scene) */
function RoomLight({ at, from = [4, 9, 5], intensity = 1.6, area = 9 }: { at: V3; from?: V3; intensity?: number; area?: number }) {
  const ref = useRef<THREE.DirectionalLight>(null);
  const scene = useThree((s) => s.scene);
  useEffect(() => {
    const l = ref.current;
    if (!l) return undefined;
    l.target.position.set(at[0], at[1], at[2]);
    scene.add(l.target);
    return () => { scene.remove(l.target); };
  }, [at, scene]);
  return (
    <directionalLight
      ref={ref}
      position={[at[0] + from[0], at[1] + from[1], at[2] + from[2]]}
      intensity={intensity}
      castShadow
      shadow-mapSize={[2048, 2048]}
      shadow-camera-left={-area}
      shadow-camera-right={area}
      shadow-camera-top={area}
      shadow-camera-bottom={-area}
      shadow-camera-near={1}
      shadow-camera-far={30}
      shadow-bias={-0.0006}
      shadow-normalBias={0.03}
    />
  );
}

function TexturedBox({ pos, size, tex, tint = '#ffffff', rough = 0.9, metal = 0 }: {
  pos: V3; size: V3; tex: { map: THREE.Texture; bump: THREE.Texture }; tint?: string; rough?: number; metal?: number;
}) {
  return (
    <mesh position={pos} castShadow receiveShadow>
      <boxGeometry args={size} />
      <meshStandardMaterial map={tex.map} bumpMap={tex.bump} bumpScale={1.4} color={tint} roughness={rough} metalness={metal} />
    </mesh>
  );
}

function Lamp({ pos, color = '#fff2d2', glow = 1 }: { pos: V3; color?: string; glow?: number }) {
  return (
    <group position={pos}>
      <mesh position={[0, 0.9, 0]}><cylinderGeometry args={[0.02, 0.02, 1.8, 6]} /><meshStandardMaterial color="#222" /></mesh>
      <mesh position={[0, 0.05, 0]}>
        <coneGeometry args={[0.55, 0.4, 24, 1, true]} />
        <meshStandardMaterial color="#2c3036" side={THREE.DoubleSide} metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh position={[0, -0.1, 0]}><sphereGeometry args={[0.16, 16, 16]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={2.4 * glow} toneMapped={false} /></mesh>
      <pointLight position={[0, -0.4, 0]} intensity={11 * glow} distance={13} color={color} />
    </group>
  );
}

function Shell({ w, d, h, floor, wall, wallTint }: {
  w: number; d: number; h: number;
  floor: { map: THREE.Texture; bump: THREE.Texture };
  wall: { map: THREE.Texture; bump: THREE.Texture };
  wallTint: string;
}) {
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[w, d]} />
        <meshStandardMaterial map={floor.map} bumpMap={floor.bump} bumpScale={1.2} roughness={0.8} metalness={0.05} />
      </mesh>
      <TexturedBox pos={[0, h / 2, -d / 2]} size={[w, h, 0.4]} tex={wall} tint={wallTint} />
      <TexturedBox pos={[-w / 2, h / 2, 0]} size={[0.4, h, d]} tex={wall} tint={wallTint} />
      <TexturedBox pos={[w / 2, h / 2, 0]} size={[0.4, h, d]} tex={wall} tint={wallTint} />
      <TexturedBox pos={[0, h / 2, d / 2]} size={[w, h, 0.4]} tex={wall} tint={wallTint} />
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, h, 0]}>
        <planeGeometry args={[w, d]} />
        <meshStandardMaterial color="#25272c" roughness={0.95} />
      </mesh>
      {/* roof beams */}
      {[-6, -2, 2, 6].map((x) => (
        <mesh key={x} position={[x, h - 0.2, 0]} castShadow>
          <boxGeometry args={[0.35, 0.4, d]} />
          <meshStandardMaterial color="#4a3a2a" roughness={0.9} />
        </mesh>
      ))}
    </group>
  );
}

function Shelf({ pos, rotY = 0, items = 6 }: { pos: V3; rotY?: number; items?: number }) {
  const cols = ['#b42318', '#2f6fa8', '#d4a017', '#3a8a4a', '#8a5a2a', '#6a6a72'];
  return (
    <group position={pos} rotation={[0, rotY, 0]}>
      {[0.5, 1.2, 1.9].map((y) => (
        <group key={y}>
          <mesh position={[0, y, 0]} castShadow receiveShadow><boxGeometry args={[2.6, 0.07, 0.6]} /><meshStandardMaterial color="#5a4630" roughness={0.8} /></mesh>
          {Array.from({ length: items }).map((_, i) => (
            <mesh key={i} position={[-1.1 + i * 0.44, y + 0.17, 0]} castShadow>
              <boxGeometry args={[0.3, 0.26 + ((i * 7) % 3) * 0.05, 0.3]} />
              <meshStandardMaterial color={cols[(i + Math.round(y * 3)) % cols.length]} roughness={0.55} metalness={0.2} />
            </mesh>
          ))}
        </group>
      ))}
      {[-1.25, 1.25].map((x) => (
        <mesh key={x} position={[x, 1.1, 0]} castShadow><boxGeometry args={[0.07, 2.2, 0.6]} /><meshStandardMaterial color="#3a3a3e" metalness={0.6} roughness={0.5} /></mesh>
      ))}
    </group>
  );
}

/** the furnace, the quench tank, the anvil and the sand table's frame */
export function FoundryRoom() {
  const o = FORGE_ORIGIN;
  const floor = useMemo(() => stoneTileTexture(8, 8), []);
  const wall = useMemo(() => brickTexture(6, 2), []);
  const plate = useMemo(() => metalPlateTexture(1, 1), []);
  const wood = useMemo(() => woodTexture(2, 1), []);
  return (
    <group position={o}>
      {/* taller room (h 7 → 11) so the lamps clear the top-down view */}
      <Shell w={18} d={14} h={11} floor={floor} wall={wall} wallTint="#c9a692" />
      <RoomLight at={[0, 0, 0]} from={[5, 14, 6]} intensity={1.1} />
      <ambientLight intensity={0.15} />
      <Lamp pos={[0, 10.3, 0]} />
      <Lamp pos={[-5, 10.3, -1]} color="#ffb26a" />
      <Lamp pos={[5, 10.3, 1]} color="#ffe6c4" />

      {/* sand-mould table */}
      <group position={[0, 0, 0]}>
        <mesh position={[0, TABLE_Y - 0.1, 0]} castShadow receiveShadow>
          <boxGeometry args={[4.4, 0.2, 3.2]} />
          <meshStandardMaterial map={wood.map} bumpMap={wood.bump} bumpScale={1} roughness={0.8} />
        </mesh>
        {[[-2.05, -1.45], [2.05, -1.45], [-2.05, 1.45], [2.05, 1.45]].map(([x, z], i) => (
          <mesh key={i} position={[x, (TABLE_Y - 0.2) / 2, z]} castShadow><boxGeometry args={[0.22, TABLE_Y - 0.2, 0.22]} /><meshStandardMaterial color="#3a3a3e" metalness={0.6} roughness={0.45} /></mesh>
        ))}
        {/* wooden moulding box that frames the sand block */}
        {[[0, -1.15, 3.5, 0.16], [0, 1.15, 3.5, 0.16]].map(([x, z, w, t], i) => (
          <mesh key={i} position={[x, TABLE_Y + 0.14, z]} castShadow><boxGeometry args={[w + 0.3, 0.44, t]} /><meshStandardMaterial map={wood.map} roughness={0.8} /></mesh>
        ))}
        {[-1.7, 1.7].map((x) => (
          <mesh key={x} position={[x, TABLE_Y + 0.14, 0]} castShadow><boxGeometry args={[0.16, 0.44, 2.46]} /><meshStandardMaterial map={wood.map} roughness={0.8} /></mesh>
        ))}
      </group>

      {/* furnace */}
      <group position={FURNACE_POS}>
        <mesh position={[0, 0.8, 0]} castShadow receiveShadow><boxGeometry args={[2.0, 1.6, 2.0]} /><meshStandardMaterial map={wall.map} bumpMap={wall.bump} color="#8a5a48" roughness={0.9} /></mesh>
        <mesh position={[0, 1.62, 0]} castShadow><boxGeometry args={[2.2, 0.14, 2.2]} /><meshStandardMaterial color="#2b2d31" metalness={0.7} roughness={0.4} /></mesh>
        <mesh position={[0, 1.63, 0]}><cylinderGeometry args={[0.6, 0.6, 0.05, 28]} /><meshStandardMaterial color="#120a06" /></mesh>
        <mesh position={[0, 0.55, 1.01]}><boxGeometry args={[0.9, 0.55, 0.05]} /><meshStandardMaterial color="#ff6a1a" emissive="#ff5a0a" emissiveIntensity={2.6} toneMapped={false} /></mesh>
        <pointLight position={[0, 1.2, 1.6]} color="#ff7a2a" intensity={30} distance={9} />
        {/* Riveted door frame, hinges and handle give the furnace readable construction. */}
        <mesh position={[0, 0.55, 1.045]}><boxGeometry args={[1.12, 0.75, 0.07]} /><meshStandardMaterial color="#25282a" metalness={0.8} roughness={0.55} /></mesh>
        <mesh position={[0, 0.55, 1.09]}><boxGeometry args={[0.80, 0.44, 0.04]} /><meshStandardMaterial color="#d45b1b" emissive="#fa4d08" emissiveIntensity={1.4} toneMapped={false} /></mesh>
        {[-0.48, 0.48].flatMap(x => [0.23, 0.86].map(y => <mesh key={x + ':' + y} position={[x,y,1.095]} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[0.035,0.035,0.025,10]}/><meshStandardMaterial color="#9a8d7e" metalness={0.9} roughness={0.4}/></mesh>))}
        <mesh position={[0.6,0.53,1.12]} rotation={[0,0,Math.PI/2]}><cylinderGeometry args={[0.035,0.035,0.32,12]}/><meshStandardMaterial color="#a7a09a" metalness={0.9} roughness={0.3}/></mesh>
        <mesh position={[0,2.13,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[0.46,0.035,8,32]}/><meshStandardMaterial color="#72665d" metalness={0.6} roughness={0.65}/></mesh>
        {/* chimney */}
        <mesh position={[0, 4.2, -0.6]} castShadow><boxGeometry args={[0.9, 5.2, 0.9]} /><meshStandardMaterial map={wall.map} color="#7a5040" /></mesh>
        {/* crucible */}
        <mesh position={[0, 1.88, 0]} castShadow><cylinderGeometry args={[0.46, 0.34, 0.5, 28, 1, true]} /><meshStandardMaterial color="#2a2522" roughness={0.9} side={THREE.DoubleSide} /></mesh>
        <mesh position={[0, 1.64, 0]}><cylinderGeometry args={[0.34, 0.34, 0.04, 28]} /><meshStandardMaterial color="#1a1512" /></mesh>
      </group>

      {/* quench tank */}
      <group position={TANK_POS}>
        <mesh position={[0, 0.45, 0]} castShadow receiveShadow><boxGeometry args={[2.0, 0.9, 1.5]} /><meshStandardMaterial map={plate.map} bumpMap={plate.bump} color="#566" metalness={0.7} roughness={0.45} /></mesh>
        <mesh position={[0, 0.88, 0]}><boxGeometry args={[1.8, 0.04, 1.3]} /><meshStandardMaterial color="#2a6a8a" transparent opacity={0.85} roughness={0.08} metalness={0.2} /></mesh>
      </group>

      {/* anvil + sand barrels + tools */}
      <group position={[-3.2, 0, 4.2]}>
        <mesh position={[0, 0.3, 0]} castShadow><cylinderGeometry args={[0.35, 0.4, 0.6, 12]} /><meshStandardMaterial map={wood.map} roughness={0.9} /></mesh>
        <mesh position={[0, 0.7, 0]} castShadow><boxGeometry args={[0.9, 0.22, 0.34]} /><meshStandardMaterial color="#303338" metalness={0.9} roughness={0.35} /></mesh>
        <mesh position={[0.5, 0.74, 0]} rotation={[0, 0, -0.3]} castShadow><coneGeometry args={[0.1, 0.4, 10]} /><meshStandardMaterial color="#303338" metalness={0.9} roughness={0.35} /></mesh>
      </group>
      {[[6.5, 5], [7.2, 4.2], [-7, 5.2]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.55, z]} castShadow receiveShadow><cylinderGeometry args={[0.5, 0.5, 1.1, 20]} /><meshStandardMaterial color={i === 1 ? '#8a6a3a' : '#5a6a7a'} metalness={0.5} roughness={0.55} /></mesh>
      ))}
      <Shelf pos={[0, 0, -6.6]} />
      <Shelf pos={[-5.5, 0, -6.6]} items={5} />
      <Shelf pos={[8.6, 0, -1]} rotY={-Math.PI / 2} items={5} />
    </group>
  );
}

/** pegboard wall, vise bench, parts drawers — the filing / sewing / soldering room */
export function BenchRoom() {
  const o = BENCH_ORIGIN;
  const floor = useMemo(() => concreteTexture(6, 5), []);
  const wall = useMemo(() => brickTexture(5, 2), []);
  const wood = useMemo(() => woodTexture(2, 1), []);
  const peg = useMemo(() => metalPlateTexture(3, 1.5), []);
  const tools = ['#b42318', '#2f6fa8', '#f5c518', '#3a8a4a', '#c9c9d0', '#8a5a2a'];
  return (
    <group position={o}>
      <Shell w={16} d={13} h={10.5} floor={floor} wall={wall} wallTint="#cfd6dd" />
      <RoomLight at={[0, 0, 0]} from={[3, 13, 6]} intensity={1.2} />
      <ambientLight intensity={0.22} />
      <Lamp pos={[0, 9.8, 0]} color="#fff6e4" />
      <Lamp pos={[-4.5, 9.8, 1]} color="#fff6e4" glow={0.8} />
      <Lamp pos={[4.5, 9.8, 1]} color="#fff6e4" glow={0.8} />

      {/* pegboard with hung tools */}
      <mesh position={[0, 2.5, -6.2]} receiveShadow>
        <boxGeometry args={[9, 2.6, 0.08]} />
        <meshStandardMaterial map={peg.map} bumpMap={peg.bump} color="#7a8088" metalness={0.5} roughness={0.5} />
      </mesh>
      {tools.flatMap((c, row) => Array.from({ length: 9 }).map((_, i) => (
        <mesh key={`${row}-${i}`} position={[-3.9 + i * 0.97, 3.2 - (row % 3) * 0.62, -6.1]} castShadow>
          <boxGeometry args={[0.12 + ((i * 3 + row) % 4) * 0.03, 0.42 + ((i + row) % 3) * 0.12, 0.05]} />
          <meshStandardMaterial color={tools[(i + row) % tools.length]} metalness={0.6} roughness={0.4} />
        </mesh>
      )).slice(0, 27))}

      {/* back counter + drawers */}
      <mesh position={[0, 0.5, -5.6]} castShadow receiveShadow><boxGeometry args={[9, 1.0, 1.0]} /><meshStandardMaterial map={wood.map} bumpMap={wood.bump} roughness={0.8} /></mesh>
      {[-3.6, -1.8, 0, 1.8, 3.6].map((x) => (
        <mesh key={x} position={[x, 0.5, -5.08]}><boxGeometry args={[1.6, 0.8, 0.03]} /><meshStandardMaterial color="#2c3036" metalness={0.6} roughness={0.4} /></mesh>
      ))}
      {/* vise */}
      <group position={[-3.9, 1.0, -5.5]}>
        <mesh position={[0, 0.12, 0]} castShadow><boxGeometry args={[0.5, 0.25, 0.4]} /><meshStandardMaterial color="#b42318" metalness={0.5} roughness={0.5} /></mesh>
        <mesh position={[0, 0.3, 0.3]} castShadow><boxGeometry args={[0.46, 0.12, 0.12]} /><meshStandardMaterial color="#c9c9d0" metalness={0.9} roughness={0.25} /></mesh>
      </group>

      <Shelf pos={[-7.6, 0, 0]} rotY={Math.PI / 2} items={5} />
      <Shelf pos={[7.6, 0, 0]} rotY={-Math.PI / 2} items={5} />
      {/* rug + stool */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 1.2]} receiveShadow>
        <planeGeometry args={[6, 4.6]} />
        <meshStandardMaterial color="#2f3b4c" roughness={1} />
      </mesh>
      <mesh position={[-2.6, 0.4, 2.8]} castShadow><cylinderGeometry args={[0.28, 0.25, 0.8, 16]} /><meshStandardMaterial color="#3a3a3e" metalness={0.5} roughness={0.5} /></mesh>
    </group>
  );
}
// r5b
// r5c
// r5d
