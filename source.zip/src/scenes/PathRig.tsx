import { useEffect, useMemo, useRef, useState } from 'react';
import { useFrame, useThree, type ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';
import type { PathSpec, ToolKind, WorkKind, PathShape } from '../manufacturing/recipes';
import { Particles, type ParticleAPI } from './fx';
import { sfx } from './sfx';
import { shotSide, shotTop, useHud } from './foundryKit';

// ─────────────────────────────────────────────────────────────────────────
// PathRig: the generic "hand work" session. A tool sits on the work piece;
// the player drags it ONE STROKE at a time from waypoint to waypoint (one
// stitch, one weld pass, one solder joint, one wrench turn, one cut...).
// Releasing away from the next waypoint is a slip: the tool snaps back,
// the slip is counted, and it lowers the quality of the finished piece.
// ─────────────────────────────────────────────────────────────────────────

type V2 = [number, number];

function buildWaypoints(shape: PathShape, steps: number): V2[] {
  const pts: V2[] = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    if (shape === 'line') pts.push([-0.9 + 1.8 * t, 0]);
    else if (shape === 'circle') {
      const a = -Math.PI / 2 + Math.PI * 2 * t;
      pts.push([Math.cos(a) * 0.6, Math.sin(a) * 0.6]);
    } else if (shape === 'outline') {
      const hx = 0.95;
      const hz = 0.55;
      const corners: V2[] = [[-hx, -hz], [hx, -hz], [hx, hz], [-hx, hz], [-hx, -hz]];
      const u = t * 4;
      const e = Math.min(3, Math.floor(u));
      const f = u - e;
      pts.push([corners[e][0] + (corners[e + 1][0] - corners[e][0]) * f, corners[e][1] + (corners[e + 1][1] - corners[e][1]) * f]);
    } else {
      pts.push([-0.9 + 1.8 * t, i % 2 === 0 ? -0.35 : 0.35]);
    }
  }
  return pts;
}

function Segment({ a, b, y, color, thick = 0.05 }: { a: V2; b: V2; y: number; color: string; thick?: number }) {
  const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
  const ang = Math.atan2(b[1] - a[1], b[0] - a[0]);
  return (
    <mesh position={[(a[0] + b[0]) / 2, y, (a[1] + b[1]) / 2]} rotation={[0, -ang, 0]}>
      <boxGeometry args={[len + 0.02, thick, thick]} />
      <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.35} metalness={0.4} roughness={0.4} />
    </mesh>
  );
}

function WorkMesh({ kind, color }: { kind: WorkKind; color: string }) {
  switch (kind) {
    case 'cloth':
      return (
        <mesh castShadow receiveShadow position={[0, 0.02, 0]}>
          <boxGeometry args={[2.2, 0.03, 1.4]} />
          <meshStandardMaterial color={color} roughness={0.95} />
        </mesh>
      );
    case 'wire':
      return (
        <group>
          <mesh rotation={[0, 0, Math.PI / 2]} position={[0, 0.06, 0]} castShadow>
            <cylinderGeometry args={[0.05, 0.05, 2.2, 14]} />
            <meshStandardMaterial color={color} roughness={0.5} />
          </mesh>
          {[-1.1, 1.1].map((x) => (
            <mesh key={x} rotation={[0, 0, Math.PI / 2]} position={[x, 0.06, 0]}>
              <cylinderGeometry args={[0.02, 0.02, 0.18, 8]} />
              <meshStandardMaterial color="#c58a3a" metalness={0.9} roughness={0.25} />
            </mesh>
          ))}
        </group>
      );
    case 'board':
      return (
        <group>
          <mesh castShadow receiveShadow position={[0, 0.04, 0]}>
            <boxGeometry args={[2.0, 0.06, 1.3]} />
            <meshStandardMaterial color="#1c7a4a" roughness={0.55} metalness={0.15} />
          </mesh>
          {[[-0.6, 0.3], [0.2, -0.3], [0.7, 0.35], [-0.2, 0.0]].map(([x, z], i) => (
            <mesh key={i} position={[x, 0.1, z]} castShadow>
              <boxGeometry args={[0.28, 0.06, 0.2]} />
              <meshStandardMaterial color="#111" roughness={0.4} />
            </mesh>
          ))}
        </group>
      );
    case 'rod':
      return (
        <mesh rotation={[0, 0, Math.PI / 2]} position={[0, 0.14, 0]} castShadow>
          <cylinderGeometry args={[0.13, 0.13, 2.2, 20]} />
          <meshStandardMaterial color={color} metalness={0.85} roughness={0.3} />
        </mesh>
      );
    case 'tube':
      return (
        <mesh rotation={[0, 0, Math.PI / 2]} position={[0, 0.1, 0]} castShadow>
          <cylinderGeometry args={[0.07, 0.07, 2.2, 16]} />
          <meshStandardMaterial color={color} metalness={0.8} roughness={0.3} />
        </mesh>
      );
    case 'cylinder':
      return (
        <mesh rotation={[0, 0, Math.PI / 2]} position={[0, 0.38, 0]} castShadow>
          <cylinderGeometry args={[0.36, 0.36, 2.0, 28]} />
          <meshStandardMaterial color={color} metalness={0.8} roughness={0.35} />
        </mesh>
      );
    case 'gear':
      return (
        <group position={[0, 0.07, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.72, 0.72, 0.14, 40]} />
            <meshStandardMaterial color={color} metalness={0.85} roughness={0.3} />
          </mesh>
          {Array.from({ length: 18 }).map((_, i) => {
            const a = (i / 18) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.76, 0, Math.sin(a) * 0.76]} rotation={[0, -a, 0]}>
                <boxGeometry args={[0.1, 0.14, 0.1]} />
                <meshStandardMaterial color={color} metalness={0.85} roughness={0.3} />
              </mesh>
            );
          })}
        </group>
      );
    case 'bolt':
      return (
        <group>
          <mesh position={[0, 0.03, 0]} receiveShadow>
            <boxGeometry args={[1.5, 0.05, 1.5]} />
            <meshStandardMaterial color="#6e6e74" metalness={0.7} roughness={0.45} />
          </mesh>
          <mesh position={[0, 0.17, 0]} castShadow>
            <cylinderGeometry args={[0.25, 0.25, 0.2, 6]} />
            <meshStandardMaterial color={color} metalness={0.9} roughness={0.25} />
          </mesh>
        </group>
      );
    case 'surface':
      return (
        <mesh position={[0, 0.02, 0]} receiveShadow>
          <boxGeometry args={[2.3, 0.04, 1.5]} />
          <meshStandardMaterial color={color} metalness={0.5} roughness={0.35} transparent opacity={0.85} />
        </mesh>
      );
    default:
      return (
        <mesh castShadow receiveShadow position={[0, 0.05, 0]}>
          <boxGeometry args={[2.2, 0.1, 1.4]} />
          <meshStandardMaterial color={color} metalness={0.8} roughness={0.35} />
        </mesh>
      );
  }
}

const GLOW_TOOLS: ToolKind[] = ['torch', 'solder', 'heatgun'];

function ToolMesh({ kind }: { kind: ToolKind }) {
  const steel = { color: '#c9c9d0', metalness: 0.9, roughness: 0.2 } as const;
  switch (kind) {
    case 'needle':
      return (
        <group>
          <mesh position={[0, 0.16, 0]} rotation={[Math.PI, 0, 0]}><coneGeometry args={[0.012, 0.32, 8]} /><meshStandardMaterial {...steel} /></mesh>
          <mesh position={[0, 0.34, 0]}><torusGeometry args={[0.03, 0.006, 6, 12]} /><meshStandardMaterial {...steel} /></mesh>
        </group>
      );
    case 'torch':
      return (
        <group>
          <mesh position={[0, 0.3, 0]}><cylinderGeometry args={[0.045, 0.05, 0.3, 12]} /><meshStandardMaterial color="#b42318" roughness={0.5} /></mesh>
          <mesh position={[0, 0.1, 0]} rotation={[Math.PI, 0, 0]}><coneGeometry args={[0.04, 0.14, 12]} /><meshStandardMaterial {...steel} /></mesh>
          <mesh position={[0, 0.02, 0]}><sphereGeometry args={[0.035, 10, 10]} /><meshStandardMaterial color="#ffb347" emissive="#ff8a2a" emissiveIntensity={3} toneMapped={false} /></mesh>
        </group>
      );
    case 'solder':
      return (
        <group>
          <mesh position={[0, 0.3, 0]}><cylinderGeometry args={[0.035, 0.04, 0.3, 12]} /><meshStandardMaterial color="#1a1a1a" roughness={0.6} /></mesh>
          <mesh position={[0, 0.1, 0]} rotation={[Math.PI, 0, 0]}><coneGeometry args={[0.02, 0.16, 10]} /><meshStandardMaterial color="#d0a070" emissive="#ff6a1a" emissiveIntensity={1.2} metalness={0.8} roughness={0.3} /></mesh>
        </group>
      );
    case 'wrench':
      return (
        <group>
          <mesh position={[0.2, 0.12, 0]}><boxGeometry args={[0.45, 0.05, 0.07]} /><meshStandardMaterial {...steel} /></mesh>
          <mesh position={[0, 0.12, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[0.09, 0.035, 8, 6]} /><meshStandardMaterial {...steel} /></mesh>
        </group>
      );
    case 'screwdriver':
      return (
        <group>
          <mesh position={[0, 0.34, 0]}><cylinderGeometry args={[0.045, 0.04, 0.2, 12]} /><meshStandardMaterial color="#f5c518" roughness={0.5} /></mesh>
          <mesh position={[0, 0.14, 0]}><cylinderGeometry args={[0.012, 0.012, 0.22, 8]} /><meshStandardMaterial {...steel} /></mesh>
        </group>
      );
    case 'file':
      return (
        <group>
          <mesh position={[0.1, 0.07, 0]}><boxGeometry args={[0.36, 0.035, 0.07]} /><meshStandardMaterial color="#8a8a90" metalness={0.8} roughness={0.55} /></mesh>
          <mesh position={[0.36, 0.1, 0]}><boxGeometry args={[0.14, 0.06, 0.06]} /><meshStandardMaterial color="#7a4a1a" roughness={0.8} /></mesh>
        </group>
      );
    case 'drill':
      return (
        <group>
          <mesh position={[0, 0.32, 0]}><cylinderGeometry args={[0.07, 0.07, 0.28, 14]} /><meshStandardMaterial color="#2f6fa8" roughness={0.4} /></mesh>
          <mesh position={[0, 0.1, 0]} rotation={[Math.PI, 0, 0]}><coneGeometry args={[0.02, 0.18, 8]} /><meshStandardMaterial {...steel} /></mesh>
        </group>
      );
    case 'press':
      return (
        <group>
          <mesh position={[0, 0.25, 0]}><cylinderGeometry args={[0.06, 0.06, 0.4, 14]} /><meshStandardMaterial {...steel} /></mesh>
          <mesh position={[0, 0.04, 0]}><cylinderGeometry args={[0.16, 0.16, 0.06, 20]} /><meshStandardMaterial color="#555" metalness={0.8} roughness={0.35} /></mesh>
        </group>
      );
    case 'brush':
      return (
        <group>
          <mesh position={[0, 0.28, 0]}><boxGeometry args={[0.16, 0.22, 0.1]} /><meshStandardMaterial color="#222" roughness={0.5} /></mesh>
          <mesh position={[0, 0.1, 0]} rotation={[Math.PI, 0, 0]}><coneGeometry args={[0.05, 0.14, 10]} /><meshStandardMaterial {...steel} /></mesh>
        </group>
      );
    case 'crimper':
    case 'stripper':
      return (
        <group>
          <mesh position={[0, 0.1, 0.03]} rotation={[0, 0, 0.2]}><boxGeometry args={[0.04, 0.22, 0.03]} /><meshStandardMaterial {...steel} /></mesh>
          <mesh position={[0, 0.1, -0.03]} rotation={[0, 0, -0.2]}><boxGeometry args={[0.04, 0.22, 0.03]} /><meshStandardMaterial {...steel} /></mesh>
          <mesh position={[0, 0.3, 0.05]}><boxGeometry args={[0.05, 0.22, 0.04]} /><meshStandardMaterial color={kind === 'crimper' ? '#d4a017' : '#b42318'} roughness={0.6} /></mesh>
          <mesh position={[0, 0.3, -0.05]}><boxGeometry args={[0.05, 0.22, 0.04]} /><meshStandardMaterial color={kind === 'crimper' ? '#d4a017' : '#b42318'} roughness={0.6} /></mesh>
        </group>
      );
    case 'heatgun':
      return (
        <group>
          <mesh position={[0, 0.3, 0]}><cylinderGeometry args={[0.06, 0.07, 0.3, 14]} /><meshStandardMaterial color="#222" roughness={0.5} /></mesh>
          <mesh position={[0, 0.1, 0]}><cylinderGeometry args={[0.05, 0.09, 0.12, 14]} /><meshStandardMaterial color="#ff6a1a" emissive="#ff6a1a" emissiveIntensity={1.6} toneMapped={false} /></mesh>
        </group>
      );
    default:
      // cutter (scissors)
      return (
        <group>
          <mesh position={[0, 0.12, 0.025]} rotation={[0, 0, 0.18]}><boxGeometry args={[0.035, 0.26, 0.015]} /><meshStandardMaterial {...steel} /></mesh>
          <mesh position={[0, 0.12, -0.025]} rotation={[0, 0, -0.18]}><boxGeometry args={[0.035, 0.26, 0.015]} /><meshStandardMaterial {...steel} /></mesh>
          <mesh position={[0, 0.3, 0.05]}><torusGeometry args={[0.05, 0.012, 6, 14]} /><meshStandardMaterial color="#b42318" roughness={0.6} /></mesh>
          <mesh position={[0, 0.3, -0.05]}><torusGeometry args={[0.05, 0.012, 6, 14]} /><meshStandardMaterial color="#b42318" roughness={0.6} /></mesh>
        </group>
      );
  }
}

/** height of the work piece's top face above the bench surface, per work kind */
const WORK_TOP: Record<WorkKind, number> = {
  cylinder: 0.74, rod: 0.27, gear: 0.14, plate: 0.1, board: 0.1, tube: 0.17, bolt: 0.27, cloth: 0.04, wire: 0.11, surface: 0.04,
};

function strokeSound(tool: ToolKind) {
  switch (tool) {
    case 'file': sfx.scrape(0.8); break;
    case 'drill': case 'cutter': case 'wrench': case 'stripper': sfx.clank(); break;
    case 'torch': case 'solder': sfx.zap(); break;
    case 'press': case 'crimper': sfx.thud(); break;
    case 'heatgun': sfx.whoosh(); break;
    default: sfx.tick();
  }
}

export default function PathRig({
  rigId, title, spec, origin, onComplete,
}: {
  rigId: string;
  title: string;
  spec: PathSpec;
  origin: [number, number, number];
  onComplete: (quality: number, errors: string[]) => void;
}) {
  const calledRef = useRef(false);
  const doneRef = useRef(onComplete);
  doneRef.current = onComplete;
  const wps = useMemo(() => buildWaypoints(spec.shape, spec.steps), [spec.shape, spec.steps]);
  const depthPasses = spec.depth ?? 0;
  const [idx, setIdx] = useState(0);
  const [misses, setMisses] = useState(0);
  const [toolPos, setToolPos] = useState<V2>(wps[0]);
  const [dragging, setDragging] = useState(false);
  const [flash, setFlash] = useState<'ok' | 'bad' | null>(null);
  // side view: nothing to do from the side unless the tool actually goes DOWN into the piece
  const [sideIdx, setSideIdx] = useState(0);
  const [sideY, setSideY] = useState(0.9);
  const [sideDrag, setSideDrag] = useState(false);
  const pulse = useRef<THREE.Mesh>(null);
  const fx = useRef<ParticleAPI>(null);

  const onBench = !spec.atTarget;
  const topY = onBench ? 0.82 : 0;
  const hot = GLOW_TOOLS.includes(spec.tool);
  const topDone = idx >= spec.steps;
  const phase: 'top' | 'side' | 'done' = !topDone ? 'top' : sideIdx < depthPasses ? 'side' : 'done';
  const workTop = WORK_TOP[spec.work];
  const targetY = workTop - 0.14;
  const sideX = (i: number) => (i - (depthPasses - 1) / 2) * 0.55;

  // camera: straight down first; the side view only when there is a depth pass to do
  useEffect(() => {
    if (onBench) shotTop(origin, topY, 3.6, 0, 0, true);
    else shotTop(origin, topY + 0.3, 3.0, 0, 0, true);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (phase === 'side') {
      if (onBench) shotSide(origin, topY + 0.35, 3.0, 0.08);
      else shotSide(origin, topY + 0.5, 2.6, 0.1);
      sfx.ok();
    }
  }, [phase]); // eslint-disable-line react-hooks/exhaustive-deps

  useFrame((state) => {
    if (pulse.current) {
      const s = 1 + Math.sin(state.clock.elapsedTime * 6) * 0.18;
      pulse.current.scale.set(s, s, 1);
    }
  });

  useEffect(() => {
    if (phase === 'done' && !calledRef.current) {
      const quality = Math.max(25, Math.round(100 - misses * 8));
      const errors = misses > 0 ? [`${title}: 손이 미끄러지거나 깊이를 놓친 횟수 ${misses}회`] : [];
      const t = setTimeout(() => {
        if (calledRef.current) return;
        calledRef.current = true;
        sfx.done();
        doneRef.current(quality, errors);
      }, 900);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [phase, misses, title]);

  useEffect(() => {
    if (!flash) return undefined;
    const t = setTimeout(() => setFlash(null), 260);
    return () => clearTimeout(t);
  }, [flash]);

  useEffect(() => {
    if (!dragging && !sideDrag) return undefined;
    const up = () => { onUpRef.current(); };
    window.addEventListener('pointerup', up);
    return () => window.removeEventListener('pointerup', up);
  }, [dragging, sideDrag]);

  const spark = (x: number, z: number, n = 8) => {
    const c: [number, number, number] = hot ? [1, 0.6, 0.2] : spec.tool === 'file' || spec.tool === 'drill' || spec.tool === 'cutter' ? [1, 0.85, 0.5] : [0.85, 0.85, 0.9];
    fx.current?.emit([x, topY + 0.2, z], n, { speed: 1.4, spread: 0.9, gravity: -3, life: 0.45, size: 0.045, color: c });
  };

  const onToolDown = (e: ThreeEvent<PointerEvent>) => {
    if (phase !== 'top') return;
    e.stopPropagation();
    setDragging(true);
  };
  const onMove = (x: number, z: number) => {
    if (!dragging) return;
    setToolPos([THREE.MathUtils.clamp(x - origin[0], -1.5, 1.5), THREE.MathUtils.clamp(z - origin[2], -1.1, 1.1)]);
  };
  const upLock = useRef(false);
  const onUp = () => {
    // plane handler and window listener can both fire for one release — count it once
    if (upLock.current) return;
    upLock.current = true;
    window.setTimeout(() => { upLock.current = false; }, 0);
    if (sideDrag) {
      setSideDrag(false);
      const dy = sideY - targetY;
      if (Math.abs(dy) <= 0.07) {
        setSideIdx((i) => i + 1);
        setFlash('ok');
        strokeSound(spec.tool);
        spark(sideX(sideIdx), 0, 10);
      } else {
        setMisses((m) => m + 1);
        setFlash('bad');
        sfx.bad();
      }
      setSideY(0.9);
      return;
    }
    if (!dragging) return;
    setDragging(false);
    const next = wps[Math.min(idx + 1, wps.length - 1)];
    const cur = wps[idx];
    const seg = Math.hypot(next[0] - cur[0], next[1] - cur[1]);
    const tol = Math.max(0.1, Math.min(0.2, seg * 0.5));
    const d = Math.hypot(toolPos[0] - next[0], toolPos[1] - next[1]);
    if (d < tol) {
      setIdx((i) => i + 1);
      setToolPos(next);
      setFlash('ok');
      strokeSound(spec.tool);
      spark(next[0], next[1]);
    } else {
      setMisses((m) => m + 1);
      setToolPos(cur);
      setFlash('bad');
      sfx.bad();
    }
  };
  const onUpRef = useRef(onUp);
  onUpRef.current = onUp;

  const cur = wps[Math.min(idx, wps.length - 1)];
  const toolY = topY + (dragging ? 0.05 : 0.16);
  const doneColor = spec.color;

  useHud(`path-${phase}-${idx}-${sideIdx}-${misses}`, () => ({
    title,
    phase: phase === 'top' ? `위에서 작업 · ${Math.min(idx, spec.steps)}/${spec.steps}` : phase === 'side' ? `옆에서 깊이 작업 · ${sideIdx}/${depthPasses}` : '확인 완료',
    hint: phase === 'top'
      ? `${spec.hint} — 노란 점이 다음 목표입니다. 공구를 잡고 그 점까지 끌어 놓으세요.`
      : phase === 'side'
        ? '시점이 옆으로 바뀌었습니다. 공구를 잡고 초록 선까지 정확히 내렸다가 놓으세요. 너무 깊거나 얕으면 다시 합니다.'
        : '모든 작업을 확인했습니다.',
    progress: Math.round(((Math.min(idx, spec.steps) + sideIdx) / (spec.steps + depthPasses)) * 100),
    stats: `실수 ${misses}회${depthPasses === 0 ? ' · 옆면 작업 없음 (건너뜀)' : ''}`,
  }));

  return (
    <group key={rigId} position={origin}>
      {onBench && (
        <group>
          <mesh position={[0, 0.76, 0]} castShadow receiveShadow>
            <boxGeometry args={[3.0, 0.08, 2.0]} />
            <meshStandardMaterial color="#8a6a43" roughness={0.75} />
          </mesh>
          {[[-1.4, -0.9], [1.4, -0.9], [-1.4, 0.9], [1.4, 0.9]].map(([x, z], i) => (
            <mesh key={i} position={[x, 0.37, z]} castShadow>
              <boxGeometry args={[0.1, 0.74, 0.1]} />
              <meshStandardMaterial color="#3a3a3e" metalness={0.6} roughness={0.5} />
            </mesh>
          ))}
          <mesh position={[0, 0.36, 0]}>
            <boxGeometry args={[2.8, 0.05, 1.8]} />
            <meshStandardMaterial color="#303034" roughness={0.7} />
          </mesh>
        </group>
      )}

      <group position={[0, topY, 0]}>
        <WorkMesh kind={spec.work} color={spec.color} />
        {wps.slice(0, idx + 1).map((p, i) => (i === 0 ? null : <Segment key={i} a={wps[i - 1]} b={p} y={0.12} color={doneColor} />))}
        {phase === 'top' && wps.map((p, i) => {
          const done = i <= idx;
          const isNext = i === idx + 1;
          return (
            <mesh key={i} ref={isNext ? pulse : undefined} position={[p[0], 0.13, p[1]]} rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry args={[0.05, isNext ? 0.12 : 0.08, 20]} />
              <meshBasicMaterial color={done ? '#2fae56' : isNext ? '#f5c518' : '#ffffff'} transparent opacity={done ? 0.9 : isNext ? 1 : 0.45} side={THREE.DoubleSide} />
            </mesh>
          );
        })}
        {/* side-view depth guide — thicker, longer, always drawn on top so
            it's visible from the camera's side shot. */}
        {phase === 'side' && (
          <group>
            <mesh position={[sideX(sideIdx), targetY, 0]} renderOrder={5}>
              <boxGeometry args={[1.4, 0.04, 0.04]} />
              <meshBasicMaterial color="#2fae56" transparent opacity={0.95} depthTest={false} toneMapped={false} />
            </mesh>
            {/* corner markers on the green line */}
            {[-0.7, 0.7].map((x) => (
              <mesh key={x} position={[sideX(sideIdx) + x, targetY, 0]} renderOrder={6}>
                <boxGeometry args={[0.1, 0.1, 0.1]} />
                <meshBasicMaterial color="#1f8d3f" depthTest={false} toneMapped={false} />
              </mesh>
            ))}
            <mesh position={[sideX(sideIdx), workTop, 0]} renderOrder={5}>
              <boxGeometry args={[1.4, 0.02, 0.02]} />
              <meshBasicMaterial color="#ffffff" transparent opacity={0.6} depthTest={false} toneMapped={false} />
            </mesh>
          </group>
        )}
        {/* finished depth marks */}
        {Array.from({ length: Math.min(sideIdx, depthPasses) }).map((_, i) => (
          <mesh key={i} position={[sideX(i), workTop + 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <circleGeometry args={[0.07, 16]} />
            <meshBasicMaterial color="#111" />
          </mesh>
        ))}
      </group>

      {phase === 'top' && (
        <group position={[toolPos[0], toolY, toolPos[1]]} onPointerDown={onToolDown} scale={dragging ? 1.12 : 1}>
          <ToolMesh kind={spec.tool} />
          {hot && dragging && <pointLight position={[0, 0.05, 0]} color="#ff9a3a" intensity={2.4} distance={2} />}
        </group>
      )}
      {phase === 'side' && (
        <group
          position={[sideX(sideIdx), topY + sideY, 0]}
          onPointerDown={(e: ThreeEvent<PointerEvent>) => { e.stopPropagation(); setSideDrag(true); }}
          scale={sideDrag ? 1.1 : 1}
        >
          <ToolMesh kind={spec.tool} />
        </group>
      )}
      {flash && (
        <mesh position={[phase === 'side' ? sideX(Math.max(0, sideIdx - 1)) : cur[0], topY + 0.5, phase === 'side' ? 0 : cur[1]]}>
          <sphereGeometry args={[0.05, 10, 10]} />
          <meshBasicMaterial color={flash === 'ok' ? '#2fae56' : '#b42318'} />
        </mesh>
      )}

      {/* drag surfaces: horizontal for the top view, vertical for the side view */}
      <mesh
        position={[0, topY + 0.1, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        visible={false}
        onPointerMove={(e: ThreeEvent<PointerEvent>) => onMove(e.point.x, e.point.z)}
        onPointerUp={onUp}
      >
        <planeGeometry args={[6, 5]} />
      </mesh>
      {phase === 'side' && (
        <mesh
          position={[0, topY + 0.9, 0]}
          visible={false}
          onPointerMove={(e: ThreeEvent<PointerEvent>) => {
            if (sideDrag) setSideY(THREE.MathUtils.clamp(e.point.y - origin[1] - topY, targetY - 0.3, 1.1));
          }}
          onPointerUp={onUp}
        >
          <planeGeometry args={[7, 4]} />
        </mesh>
      )}
      <Particles ref={fx} max={260} additive />
    </group>
  );
}
