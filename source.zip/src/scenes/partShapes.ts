// Resolves a part's Korean label/defId to a concrete shape family so the
// 3D object actually looks like the thing it claims to be (a panel looks
// like a flat formed plate, a screw looks like a screw, a piston looks
// like a piston) instead of a generic gray block.

export type ShapeKey =
  | 'panel' | 'slab' | 'block' | 'piston' | 'shaft' | 'turbo' | 'circuitBoard'
  | 'chip' | 'module' | 'airbag' | 'screw' | 'tire' | 'wheel' | 'disc' | 'caliper'
  | 'coil' | 'beam' | 'seatFrame' | 'cushion' | 'cover' | 'steeringWheel' | 'strap'
  | 'speaker' | 'ampBox' | 'screen' | 'tube' | 'hydraulicUnit' | 'gearbox'
  | 'ingot' | 'can' | 'wire' | 'generic';

interface ShapeRule { test: (s: string) => boolean; key: ShapeKey; color: string }

const RULES: ShapeRule[] = [
  { test: (s) => s.includes('전선') || s.includes('배선'), key: 'wire', color: '#c0392b' },
  { test: (s) => s.includes('스티어링 휠'), key: 'steeringWheel', color: '#2a2a2a' },
  { test: (s) => s.includes('커넥팅 로드'), key: 'shaft', color: '#7a7a7e' },
  { test: (s) => s.includes('디스플레이') || s.includes('터치 입력') || s.includes('화면'), key: 'screen', color: '#111' },
  { test: (s) => s.includes('슬래브'), key: 'slab', color: '#a8a8ad' },
  { test: (s) => s.includes('패널'), key: 'panel', color: '#c7c9cc' },
  { test: (s) => s.includes('블록'), key: 'block', color: '#4a4a4a' },
  { test: (s) => s.includes('피스톤'), key: 'piston', color: '#9a9a9a' },
  { test: (s) => s.includes('캠축') || s.includes('크랭크축') || s.includes('컬럼') || s.endsWith('축'), key: 'shaft', color: '#5a5a5a' },
  { test: (s) => s.includes('터보'), key: 'turbo', color: '#555' },
  { test: (s) => s.includes('기판'), key: 'circuitBoard', color: '#1f6feb' },
  { test: (s) => s.includes('칩'), key: 'chip', color: '#111' },
  { test: (s) => s.includes('에어백'), key: 'airbag', color: '#e8e2d8' },
  { test: (s) => s.includes('나사') || s.includes('봉강'), key: 'screw', color: '#b0b0b0' },
  { test: (s) => s.includes('타이어'), key: 'tire', color: '#111' },
  { test: (s) => s.includes('휠'), key: 'wheel', color: '#1a1a1a' },
  { test: (s) => s.includes('브레이크 디스크') || s.includes('디스크'), key: 'disc', color: '#8a8a8a' },
  { test: (s) => s.includes('캘리퍼'), key: 'caliper', color: '#b42318' },
  { test: (s) => s.includes('쇼크업소버') || s.includes('스프링'), key: 'coil', color: '#707070' },
  { test: (s) => s.includes('서스펜션 암') || s.includes('프레임 빔') || s.includes('빔') || s.includes('멤버') || s.includes('레일'), key: 'beam', color: '#6a6a6a' },
  { test: (s) => s.includes('시트 프레임'), key: 'seatFrame', color: '#3a3a3a' },
  { test: (s) => s.includes('쿠션재'), key: 'cushion', color: '#8a6a4a' },
  { test: (s) => s.includes('커버재'), key: 'cover', color: '#5c4433' },
  { test: (s) => s.includes('안전벨트'), key: 'strap', color: '#2a2a2a' },
  { test: (s) => s.includes('스피커'), key: 'speaker', color: '#1a1a1a' },
  { test: (s) => s.includes('앰프'), key: 'ampBox', color: '#1a1a1a' },
  { test: (s) => s.includes('유압 라인') || s.includes('호스'), key: 'tube', color: '#222' },
  { test: (s) => s.includes('유압 유닛'), key: 'hydraulicUnit', color: '#5a5a5a' },
  { test: (s) => s.includes('기어') || s.includes('클러치') || s.includes('토크 컨버터'), key: 'gearbox', color: '#3a3a3a' },
  { test: (s) => s.includes('철괴') || s.includes('합금 첨가재'), key: 'ingot', color: '#6b6b6b' },
  { test: (s) => s.includes('도료') || s.includes('클리어코트'), key: 'can', color: '#f5c518' },
  { test: (s) => s.includes('센서') || s.includes('커넥터') || s.includes('모듈') || s.includes('제어 유닛'), key: 'module', color: '#2a2a2a' },
];

export function resolveShape(label: string): { key: ShapeKey; color: string } {
  for (const rule of RULES) {
    if (rule.test(label)) return { key: rule.key, color: rule.color };
  }
  return { key: 'generic', color: '#808080' };
}
