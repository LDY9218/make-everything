import { useEffect, useLayoutEffect, useMemo, useRef, type MutableRefObject } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Environment, Sky } from '@react-three/drei';
import * as THREE from 'three';
import type { CarModel, QualityReport } from '../types';
import CarBodyMesh from './CarBodyMesh';
import { getCarLayout, makeDriveVisual, type DriveVisual } from './carLayout';

export type ViewMode = 'far' | 'near' | 'interior';

export interface Telemetry {
  speedKmh: number;
  rpm: number;
  gear: number;
  indicator: number;
  braking: boolean;
  headlights: boolean;
}

const PERIOD = 320;

// ── tiny seeded RNG so the scenery is the same every drive ───────────────
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function noiseTexture(base: string, speck: string[], size = 256, density = 0.35): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = size; c.height = size;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, size, size);
    const r = rng(7);
    for (let i = 0; i < size * size * density; i++) {
      ctx.fillStyle = speck[Math.floor(r() * speck.length)];
      ctx.globalAlpha = 0.15 + r() * 0.35;
      ctx.fillRect(Math.floor(r() * size), Math.floor(r() * size), 1 + Math.floor(r() * 2), 1 + Math.floor(r() * 2));
    }
    ctx.globalAlpha = 1;
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

function Instanced({ geometry, material, matrices, castShadow = true }: {
  geometry: THREE.BufferGeometry; material: THREE.Material; matrices: THREE.Matrix4[]; castShadow?: boolean;
}) {
  const ref = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    const m = ref.current;
    if (!m) return;
    matrices.forEach((mat, i) => m.setMatrixAt(i, mat));
    m.instanceMatrix.needsUpdate = true;
    m.computeBoundingSphere();
  }, [matrices]);
  return <instancedMesh ref={ref} args={[geometry, material, matrices.length]} castShadow={castShadow} receiveShadow frustumCulled={false} />;
}

const mat4 = (x: number, y: number, z: number, sx = 1, sy = 1, sz = 1, ry = 0) => {
  const o = new THREE.Object3D();
  o.position.set(x, y, z);
  o.scale.set(sx, sy, sz);
  o.rotation.y = ry;
  o.updateMatrix();
  return o.matrix.clone();
};

// ── an endless straight highway: content repeats every PERIOD metres ─────
function World({ carPos, night }: { carPos: MutableRefObject<{ x: number; z: number }>; night: boolean }) {
  const periodic = useRef<THREE.Group>(null);
  const ground = useRef<THREE.Mesh>(null);
  const backdrop = useRef<THREE.Group>(null);

  const tex = useMemo(() => {
    const grass = noiseTexture('#4f7d3b', ['#3f6a2f', '#5e8f46', '#47742f', '#6a9b4d'], 256, 0.5);
    grass.repeat.set(220, 220);
    const asphalt = noiseTexture('#3b3d42', ['#2c2e32', '#4a4d52', '#55585d', '#26282b'], 256, 0.6);
    asphalt.repeat.set(5, PERIOD * 3 / 6);
    return { grass, asphalt };
  }, []);

  const data = useMemo(() => {
    const r = rng(42);
    const dashes: THREE.Matrix4[] = [];
    for (let z = -PERIOD; z < PERIOD * 2; z += 12) {
      dashes.push(mat4(-3.6, 0.012, z, 0.16, 0.01, 5));
      dashes.push(mat4(3.6, 0.012, z, 0.16, 0.01, 5));
    }
    const lamps: THREE.Matrix4[] = [];
    const lampHeads: THREE.Matrix4[] = [];
    for (let z = -PERIOD; z < PERIOD * 2; z += 40) {
      lamps.push(mat4(-9.4, 4.2, z, 1, 1, 1));
      lampHeads.push(mat4(-8.4, 8.3, z, 1, 1, 1));
      lamps.push(mat4(9.4, 4.2, z + 20, 1, 1, 1));
      lampHeads.push(mat4(8.4, 8.3, z + 20, 1, 1, 1));
    }
    const trunks: THREE.Matrix4[] = [];
    const crowns: THREE.Matrix4[] = [];
    const crowns2: THREE.Matrix4[] = [];
    for (let i = 0; i < 170; i++) {
      const side = r() < 0.5 ? -1 : 1;
      const x = side * (13 + r() * 70);
      const z = -PERIOD + r() * PERIOD * 3;
      const s = 0.8 + r() * 1.0;
      trunks.push(mat4(x, 1.1 * s, z, s, s, s));
      crowns.push(mat4(x, 3.3 * s, z, s * 1.2, s * 1.2, s * 1.2));
      crowns2.push(mat4(x, 4.7 * s, z, s * 0.9, s * 0.9, s * 0.9));
    }
    const blocks: THREE.Matrix4[] = [];
    const windows: THREE.Matrix4[] = [];
    for (let i = 0; i < 46; i++) {
      const side = r() < 0.5 ? -1 : 1;
      const x = side * (95 + r() * 150);
      const z = -PERIOD + r() * PERIOD * 3;
      const w = 12 + r() * 22;
      const h = 14 + r() * 60;
      const d = 12 + r() * 22;
      blocks.push(mat4(x, h / 2, z, w, h, d));
      // a lit window band per building
      windows.push(mat4(x - side * (w / 2 + 0.05), h * 0.5, z, 0.1, h * 0.8, d * 0.8));
    }
    const rails: THREE.Matrix4[] = [mat4(-8.4, 0.5, PERIOD / 2, 0.08, 0.35, PERIOD * 3), mat4(8.4, 0.5, PERIOD / 2, 0.08, 0.35, PERIOD * 3)];
    const mountains: THREE.Matrix4[] = [];
    for (let i = 0; i < 18; i++) {
      const a = (i / 18) * Math.PI * 2;
      const dist = 900 + r() * 200;
      const s = 140 + r() * 180;
      mountains.push(mat4(Math.cos(a) * dist, s * 0.35, Math.sin(a) * dist, s * 1.3, s * 0.7, s * 1.3));
    }
    return { dashes, lamps, lampHeads, trunks, crowns, crowns2, blocks, windows, rails, mountains };
  }, []);

  const geo = useMemo(() => ({
    box: new THREE.BoxGeometry(1, 1, 1),
    pole: new THREE.CylinderGeometry(0.07, 0.1, 8.4, 8),
    trunk: new THREE.CylinderGeometry(0.16, 0.24, 2.2, 7),
    cone: new THREE.ConeGeometry(1.5, 3.0, 9),
    mount: new THREE.ConeGeometry(1, 2, 7),
  }), []);
  const mats = useMemo(() => ({
    white: new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.6 }),
    pole: new THREE.MeshStandardMaterial({ color: '#8a8f96', metalness: 0.7, roughness: 0.4 }),
    lampHead: new THREE.MeshStandardMaterial({ color: '#fff3cf', emissive: new THREE.Color('#ffe9a8'), emissiveIntensity: night ? 3 : 0.2, toneMapped: false }),
    trunk: new THREE.MeshStandardMaterial({ color: '#5a3d26', roughness: 0.95 }),
    leaf: new THREE.MeshStandardMaterial({ color: '#2f6b2c', roughness: 0.9 }),
    leaf2: new THREE.MeshStandardMaterial({ color: '#3d7d36', roughness: 0.9 }),
    building: new THREE.MeshStandardMaterial({ color: night ? '#1a2029' : '#9aa3ae', roughness: 0.7, metalness: 0.2 }),
    windows: new THREE.MeshStandardMaterial({ color: '#cfe6ff', emissive: new THREE.Color(night ? '#ffd88a' : '#7aa7d6'), emissiveIntensity: night ? 1.8 : 0.25, roughness: 0.2, metalness: 0.5, toneMapped: false }),
    rail: new THREE.MeshStandardMaterial({ color: '#b9bec5', metalness: 0.8, roughness: 0.35 }),
    dash: new THREE.MeshStandardMaterial({ color: '#f1f1ea', roughness: 0.6 }),
    mount: new THREE.MeshStandardMaterial({ color: night ? '#10141c' : '#7a8896', roughness: 1, fog: true }),
    edge: new THREE.MeshStandardMaterial({ color: '#f5f5f0', roughness: 0.6 }),
  }), [night]);

  useFrame(() => {
    const p = carPos.current;
    if (periodic.current) periodic.current.position.z = Math.floor(p.z / PERIOD) * PERIOD;
    if (ground.current) {
      ground.current.position.set(p.x, -0.02, p.z);
      const tile = 1400 / 220;
      tex.grass.offset.set((p.x / tile) % 1, (-p.z / tile) % 1);
    }
    if (backdrop.current) backdrop.current.position.set(p.x, 0, p.z);
  });

  return (
    <group>
      <mesh ref={ground} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[1400, 1400]} />
        <meshStandardMaterial map={tex.grass} roughness={1} color={night ? '#24301f' : '#ffffff'} />
      </mesh>
      <group ref={backdrop}>
        <Instanced geometry={geo.mount} material={mats.mount} matrices={data.mountains} castShadow={false} />
      </group>
      <group ref={periodic}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.004, PERIOD / 2]} receiveShadow>
          <planeGeometry args={[16, PERIOD * 3]} />
          <meshStandardMaterial map={tex.asphalt} roughness={0.85} metalness={0.05} color={night ? '#777' : '#ffffff'} />
        </mesh>
        {[-7.6, 7.6].map((x) => (
          <mesh key={x} position={[x, 0.01, PERIOD / 2]}>
            <boxGeometry args={[0.18, 0.01, PERIOD * 3]} />
            <primitive object={mats.edge} attach="material" />
          </mesh>
        ))}
        <Instanced geometry={geo.box} material={mats.dash} matrices={data.dashes} castShadow={false} />
        <Instanced geometry={geo.pole} material={mats.pole} matrices={data.lamps} />
        <Instanced geometry={geo.box} material={mats.lampHead} matrices={data.lampHeads.map((m) => {
          const o = new THREE.Object3D(); o.applyMatrix4(m); o.scale.set(1.6, 0.14, 0.5); o.updateMatrix(); return o.matrix.clone();
        })} castShadow={false} />
        <Instanced geometry={geo.trunk} material={mats.trunk} matrices={data.trunks} />
        <Instanced geometry={geo.cone} material={mats.leaf} matrices={data.crowns} />
        <Instanced geometry={geo.cone} material={mats.leaf2} matrices={data.crowns2} />
        <Instanced geometry={geo.box} material={mats.building} matrices={data.blocks} />
        <Instanced geometry={geo.box} material={mats.windows} matrices={data.windows} castShadow={false} />
        <Instanced geometry={geo.box} material={mats.rail} matrices={data.rails} />
      </group>
    </group>
  );
}

// ── engine note: a filtered saw wave that follows rpm ────────────────────
function useEngineSound(dv: MutableRefObject<DriveVisual>, muted: boolean) {
  const ctxRef = useRef<{ ctx: AudioContext; osc: OscillatorNode; osc2: OscillatorNode; gain: GainNode; filter: BiquadFilterNode } | null>(null);
  const mutedRef = useRef(muted);
  mutedRef.current = muted;

  useEffect(() => {
    const start = () => {
      if (ctxRef.current) return;
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AC();
        const osc = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();
        osc.type = 'sawtooth';
        osc2.type = 'square';
        filter.type = 'lowpass';
        filter.frequency.value = 600;
        gain.gain.value = 0;
        osc.connect(filter);
        osc2.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc2.start();
        ctxRef.current = { ctx, osc, osc2, gain, filter };
      } catch {
        /* audio is optional */
      }
    };
    window.addEventListener('keydown', start, { once: true });
    window.addEventListener('pointerdown', start, { once: true });
    return () => {
      window.removeEventListener('keydown', start);
      window.removeEventListener('pointerdown', start);
      try { ctxRef.current?.ctx.close(); } catch { /* ignore */ }
      ctxRef.current = null;
    };
  }, []);

  useFrame(() => {
    const a = ctxRef.current;
    if (!a) return;
    try {
      const d = dv.current;
      const f = 28 + (d.rpm / 60) * 1.0;
      a.osc.frequency.setTargetAtTime(f, a.ctx.currentTime, 0.04);
      a.osc2.frequency.setTargetAtTime(f * 0.5, a.ctx.currentTime, 0.04);
      a.filter.frequency.setTargetAtTime(380 + d.rpm * 0.35 + d.throttle * 500, a.ctx.currentTime, 0.05);
      const g = mutedRef.current ? 0 : 0.035 + d.throttle * 0.05 + (d.rpm / 8000) * 0.03;
      a.gain.gain.setTargetAtTime(g, a.ctx.currentTime, 0.06);
    } catch {
      /* ignore */
    }
  });
}

// ── the vehicle: physics, camera, lights ─────────────────────────────────
interface Phys {
  x: number; z: number; heading: number; speed: number; steer: number; pitch: number; roll: number;
  gear: number; rpm: number; lastSpeed: number; yaw: number; look: { yaw: number; pitch: number; dragging: boolean };
  indicator: number; headlights: boolean; edge: Record<string, boolean>; t: number; shake: number;
}

function Vehicle({
  model, report, keys, viewMode, night, muted, carPos, onTelemetry,
}: {
  model: CarModel; report: QualityReport; keys: MutableRefObject<Record<string, boolean>>;
  viewMode: ViewMode; night: boolean; muted: boolean;
  carPos: MutableRefObject<{ x: number; z: number }>;
  onTelemetry: (t: Telemetry) => void;
}) {
  const lay = useMemo(() => getCarLayout(model), [model]);
  const root = useRef<THREE.Group>(null);
  const chassis = useRef<THREE.Group>(null);
  const sun = useRef<THREE.DirectionalLight>(null);
  const spotL = useRef<THREE.SpotLight>(null);
  const spotR = useRef<THREE.SpotLight>(null);
  const tgt = useRef<THREE.Object3D>(null);
  const dv = useRef<DriveVisual>(makeDriveVisual());
  const { camera, gl } = useThree();
  const lastTele = useRef(0);
  const p = useRef<Phys>({
    x: 0, z: 0, heading: 0, speed: 0, steer: 0, pitch: 0, roll: 0, gear: 1, rpm: 900, lastSpeed: 0, yaw: 0,
    look: { yaw: 0, pitch: 0, dragging: false }, indicator: 0, headlights: false, edge: {}, t: 0, shake: 0,
  });

  const ep = Math.max(0.25, Math.min(1, report.engine / 100));
  const vmax = (110 + ep * 230) / 3.6;
  const grip = 0.55 + Math.max(0, Math.min(1, report.assembly / 100)) * 0.45;
  const lightsWork = report.electronics > 40;
  const wheelbase = lay.axleF - lay.axleR;
  const gearTops = useMemo(() => [0.13, 0.25, 0.4, 0.56, 0.76, 1.0].map((f) => f * vmax), [vmax]);

  useEngineSound(dv, muted);

  // mouse-look: drag to glance around the cabin, it springs back when released
  useEffect(() => {
    const el = gl.domElement;
    const down = (e: PointerEvent) => { if (e.button === 0 || e.button === 2) p.current.look.dragging = true; };
    const up = () => { p.current.look.dragging = false; };
    const move = (e: PointerEvent) => {
      const l = p.current.look;
      if (!l.dragging) return;
      l.yaw = THREE.MathUtils.clamp(l.yaw - e.movementX * 0.004, -2.4, 2.4);
      l.pitch = THREE.MathUtils.clamp(l.pitch - e.movementY * 0.004, -0.9, 0.9);
    };
    el.addEventListener('pointerdown', down);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointermove', move);
    return () => {
      el.removeEventListener('pointerdown', down);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointermove', move);
    };
  }, [gl]);

  useEffect(() => {
    if (spotL.current && tgt.current) spotL.current.target = tgt.current;
    if (spotR.current && tgt.current) spotR.current.target = tgt.current;
  }, []);

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const k = keys.current;
    const s = p.current;
    s.t += dt;

    // edge-triggered toggles
    const edge = (key: string) => {
      const down = !!k[key];
      const fire = down && !s.edge[key];
      s.edge[key] = down;
      return fire;
    };
    if (edge('q')) s.indicator = s.indicator === 1 ? 0 : 1;
    if (edge('e')) s.indicator = s.indicator === -1 ? 0 : -1;
    if (edge('l') && lightsWork) s.headlights = !s.headlights;
    if (edge('r')) { s.x = 0; s.z = 0; s.heading = 0; s.speed = 0; s.steer = 0; }

    const forwardKey = !!(k['w'] || k['arrowup']);
    const backKey = !!(k['s'] || k['arrowdown']);
    const handbrake = !!k[' '];
    const left = !!(k['a'] || k['arrowleft']);
    const right = !!(k['d'] || k['arrowright']);

    // ── longitudinal ──
    let accel = 0;
    let braking = handbrake;
    const v = s.speed;
    if (forwardKey) {
      if (v < -0.5) { accel = 12; braking = true; }
      else {
        const gi = Math.max(0, s.gear - 1);
        const lowGearBoost = 1 + 0.35 * (1 - gi / 5);
        accel = (4 + 9 * ep) * lowGearBoost * Math.max(0, 1 - Math.pow(Math.max(0, v) / vmax, 2));
      }
    } else if (backKey) {
      if (v > 0.5) { accel = -12 * (0.7 + 0.3 * grip); braking = true; }
      else accel = -(3 + 3 * ep) * Math.max(0, 1 - Math.pow(Math.abs(v) / 7, 2));
    }
    if (handbrake) accel = -Math.sign(v) * Math.min(Math.abs(v) / dt, 13);
    if (!forwardKey && !backKey && !handbrake) accel = -Math.sign(v) * (0.5 + 0.0035 * v * v);
    s.speed += accel * dt;
    if (!forwardKey && !backKey && Math.abs(s.speed) < 0.08) s.speed = 0;
    if (handbrake && Math.abs(s.speed) < 0.1) s.speed = 0;
    s.speed = THREE.MathUtils.clamp(s.speed, -8, vmax * 1.02);

    // ── steering (a real wheel angle that shrinks with speed) ──
    const target = (left ? 1 : 0) - (right ? 1 : 0);
    s.steer += (target - s.steer) * Math.min(1, (target === 0 ? 7 : 3.6) * dt);
    const av = Math.abs(s.speed);
    const lim = Math.max(0.1, 1 / (1 + Math.pow(av / 20, 2)));
    const wobble = (1 - grip) * 0.03 * Math.sin(s.t * 11) * Math.min(1, av / 10);
    const wheelAngle = s.steer * 0.55 * lim + wobble;
    const yawRate = (s.speed / wheelbase) * Math.tan(wheelAngle);
    s.heading += yawRate * dt;
    s.x += Math.sin(s.heading) * s.speed * dt;
    s.z += Math.cos(s.heading) * s.speed * dt;

    // ── gearbox & rpm ──
    if (s.speed < -0.1) s.gear = -1;
    else {
      let g = gearTops.length;
      for (let i = 0; i < gearTops.length; i++) { if (s.speed <= gearTops[i] * 0.96) { g = i + 1; break; } }
      if (s.gear < 1) s.gear = 1;
      // hysteresis: shift up at once, shift down only when clearly below the lower gear's band
      if (g > s.gear) s.gear = g;
      else if (g < s.gear && s.speed < (gearTops[s.gear - 2] ?? 0) * 0.85) s.gear = g;
    }
    const gTop = s.gear > 0 ? gearTops[s.gear - 1] : 7;
    const targetRpm = 900 + (Math.min(1, av / gTop)) * 6600 + (forwardKey ? 300 : 0);
    s.rpm += (targetRpm - s.rpm) * Math.min(1, 9 * dt);

    // ── body attitude ──
    const longA = (s.speed - s.lastSpeed) / Math.max(dt, 0.001);
    s.lastSpeed = s.speed;
    const latA = s.speed * yawRate;
    s.pitch += ((-longA * 0.0065) - s.pitch) * Math.min(1, 6 * dt);
    s.roll += ((latA * 0.007) - s.roll) * Math.min(1, 6 * dt);
    const bump = (Math.sin(s.t * 38) * 0.5 + Math.sin(s.t * 23.7) * 0.5) * Math.min(1, av / 30) * (0.0025 + (1 - grip) * 0.004);

    // ── publish visual state ──
    const d = dv.current;
    d.speedKmh = av * 3.6;
    d.rpm = s.rpm;
    d.gear = s.gear;
    d.steer = THREE.MathUtils.clamp(wheelAngle / 0.5, -1.2, 1.2);
    d.wheelSpin += (s.speed * dt) / lay.wheelR;
    d.braking = braking && av > 0.3;
    d.headlights = s.headlights;
    d.reversing = s.speed < -0.2;
    d.indicator = s.indicator;
    d.throttle = forwardKey ? 1 : 0;
    carPos.current.x = s.x;
    carPos.current.z = s.z;

    if (root.current) {
      root.current.position.set(s.x, 0, s.z);
      root.current.rotation.y = s.heading;
    }
    if (chassis.current) chassis.current.rotation.set(s.pitch + bump, 0, s.roll);

    // ── lights ──
    const lightOn = s.headlights && lightsWork;
    if (spotL.current) spotL.current.intensity = lightOn ? 220 : 0;
    if (spotR.current) spotR.current.intensity = lightOn ? 220 : 0;
    if (sun.current) {
      sun.current.position.set(s.x + 30, 45, s.z + 20);
      sun.current.target.position.set(s.x, 0, s.z);
      sun.current.target.updateMatrixWorld();
    }

    // ── camera ──
    const cam = camera as THREE.PerspectiveCamera;
    const sm = 1 - Math.pow(0.0008, dt);
    const fwd = new THREE.Vector3(Math.sin(s.heading), 0, Math.cos(s.heading));
    const targetFov = viewMode === 'interior' ? 74 + Math.min(14, av * 0.18) : 56 + Math.min(10, av * 0.12);
    if (Math.abs(cam.fov - targetFov) > 0.05) {
      cam.fov += (targetFov - cam.fov) * Math.min(1, 4 * dt);
      cam.updateProjectionMatrix();
    }
    if (viewMode === 'interior') {
      cam.near = 0.04;
      if (!s.look.dragging) {
        s.look.yaw += (0 - s.look.yaw) * Math.min(1, 5 * dt);
        s.look.pitch += (0 - s.look.pitch) * Math.min(1, 5 * dt);
      }
      if (chassis.current) {
        const bob = Math.sin(s.t * 14) * 0.0015 * Math.min(1, av / 15);
        const eye = new THREE.Vector3(lay.eye[0] - latA * 0.0012, lay.eye[1] + bob, lay.eye[2] - longA * 0.0012);
        chassis.current.updateWorldMatrix(true, false);
        eye.applyMatrix4(chassis.current.matrixWorld);
        cam.position.copy(eye);
        const q = new THREE.Quaternion();
        chassis.current.getWorldQuaternion(q);
        const lookQ = new THREE.Quaternion().setFromEuler(new THREE.Euler(s.look.pitch, s.look.yaw, 0, 'YXZ'));
        const flip = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI);
        cam.quaternion.copy(q).multiply(lookQ).multiply(flip);
      }
    } else {
      cam.near = 0.1;
      const back = viewMode === 'far' ? lay.L * 0.5 + 6.5 : lay.L * 0.5 + 3.4;
      const height = viewMode === 'far' ? 3.2 : 1.55;
      const want = new THREE.Vector3(s.x, height, s.z).sub(fwd.clone().multiplyScalar(back));
      cam.position.lerp(want, sm);
      cam.lookAt(s.x + fwd.x * 3, viewMode === 'far' ? 0.9 : 0.8, s.z + fwd.z * 3);
    }

    // ── telemetry for the DOM HUD (≈10 Hz) ──
    if (state.clock.elapsedTime - lastTele.current > 0.1) {
      lastTele.current = state.clock.elapsedTime;
      onTelemetry({ speedKmh: d.speedKmh, rpm: d.rpm, gear: d.gear, indicator: d.indicator, braking: d.braking, headlights: d.headlights });
    }
  });

  const hl = lay.L / 2;
  const hy = lay.beltY * 0.66 + 0.05;
  return (
    <>
      <directionalLight
        ref={sun}
        intensity={night ? 0.25 : 2.6}
        color={night ? '#8fa8ff' : '#fff4e0'}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-24}
        shadow-camera-right={24}
        shadow-camera-top={24}
        shadow-camera-bottom={-24}
        shadow-camera-near={1}
        shadow-camera-far={140}
        shadow-bias={-0.0005}
        shadow-normalBias={0.05}
      />
      <group ref={root}>
        <group ref={chassis}>
          <CarBodyMesh model={model} driveRef={dv} interior />
          <spotLight ref={spotL} position={[lay.W * 0.33, hy, hl]} angle={0.5} penumbra={0.7} distance={70} decay={1.6} intensity={0} color="#fff3d6" />
          <spotLight ref={spotR} position={[-lay.W * 0.33, hy, hl]} angle={0.5} penumbra={0.7} distance={70} decay={1.6} intensity={0} color="#fff3d6" />
          <object3D ref={tgt} position={[0, 0.2, hl + 20]} />
        </group>
      </group>
    </>
  );
}

export default function DriveScene({
  model, report, viewMode, keysRef, night, muted, onTelemetry,
}: {
  model: CarModel; report: QualityReport; viewMode: ViewMode;
  keysRef: MutableRefObject<Record<string, boolean>>;
  night: boolean; muted: boolean;
  onTelemetry: (t: Telemetry) => void;
}) {
  const carPos = useRef({ x: 0, z: 0 });
  return (
    <Canvas
      shadows="soft"
      camera={{ position: [0, 3, -10], fov: 56, near: 0.1, far: 3000 }}
      dpr={[1, 2]}
      gl={{ antialias: true, powerPreference: 'high-performance', toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: night ? 0.9 : 1.0 }}
    >
      {night ? (
        <>
          <color attach="background" args={['#05080f']} />
          <fog attach="fog" args={['#05080f', 40, 380]} />
        </>
      ) : (
        <>
          <Sky distance={4500} sunPosition={[30, 45, 20]} turbidity={6} rayleigh={1.6} mieCoefficient={0.006} mieDirectionalG={0.85} />
          <fog attach="fog" args={['#cfdbe8', 120, 760]} />
        </>
      )}
      <ambientLight intensity={night ? 0.08 : 0.35} />
      <hemisphereLight args={night ? ['#223355', '#0a0c10', 0.35] : ['#cfe3ff', '#6b7a55', 0.55]} />
      <World carPos={carPos} night={night} />
      <Vehicle
        model={model} report={report} keys={keysRef} viewMode={viewMode} night={night} muted={muted}
        carPos={carPos} onTelemetry={onTelemetry}
      />
      <Environment preset={night ? 'night' : 'park'} background={false} />
    </Canvas>
  );
}
