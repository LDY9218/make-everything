import type { CarOption } from '../types';

export const CAR_OPTIONS: CarOption[] = [
  // Engine
  { id: 'engine-w16', category: 'engine', name: 'W16 쿼드터보 엔진', description: '16기통 쿼드터보 엔진. 최고 수준의 출력을 내지만 제작 난이도가 매우 높다.', difficulty: 5, extraMinutes: 90, addsProcessSteps: ['engine-block-w16', 'engine-assembly-w16'] },
  { id: 'engine-v12', category: 'engine', name: 'V12 자연흡기 엔진', description: '부드러운 출력 특성의 12기통 엔진.', difficulty: 4, extraMinutes: 70, addsProcessSteps: ['engine-block-v12', 'engine-assembly-v12'] },
  { id: 'engine-v10', category: 'engine', name: 'V10 고회전 엔진', description: '고회전 영역에서 강력한 출력을 내는 10기통 엔진.', difficulty: 5, extraMinutes: 80, addsProcessSteps: ['engine-block-v10', 'engine-assembly-v10'] },
  { id: 'engine-v8-twin', category: 'engine', name: 'V8 트윈터보 엔진', description: '균형 잡힌 성능의 8기통 트윈터보 엔진.', difficulty: 4, extraMinutes: 60, addsProcessSteps: ['engine-block-v8', 'engine-assembly-v8'] },
  { id: 'engine-i6-turbo', category: 'engine', name: '직렬 6기통 터보 엔진', description: '효율성과 성능의 균형이 좋은 직렬 6기통.', difficulty: 3, extraMinutes: 45, addsProcessSteps: ['engine-block-i6', 'engine-assembly-i6'] },
  { id: 'engine-i4-standard', category: 'engine', name: '직렬 4기통 표준 엔진', description: '가장 기본적인 구조의 4기통 엔진. 입문자에게 적합.', difficulty: 2, extraMinutes: 30, addsProcessSteps: ['engine-block-i4', 'engine-assembly-i4'] },

  // Transmission
  { id: 'trans-dct7', category: 'transmission', name: '7단 듀얼클러치 변속기', description: '빠른 변속이 가능한 듀얼클러치 변속기.', difficulty: 4, extraMinutes: 35, addsProcessSteps: ['transmission-dct'] },
  { id: 'trans-auto8', category: 'transmission', name: '8단 자동변속기', description: '부드러운 변속감의 8단 자동변속기.', difficulty: 3, extraMinutes: 25, addsProcessSteps: ['transmission-auto'] },
  { id: 'trans-auto6', category: 'transmission', name: '6단 자동변속기', description: '표준적인 6단 자동변속기.', difficulty: 2, extraMinutes: 20, addsProcessSteps: ['transmission-auto'] },
  { id: 'trans-manual6', category: 'transmission', name: '6단 수동변속기', description: '직접 조작하는 수동변속기.', difficulty: 3, extraMinutes: 25, addsProcessSteps: ['transmission-manual'] },

  // Brakes
  { id: 'brakes-carbon-ceramic', category: 'brakes', name: '카본 세라믹 브레이크', description: '내열성이 뛰어난 고성능 브레이크 시스템.', difficulty: 5, extraMinutes: 30, addsProcessSteps: ['brakes-install'] },
  { id: 'brakes-performance', category: 'brakes', name: '고성능 브레이크', description: '향상된 제동력의 브레이크 시스템.', difficulty: 3, extraMinutes: 20, addsProcessSteps: ['brakes-install'] },
  { id: 'brakes-standard', category: 'brakes', name: '표준 브레이크', description: '기본적인 디스크 브레이크 시스템.', difficulty: 2, extraMinutes: 15, addsProcessSteps: ['brakes-install'] },

  // Wheels
  { id: 'wheels-forged-20', category: 'wheels', name: '단조 휠 20인치', description: '가볍고 강성이 높은 단조 알루미늄 휠.', difficulty: 4, extraMinutes: 20, addsProcessSteps: ['wheels-install'] },
  { id: 'wheels-forged-19', category: 'wheels', name: '단조 휠 19인치', description: '가볍고 강성이 높은 단조 알루미늄 휠.', difficulty: 3, extraMinutes: 18, addsProcessSteps: ['wheels-install'] },
  { id: 'wheels-chrome-21', category: 'wheels', name: '크롬 휠 21인치', description: '화려한 크롬 마감의 대형 휠.', difficulty: 3, extraMinutes: 20, addsProcessSteps: ['wheels-install'] },
  { id: 'wheels-alloy-18', category: 'wheels', name: '알로이 휠 18인치', description: '가성비 좋은 알루미늄 합금 휠.', difficulty: 2, extraMinutes: 15, addsProcessSteps: ['wheels-install'] },
  { id: 'wheels-alloy-17', category: 'wheels', name: '알로이 휠 17인치', description: '기본형 알루미늄 합금 휠.', difficulty: 1, extraMinutes: 12, addsProcessSteps: ['wheels-install'] },

  // Tires
  { id: 'tires-performance', category: 'tires', name: '퍼포먼스 타이어', description: '그립력이 뛰어난 고성능 타이어.', difficulty: 2, extraMinutes: 10, addsProcessSteps: ['tires-install'] },
  { id: 'tires-comfort', category: 'tires', name: '컴포트 타이어', description: '승차감을 중시한 타이어.', difficulty: 1, extraMinutes: 10, addsProcessSteps: ['tires-install'] },
  { id: 'tires-allterrain', category: 'tires', name: '올터레인 타이어', description: '다양한 노면에 대응하는 타이어.', difficulty: 2, extraMinutes: 10, addsProcessSteps: ['tires-install'] },

  // Suspension
  { id: 'susp-adaptive', category: 'suspension', name: '적응형 서스펜션', description: '주행 상황에 맞춰 감쇠력을 조절하는 서스펜션.', difficulty: 4, extraMinutes: 30, addsProcessSteps: ['suspension-install'] },
  { id: 'susp-air', category: 'suspension', name: '에어 서스펜션', description: '공기 압력으로 승차감을 조절하는 서스펜션.', difficulty: 4, extraMinutes: 30, addsProcessSteps: ['suspension-install'] },
  { id: 'susp-sport', category: 'suspension', name: '스포츠 서스펜션', description: '단단한 감쇠력의 스포츠 세팅 서스펜션.', difficulty: 3, extraMinutes: 22, addsProcessSteps: ['suspension-install'] },
  { id: 'susp-standard', category: 'suspension', name: '표준 서스펜션', description: '기본적인 맥퍼슨 스트럿 서스펜션.', difficulty: 2, extraMinutes: 18, addsProcessSteps: ['suspension-install'] },

  // Navigation (electronics)
  { id: 'nav-premium', category: 'navigation', name: '프리미엄 내비게이션', description: '대형 디스플레이와 고급 회로를 사용하는 내비게이션.', difficulty: 4, extraMinutes: 40, addsProcessSteps: ['nav-circuit', 'nav-assembly'] },
  { id: 'nav-standard', category: 'navigation', name: '표준 내비게이션', description: '기본형 내비게이션 시스템.', difficulty: 2, extraMinutes: 25, addsProcessSteps: ['nav-circuit', 'nav-assembly'] },

  // Dashboard
  { id: 'dash-digital', category: 'dashboard', name: '풀 디지털 계기판', description: '전체 디지털 디스플레이로 구성된 계기판.', difficulty: 3, extraMinutes: 25, addsProcessSteps: ['dashboard-circuit'] },
  { id: 'dash-analog-digital', category: 'dashboard', name: '아날로그-디지털 계기판', description: '아날로그 바늘과 디지털 정보를 함께 표시.', difficulty: 2, extraMinutes: 18, addsProcessSteps: ['dashboard-circuit'] },

  // Audio
  { id: 'audio-premium', category: 'audio', name: '프리미엄 오디오', description: '다수의 스피커와 앰프로 구성된 고급 오디오 시스템.', difficulty: 2, extraMinutes: 15, addsProcessSteps: ['audio-install'] },
  { id: 'audio-standard', category: 'audio', name: '표준 오디오', description: '기본형 오디오 시스템.', difficulty: 1, extraMinutes: 10, addsProcessSteps: ['audio-install'] },

  // Seats
  { id: 'seats-carbon-bucket', category: 'seats', name: '카본 버킷 시트', description: '경량 카본 쉘로 제작된 레이싱 시트.', difficulty: 4, extraMinutes: 25, addsProcessSteps: ['seats-install'] },
  { id: 'seats-leather-lounge', category: 'seats', name: '가죽 라운지 시트', description: '편안함을 극대화한 가죽 시트.', difficulty: 2, extraMinutes: 20, addsProcessSteps: ['seats-install'] },
  { id: 'seats-sport', category: 'seats', name: '스포츠 시트', description: '측면 지지력이 강화된 시트.', difficulty: 3, extraMinutes: 20, addsProcessSteps: ['seats-install'] },
  { id: 'seats-cloth', category: 'seats', name: '패브릭 시트', description: '기본형 패브릭 시트.', difficulty: 1, extraMinutes: 15, addsProcessSteps: ['seats-install'] },

  // Steering wheel
  { id: 'wheel-alcantara', category: 'steeringWheel', name: '알칸타라 스티어링 휠', description: '그립감이 뛰어난 알칸타라 소재 핸들.', difficulty: 2, extraMinutes: 10, addsProcessSteps: ['steering-install'] },
  { id: 'wheel-leather', category: 'steeringWheel', name: '가죽 스티어링 휠', description: '고급 가죽으로 마감된 핸들.', difficulty: 1, extraMinutes: 8, addsProcessSteps: ['steering-install'] },
  { id: 'wheel-wood-leather', category: 'steeringWheel', name: '우드&가죽 스티어링 휠', description: '원목과 가죽을 조합한 클래식한 핸들.', difficulty: 2, extraMinutes: 10, addsProcessSteps: ['steering-install'] },

  // Exterior color
  { id: 'color-custom', category: 'exteriorColor', name: '커스텀 도장', description: '차체를 원하는 색상으로 도장한다.', difficulty: 1, extraMinutes: 15, addsProcessSteps: ['paint-body'] },

  // Lighting
  { id: 'light-matrix-led', category: 'lighting', name: '매트릭스 LED 헤드라이트', description: '구역별로 점멸을 제어하는 고급 헤드라이트.', difficulty: 3, extraMinutes: 20, addsProcessSteps: ['lighting-circuit'] },
  { id: 'light-led', category: 'lighting', name: 'LED 헤드라이트', description: '표준 LED 헤드라이트.', difficulty: 2, extraMinutes: 14, addsProcessSteps: ['lighting-circuit'] },

  // Electronics
  { id: 'elec-track-telemetry', category: 'electronics', name: '트랙 텔레메트리 시스템', description: '주행 데이터를 기록하는 고급 전자장치.', difficulty: 4, extraMinutes: 30, addsProcessSteps: ['telemetry-circuit'] },
  { id: 'elec-driver-assist', category: 'electronics', name: '운전자 보조 시스템', description: '센서 기반의 운전 보조 전자장치.', difficulty: 3, extraMinutes: 25, addsProcessSteps: ['driver-assist-circuit'] },

  // Safety
  { id: 'safety-advanced', category: 'safety', name: '고급 안전장치', description: '다중 에어백과 센서가 포함된 안전 시스템.', difficulty: 3, extraMinutes: 20, addsProcessSteps: ['safety-install'] },
  { id: 'safety-standard', category: 'safety', name: '표준 안전장치', description: '기본형 안전벨트와 에어백 시스템.', difficulty: 1, extraMinutes: 12, addsProcessSteps: ['safety-install'] },
];

export function getOption(id: string): CarOption | undefined {
  return CAR_OPTIONS.find((o) => o.id === id);
}

export function getOptionsByIds(ids: string[]): CarOption[] {
  return ids.map(getOption).filter((o): o is CarOption => !!o);
}
