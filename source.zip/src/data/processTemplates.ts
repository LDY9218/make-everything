import type { ProcessStepDef, CarModel, InteractionKind } from '../types';
import { getOptionsByIds } from './carOptions';

function step(
  id: string,
  category: ProcessStepDef['category'],
  title: string,
  taskDescription: string,
  materials: string[],
  tools: string[],
  goal: string,
  completionCondition: string,
  estimatedMinutes: number,
  interaction: InteractionKind,
): ProcessStepDef {
  return { id, order: 0, category, title, taskDescription, materials, tools, goal, completionCondition, estimatedMinutes, interaction };
}

// ── Base steps every car always goes through ───────────────────────────
// Every entry in `materials` is expanded by the assembly station into
// individual units ("피스톤 x16" → sixteen separate pistons), and each unit
// is then made by hand, task by task (see manufacturing/recipes.ts).
const BASE_STEPS: ProcessStepDef[] = [
  step(
    'raw-steel', 'rawMaterial', '철 원재료 준비',
    '철괴를 녹여 틀에 붓고, 압연기로 한 구간씩 밀어 강판 슬래브를 만든다. 슬래브 하나하나를 직접 주조하고 압연해야 한다.',
    ['강판 슬래브 x4'], ['용해로', '압연기'],
    '균일한 두께의 강판 슬래브 확보', '슬래브 4장 전량 주조·압연 완료',
    8, 'sheetMetalForming',
  ),
  step(
    'body-panels', 'bodyPanel', '차체 패널 가공',
    '각 패널의 틀을 조각해 주조하고, 프레스로 곡면을 만들고, 가장자리를 자르고, 표면을 연마한 뒤 차체에 올려 용접한다.',
    ['후드 패널', '프론트 펜더 패널 x2', '도어 패널 x2', '루프 패널', '트렁크 패널'], ['절단기', '프레스 금형', '표면 연마기', '용접 토치'],
    '차체 실루엣에 맞는 패널 세트 제작', '모든 패널 제작·장착·용접 완료',
    20, 'sheetMetalForming',
  ),
  step(
    'body-frame', 'frame', '프레임 제작 및 패널 접합',
    '프레임 빔, 크로스 멤버, 사이드 레일을 하나씩 주조·가공하고 차체에 올려 이음 부위를 용접한다.',
    ['프레임 빔 x4', '크로스 멤버 x2', '사이드 레일 x2'], ['용접기', '정렬 지그'],
    '뒤틀림 없는 차체 쉘 완성', '모든 프레임 부재 장착 및 용접 완료',
    25, 'componentAssembly',
  ),
  step(
    'fasteners-body', 'fasteners', '차체 체결용 나사 제작',
    '나사를 한 개씩 주조하고 나사산을 깎은 뒤, 차체에 올려 드라이버로 한 칸씩 조여 체결한다.',
    ['차체 체결 나사 x12'], ['나사 가공기', '체결 공구'],
    '필요 수량만큼 나사 제작 및 체결', '규격 나사 전량 체결 완료',
    12, 'fastenerInstallation',
  ),
  step(
    'interior-base', 'interior', '내부 기본 골격 제작',
    '플로어 패널과 내부 프레임 빔, 대시보드 크로스 빔을 하나씩 만들어 장착한다.',
    ['플로어 패널 x2', '인테리어 프레임 빔 x2', '대시보드 크로스 빔'], ['사출 성형기', '절단기'],
    '내부 기본 골격 완성', '모든 내부 마운트 포인트 고정',
    15, 'componentAssembly',
  ),
  step(
    'final-assembly', 'finalAssembly', '최종 조립',
    '엔진·변속기·서브프레임·시트 레일 등 큰 조립체를 고정하는 볼트를 한 개씩 토크 렌치로 조인다. 장착하지 않은 부품이 남아 있으면 감점된다.',
    ['엔진 마운트 볼트 x4', '변속기 마운트 볼트 x2', '서브프레임 볼트 x4', '시트 레일 볼트 x4', '스티어링 컬럼 볼트 x2', '배터리 단자 볼트 x2'], ['조립 리프트', '토크 렌치'],
    '모든 부품 정위치 조립', '필수 볼트 전량 체결 및 부품 전량 장착',
    30, 'finalAssemblyPlacement',
  ),
  step(
    'final-inspection', 'finalAssembly', '최종 검사',
    '완성된 차량의 치수, 체결 상태, 전자장치 작동 여부를 검사한다.',
    [], ['측정 장비', '진단 스캐너'],
    '출고 가능 품질 확인', '검사 항목 전체 확인 완료',
    10, 'inspection',
  ),
];

// ── Option-triggered step templates ─────────────────────────────────────
interface EngineVariant { label: string; pistons: number; cams: number; turbo: string | null; minutes: number }
const ENGINE_VARIANTS: Record<string, EngineVariant> = {
  w16: { label: 'W16', pistons: 16, cams: 4, turbo: '쿼드터보 유닛', minutes: 45 },
  v12: { label: 'V12', pistons: 12, cams: 2, turbo: null, minutes: 38 },
  v10: { label: 'V10', pistons: 10, cams: 2, turbo: '터보 유닛', minutes: 36 },
  v8: { label: 'V8', pistons: 8, cams: 2, turbo: '트윈터보 유닛', minutes: 30 },
  i6: { label: 'I6', pistons: 6, cams: 1, turbo: '터보 유닛', minutes: 24 },
  i4: { label: 'I4', pistons: 4, cams: 1, turbo: null, minutes: 18 },
};

function engineSteps(key: keyof typeof ENGINE_VARIANTS): ProcessStepDef[] {
  const v = ENGINE_VARIANTS[key];
  const cams = v.cams > 1 ? `캠축 x${v.cams}` : '캠축';
  const parts = [
    `피스톤 x${v.pistons}`, `커넥팅 로드 x${v.pistons}`, '크랭크축', cams,
    `점화 플러그 x${v.pistons}`, `실린더 헤드 볼트 x${Math.max(8, v.pistons)}`,
    ...(v.turbo ? [v.turbo] : []),
  ];
  return [
    step(
      `engine-block-${key}`, 'engine', `엔진 블록 제작 (${v.label})`,
      '틀을 조각해 엔진 블록을 주조하고, 실린더 보어를 뚫고 호닝하고, 상면을 평탄하게 갈아 낸 뒤 차대에 올린다.',
      ['실린더 블록'], ['정밀 보링 머신', '연마기'],
      '정밀 가공된 실린더 블록 완성', '블록 주조·보어 가공·호닝·평탄화·장착 완료',
      v.minutes, 'sheetMetalForming',
    ),
    step(
      `engine-assembly-${key}`, 'engine', `엔진 조립 (${v.label})`,
      `${v.pistons}개의 피스톤과 커넥팅 로드를 하나씩 주조·가공하고, 크랭크축·캠축·점화 플러그·터보까지 모든 부품을 직접 만들어 블록에 조립한다. 한 개라도 빠지거나 거칠게 만들면 엔진 성능이 떨어진다.`,
      parts, ['조립 지그', '토크 렌치'],
      '모든 엔진 부품 정상 조립', '피스톤/크랭크축/캠축 결합 및 체결 완료',
      v.minutes + 10, 'componentAssembly',
    ),
  ];
}

const OPTION_STEP_TEMPLATES: Record<string, ProcessStepDef[]> = {
  'engine-block-w16': engineSteps('w16'), 'engine-assembly-w16': [],
  'engine-block-v12': engineSteps('v12'), 'engine-assembly-v12': [],
  'engine-block-v10': engineSteps('v10'), 'engine-assembly-v10': [],
  'engine-block-v8': engineSteps('v8'), 'engine-assembly-v8': [],
  'engine-block-i6': engineSteps('i6'), 'engine-assembly-i6': [],
  'engine-block-i4': engineSteps('i4'), 'engine-assembly-i4': [],

  'transmission-dct': [step('transmission-dct', 'engine', '듀얼클러치 변속기 조립', '변속기 하우징, 클러치 팩, 기어 세트, 유압 유닛과 유압 라인을 하나씩 만들어 조립한다.', ['변속기 하우징', '클러치 팩 x2', '기어 세트 x7', '유압 유닛', '유압 라인 x2', '하우징 볼트 x6'], ['조립 지그'], '변속기 완성 및 엔진 연결', '기어 단수 전체 정상 결합', 25, 'componentAssembly')],
  'transmission-auto': [step('transmission-auto', 'engine', '자동변속기 조립', '토크 컨버터와 유성기어 세트, 유압 유닛을 하나씩 만들어 조립한다.', ['변속기 하우징', '토크 컨버터', '유성기어 세트 x3', '유압 유닛', '하우징 볼트 x6'], ['조립 지그'], '변속기 완성 및 엔진 연결', '기어 단수 전체 정상 결합', 20, 'componentAssembly')],
  'transmission-manual': [step('transmission-manual', 'engine', '수동변속기 조립', '클러치판과 기어 세트, 변속기 하우징을 하나씩 만들어 조립한다.', ['변속기 하우징', '클러치판', '기어 세트 x6', '하우징 볼트 x6'], ['조립 지그'], '변속기 완성 및 엔진 연결', '기어 단수 전체 정상 결합', 20, 'componentAssembly')],

  'brakes-install': [step('brakes-install', 'frame', '브레이크 시스템 조립', '브레이크 디스크, 캘리퍼, 유압 라인을 바퀴마다 하나씩 만들어 조립한다.', ['브레이크 디스크 x4', '캘리퍼 x4', '유압 라인 x4'], ['조립 공구'], '4륜 브레이크 정상 체결', '브레이크 라인 연결 및 체결 완료', 18, 'componentAssembly')],
  'wheels-install': [step('wheels-install', 'frame', '휠 제작 및 장착', '휠을 한 개씩 주조하고 선반으로 깎아 허브 구멍을 뚫고 연마한 뒤 장착해 너트를 조인다.', ['휠 x4'], ['주조기', '가공기'], '4개 휠 정상 장착', '휠 너트 전량 체결', 14, 'fastenerInstallation')],
  'tires-install': [step('tires-install', 'frame', '타이어 장착', '타이어 고무를 틀에 부어 가황하고 트레드를 다듬은 뒤, 장착해 공기를 넣는다.', ['타이어 x4'], ['타이어 장착기'], '4개 타이어 정상 장착', '타이어 공기압 정상 범위', 8, 'componentAssembly')],
  'suspension-install': [step('suspension-install', 'frame', '서스펜션 조립', '쇼크업소버, 스프링, 서스펜션 암을 바퀴마다 하나씩 만들어 조립한다.', ['쇼크업소버 x4', '스프링 x4', '서스펜션 암 x4'], ['조립 지그'], '4륜 서스펜션 정상 장착', '모든 마운트 체결 완료', 20, 'componentAssembly')],

  'nav-circuit': [step('nav-circuit', 'electronics', '내비게이션 회로 제작', '회로 기판을 자르고 구멍을 뚫어 패턴을 납땜하고, 칩과 커넥터, 전원 전선과 신호 전선을 한 가닥씩 직접 만들어 연결한다. 전원 전선이 빠지면 화면이 켜지지 않는다.', ['회로 기판', '프로세서 칩', '메모리 칩', '커넥터', '전원 전선', '신호 전선 x3'], ['납땜 인두', '회로 테스터'], '정상 작동하는 내비게이션 회로 완성', '전원/신호 경로 연결 확인', 22, 'circuitAssembly')],
  'nav-assembly': [step('nav-assembly', 'electronics', '내비게이션 화면 조립', '디스플레이와 입력장치를 만들고 전원 전선을 직접 만들어 연결한다.', ['디스플레이 패널', '터치 입력장치', '디스플레이 전원 전선'], ['조립 지그'], '내비게이션 유닛 완성', '화면 정상 점등 확인', 14, 'componentAssembly')],

  'dashboard-circuit': [step('dashboard-circuit', 'electronics', '계기판 회로 구성', '계기판용 회로 기판과 칩, 센서 커넥터, 전선을 한 가닥씩 만들어 연결한다.', ['회로 기판', '마이크로컨트롤러 칩', '센서 커넥터 x2', '전원 전선', '신호 전선 x2'], ['납땜 인두', '회로 테스터'], '정상 작동하는 계기판 완성', '신호 경로 연결 및 작동 테스트 통과', 18, 'circuitAssembly')],
  'audio-install': [step('audio-install', 'electronics', '오디오 시스템 조립', '스피커와 앰프를 만들고, 전원 전선과 스피커 신호 전선을 한 가닥씩 만들어 배선한다.', ['스피커 x4', '앰프', '앰프 전원 전선', '스피커 신호 전선 x4'], ['배선 공구'], '오디오 시스템 작동', '전원 및 신호선 연결 완료', 10, 'componentAssembly')],
  'seats-install': [step('seats-install', 'interior', '시트 제작 및 장착', '시트 프레임을 만들고, 쿠션재와 커버재를 재단해 한 땀 한 땀 박음질한 뒤 장착한다.', ['시트 프레임 x2', '쿠션재 x2', '커버재 x2'], ['재봉기', '고정 공구'], '시트 정상 장착', '시트 레일 체결 완료', 14, 'componentAssembly')],
  'steering-install': [step('steering-install', 'interior', '스티어링 휠 조립', '스티어링 림을 주조하고 가죽을 한 땀씩 박음질해 감은 뒤, 컬럼과 결합한다.', ['스티어링 휠', '스티어링 컬럼'], ['조립 공구'], '핸들 정상 작동', '컬럼 체결 및 회전 테스트 통과', 8, 'componentAssembly')],
  'paint-body': [step('paint-body', 'bodyPanel', '차체 도장', '프라이머, 베이스 컬러, 클리어코트를 차례로 직접 연마·분사·건조한다.', ['프라이머 도장', '베이스 컬러 도장', '클리어코트 도장'], ['도장 부스', '스프레이건'], '균일한 도장 마감', '도장 균일도 90% 이상', 15, 'sheetMetalForming')],
  'lighting-circuit': [step('lighting-circuit', 'electronics', '조명 회로 구성', 'LED 모듈과 회로 기판, 전원 전선, 신호 전선을 한 가닥씩 만들어 연결한다.', ['회로 기판', 'LED 모듈 x4', '전원 전선', '신호 전선 x2'], ['납땜 인두', '회로 테스터'], '전조등/후미등 정상 점등', '전원 연결 및 점등 테스트 통과', 16, 'circuitAssembly')],
  'telemetry-circuit': [step('telemetry-circuit', 'electronics', '텔레메트리 회로 제작', '센서 모듈과 회로 기판, 전선을 만들어 연결한다.', ['회로 기판', '센서 모듈 x2', '전원 전선', '신호 전선 x2'], ['납땜 인두', '회로 테스터'], '텔레메트리 시스템 작동', '센서 신호 수신 확인', 20, 'circuitAssembly')],
  'driver-assist-circuit': [step('driver-assist-circuit', 'electronics', '운전자 보조 회로 제작', '센서 모듈과 제어 유닛, 회로 기판, 전선을 만들어 연결한다.', ['회로 기판', '센서 모듈 x3', '제어 유닛', '전원 전선', '신호 전선 x2'], ['납땜 인두', '회로 테스터'], '운전자 보조 시스템 작동', '센서-제어 유닛 연결 확인', 20, 'circuitAssembly')],
  'safety-install': [step('safety-install', 'interior', '안전장치 장착', '에어백 원단을 재단·박음질해 접어 포장하고, 안전벨트 웨빙을 재단·박음질해 장착한다.', ['에어백 모듈 x2', '안전벨트 x2'], ['조립 공구'], '안전장치 정상 장착', '모든 안전장치 체결 완료', 12, 'componentAssembly')],
};

/**
 * Builds the full, ordered manufacturing plan for a car + selected options.
 * Base steps are always included; raw-steel/body/frame always come first,
 * final-assembly/inspection always come last. Option steps are inserted
 * in between, grouped by category for a sane build order.
 */
export function buildProcessPlan(_car: CarModel, selectedOptionIds: string[]): ProcessStepDef[] {
  const options = getOptionsByIds(selectedOptionIds);
  const optionSteps: ProcessStepDef[] = [];
  const seen = new Set<string>();

  for (const opt of options) {
    for (const stepId of opt.addsProcessSteps) {
      if (seen.has(stepId)) continue;
      const templates = OPTION_STEP_TEMPLATES[stepId];
      if (!templates) continue;
      for (const t of templates) {
        if (seen.has(t.id)) continue;
        seen.add(t.id);
        optionSteps.push(t);
      }
      seen.add(stepId);
    }
  }

  const leading = BASE_STEPS.slice(0, 4); // raw-steel, body-panels, body-frame, fasteners-body
  const interiorBase = BASE_STEPS[4]; // interior-base
  const trailing = BASE_STEPS.slice(5); // final-assembly, final-inspection

  const ordered = [...leading, ...optionSteps, interiorBase, ...trailing];
  return ordered.map((s, idx) => ({ ...s, order: idx + 1 }));
}
