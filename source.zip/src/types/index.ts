// ─────────────────────────────────────────────────────────────────────────
// MAKE EVERYTHING — core domain types
// ─────────────────────────────────────────────────────────────────────────

export type AppScreen =
  | 'intro'
  | 'menu'
  | 'tutorial'
  | 'carSelect'
  | 'modelSelect'
  | 'optionSelect'
  | 'workshop'
  | 'completion'
  | 'drive';

export type BodyType = 'hypercar' | 'sportscar' | 'luxury' | 'sedan' | 'suv';

export interface CarModel {
  id: string;
  name: string;
  manufacturer: string;
  bodyType: BodyType;
  difficulty: 1 | 2 | 3 | 4 | 5;
  estimatedHours: 1 | 2 | 3 | 4 | 5;
  description: string;
  // Rough body silhouette parameters used to generate a non-licensed,
  // procedurally-built 3D body mesh distinctive per model.
  silhouette: {
    length: number; // meters
    width: number;
    height: number;
    hoodRatio: number; // 0..1, portion of length used for hood/nose
    roofHeightRatio: number; // 0..1, cabin roof height relative to body height
    rearSlope: number; // 0..1, how steeply the rear tapers
    wheelbaseRatio: number; // 0..1
  };
  accentColor: string;
  availableOptionIds: string[];
}

export type OptionCategory =
  | 'engine'
  | 'transmission'
  | 'brakes'
  | 'wheels'
  | 'tires'
  | 'suspension'
  | 'navigation'
  | 'dashboard'
  | 'audio'
  | 'seats'
  | 'steeringWheel'
  | 'exteriorColor'
  | 'lighting'
  | 'electronics'
  | 'safety';

export interface CarOption {
  id: string;
  category: OptionCategory;
  name: string;
  description: string;
  difficulty: 1 | 2 | 3 | 4 | 5;
  extraMinutes: number;
  /** Process step template ids this option injects into the build plan. */
  addsProcessSteps: string[];
}

// ── Manufacturing process ───────────────────────────────────────────────

export type ProcessCategory =
  | 'rawMaterial'
  | 'bodyPanel'
  | 'frame'
  | 'engine'
  | 'electronics'
  | 'fasteners'
  | 'interior'
  | 'finalAssembly';

export interface ProcessStepDef {
  id: string;
  order: number;
  category: ProcessCategory;
  title: string;
  taskDescription: string;
  materials: string[];
  tools: string[];
  goal: string;
  completionCondition: string;
  estimatedMinutes: number;
  /** interactive "mini-process" this step launches in the 3D workshop */
  interaction: InteractionKind;
}

export type InteractionKind =
  | 'sheetMetalForming'
  | 'componentAssembly'
  | 'circuitAssembly'
  | 'fastenerInstallation'
  | 'finalAssemblyPlacement'
  | 'inspection';

export type StepStatus = 'locked' | 'available' | 'inProgress' | 'completed';

export interface StepRuntimeState {
  stepId: string;
  status: StepStatus;
  progress: number; // 0..100
  qualityScore: number; // 0..100, null until first measured
  errors: string[];
  completedAt?: number;
  /** free-form data for the specific interaction (cut lengths, bend angles, etc) */
  data: Record<string, unknown>;
}

// ── Parts: every physical thing the player places is its own object ────

export interface PartInstance {
  id: string;
  defId: string; // references a PartDef
  label: string;
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
  qualityScore: number;
  assembled: boolean;
  connected: boolean;
  fastenerCount: number;
  fastenersInstalled: number;
  errors: string[];
  powered?: boolean;
  functional?: boolean;
}

export interface BuildSnapshot {
  stepId: string;
  takenAt: number;
  partIds: string[];
  qualityScore: number;
  note: string;
}

export interface CarBuild {
  carModelId: string;
  selectedOptionIds: string[];
  steps: ProcessStepDef[];
  stepStates: Record<string, StepRuntimeState>;
  parts: Record<string, PartInstance>;
  snapshots: BuildSnapshot[];
  startedAt: number;
  completedAt?: number;
  currentStepIndex: number;
}

export interface QualityReport {
  overall: number;
  body: number;
  engine: number;
  electronics: number;
  assembly: number;
  fuelEfficiency: number; // km/L, in-game abstraction
  functioningFeatures: string[];
  brokenFeatures: string[];
  errorLog: string[];
  totalMinutes: number;
}
