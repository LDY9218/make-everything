import { useMemo, useState } from 'react';
import { useGameStore } from '../store/useGameStore';
import type { ProcessStepDef } from '../types';
import { EMPTY_PROGRESS, expandUnits, getRecipe, unitDisplayName } from './recipes';
import {
  doneTaskCount, finishAssemblyStep, isUnitDone, jumpToUnit, nextTaskOf, startNextTask,
  stepPercent, totalTaskCount, tryPlace, unitQuality, unitTaskRows, type UnitsMap,
} from './assemblyLogic';

// ─────────────────────────────────────────────────────────────────────────
// AssemblyStation — the ONE station every manufacturing step uses.
// A step's materials expand into individual units ("피스톤 x16" → 16
// pistons); each unit is walked through its recipe one hand-done task at a
// time (carve mold → melt → pour → quench → polish → drill → file → place →
// tighten ...). Every button below only decides WHICH task you do next; the
// work itself happens by dragging in the 3D view.
// ─────────────────────────────────────────────────────────────────────────

function AssemblyStation({ step }: { step: ProcessStepDef }) {
  const build = useGameStore((s) => s.build!);
  const craftTarget = useGameStore((s) => s.craftTarget);
  const fade = useGameStore((s) => s.fade);
  const [showDone, setShowDone] = useState(false);

  const units = useMemo(() => expandUnits(step.materials, step.title), [step.materials, step.title]);
  const data = build.stepStates[step.id]?.data;
  const progMap = ((data?.['units'] as UnitsMap | undefined) ?? {});

  const rows = units.map((u) => {
    const recipe = getRecipe(u.label);
    const prog = progMap[u.key] ?? EMPTY_PROGRESS;
    const next = nextTaskOf(recipe, prog);
    return { u, recipe, prog, next, done: isUnitDone(recipe, prog), nDone: doneTaskCount(recipe, prog), nTotal: totalTaskCount(recipe) };
  });

  const doneUnits = rows.filter((r) => r.done).length;
  const tasksDone = rows.reduce((n, r) => n + r.nDone, 0);
  const tasksTotal = rows.reduce((n, r) => n + r.nTotal, 0);
  const finishedQ = rows.filter((r) => r.done).map((r) => unitQuality(r.prog));
  const avgQ = finishedQ.length ? Math.round(finishedQ.reduce((a, b) => a + b, 0) / finishedQ.length) : 0;
  const percent = stepPercent(step, progMap);
  // strictly sequential: only the first unfinished piece may be worked on
  const nextRow = rows.find((r) => !r.done);
  const busy = !!craftTarget || fade;
  const taskRows = nextRow ? unitTaskRows(nextRow.recipe, nextRow.prog) : [];

  const act = (r: (typeof rows)[number]) => {
    if (busy || r !== nextRow) return;
    if (r.next.kind === 'place') {
      tryPlace(step, r.u);
      return;
    }
    startNextTask(step, r.u);
  };

  const visible = rows.filter((r) => r !== nextRow && (showDone || !r.done));

  return (
    <div className="station">
      <div className="asm-summary">
        <span><b>{doneUnits}</b>/{rows.length}개 완성</span>
        <span>단계 <b>{tasksDone}</b>/{tasksTotal}</span>
        <span>평균 품질 <b>{avgQ}</b></span>
      </div>
      <div className="progress-track" style={{ margin: '6px 0 10px' }}>
        <div className="progress-fill" style={{ width: `${percent}%` }} />
      </div>

      {nextRow && (
        <div className="asm-current">
          <div className="asm-current-head">
            <div>
              <div className="asm-next-label">지금 만드는 것 ({nextRow.u.ordinal + 1}/{rows.length})</div>
              <div className="asm-next-title">{unitDisplayName(nextRow.u)}</div>
            </div>
            <button className="btn accent" disabled={busy} onClick={() => act(nextRow)}>
              {busy ? '이동 중…' : nextRow.next.kind === 'place' ? '정렬 확인' : '▶ 다음 단계 시작'}
            </button>
          </div>
          <ol className="asm-steps">
            {taskRows.map((t, i) => (
              <li key={i} className={`${t.done ? 'done' : ''} ${t.current ? 'current' : ''}`}>
                <span className="asm-step-mark">{t.done ? '✓' : t.current ? '▶' : i + 1}</span>
                <span className="asm-step-title">{t.title}</span>
                <span className="asm-step-where">{t.where}</span>
              </li>
            ))}
          </ol>
          {nextRow.prog.fabDone >= nextRow.recipe.fab.length && nextRow.recipe.makesPart && !nextRow.prog.placed && (
            <button className="btn ghost sm" onClick={() => jumpToUnit(step, nextRow.u)}>부품 위치 보기</button>
          )}
        </div>
      )}

      <div className="part-list asm-list">
        {visible.map((r) => (
          <div key={r.u.key} className={`part-row asm-row ${r.done ? 'done' : ''}`}>
            <div className="asm-row-main">
              <span className={`part-row-label ${r.done ? 'ok' : ''}`}>{unitDisplayName(r.u)}</span>
              <span className="asm-row-sub">{r.done ? `완성 · 품질 ${unitQuality(r.prog)}` : '앞의 것을 먼저 완성해야 합니다'}</span>
            </div>
            <div className="asm-row-right"><span className="asm-count">{r.nDone}/{r.nTotal}</span></div>
          </div>
        ))}
        {visible.length === 0 && !nextRow && <p className="station-desc">모든 항목을 완성했습니다. 아래에서 단계를 마무리하세요.</p>}
      </div>
      {doneUnits > 0 && (
        <button className="hud-collapse-btn" style={{ marginTop: 8 }} onClick={() => setShowDone((v) => !v)}>
          {showDone ? '완성한 항목 숨기기' : `완성한 항목 ${doneUnits}개 보기`}
        </button>
      )}

      <div className="station-footer">
        <span className="quality-preview">
          {doneUnits === rows.length ? '모든 공정 완료' : `${rows.length - doneUnits}개 남음`}
        </span>
        {doneUnits === rows.length && (
          <button className="btn accent" disabled={busy} onClick={() => finishAssemblyStep(step)}>
            단계 완료
          </button>
        )}
      </div>
    </div>
  );
}

// ── Station 6: Inspection ────────────────────────────────────────────────
function InspectionStation({ step }: { step: ProcessStepDef }) {
  const build = useGameStore((s) => s.build!);
  const completeStep = useGameStore((s) => s.completeStep);
  const finalizeCar = useGameStore((s) => s.finalizeCar);

  const otherSteps = build.steps.filter((s) => s.id !== step.id);
  const completed = otherSteps.filter((s) => build.stepStates[s.id]?.status === 'completed');
  const avgQuality = Math.round(
    completed.reduce((sum, s) => sum + (build.stepStates[s.id]?.qualityScore ?? 0), 0) / Math.max(1, completed.length),
  );
  const errorCount = completed.reduce((n, s) => n + (build.stepStates[s.id]?.errors.length ?? 0), 0);

  const finish = () => {
    completeStep(step.id, avgQuality, []);
    finalizeCar();
  };

  return (
    <div className="station">
      <p className="station-desc">
        {completed.length}/{otherSteps.length}개 공정 완료 · 종합 품질 {avgQuality}점
        {errorCount > 0 && ` · 누적 오류 ${errorCount}건`}
      </p>
      <div className="station-footer">
        <span className="quality-preview">검사는 간단히 — 바로 출고 처리합니다</span>
        <button className="btn accent" onClick={finish}>검사 완료 및 차량 출고</button>
      </div>
    </div>
  );
}

export default function StepInteractionPanel({ step }: { step: ProcessStepDef }) {
  if (step.interaction === 'inspection') return <InspectionStation step={step} />;
  return <AssemblyStation step={step} />;
}
