import { useGameStore } from '../store/useGameStore';
import type { PartInstance, ProcessStepDef } from '../types';
import {
  EMPTY_PROGRESS, expandUnits, getRecipe, restSpot, unitDisplayName, unitPartId,
  type Recipe, type TaskDef, type UnitDef, type UnitProgress,
} from './recipes';
import { BENCH_ORIGIN, getAssemblyTarget } from './targets';

// ─────────────────────────────────────────────────────────────────────────
// Everything the AssemblyStation does to the store lives here, so the DOM
// panel and the 3D scene (drag & drop) share exactly one implementation.
//
// Per step, build.stepStates[stepId].data holds:
//   units  : { [unitKey]: UnitProgress }   — how far each single piece is
//   molds  : { [label]:   {quality,errors} } — carved molds, reused per label
//   powered: boolean                        — set when the step is finished
// ─────────────────────────────────────────────────────────────────────────

export type UnitsMap = Record<string, UnitProgress>;
export interface MoldInfo { quality: number; errors: string[] }
export type NextTask =
  | { kind: 'fab'; idx: number; task: TaskDef }
  | { kind: 'place' }
  | { kind: 'fasten'; idx: number; task: TaskDef }
  | { kind: 'done' };

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export function readUnits(stepId: string): UnitsMap {
  const st = useGameStore.getState().build?.stepStates[stepId];
  return ((st?.data?.['units'] as UnitsMap | undefined) ?? {});
}

export function readMolds(stepId: string): Record<string, MoldInfo> {
  const st = useGameStore.getState().build?.stepStates[stepId];
  return ((st?.data?.['molds'] as Record<string, MoldInfo> | undefined) ?? {});
}

export function nextTaskOf(recipe: Recipe, prog: UnitProgress): NextTask {
  if (prog.fabDone < recipe.fab.length) return { kind: 'fab', idx: prog.fabDone, task: recipe.fab[prog.fabDone] };
  if (!recipe.makesPart) return { kind: 'done' };
  if (!prog.placed) return { kind: 'place' };
  if (prog.fastenDone < recipe.fasten.length) return { kind: 'fasten', idx: prog.fastenDone, task: recipe.fasten[prog.fastenDone] };
  return { kind: 'done' };
}

export function isUnitDone(recipe: Recipe, prog: UnitProgress): boolean {
  return nextTaskOf(recipe, prog).kind === 'done';
}

export function doneTaskCount(recipe: Recipe, prog: UnitProgress): number {
  return prog.fabDone + (recipe.makesPart && prog.placed ? 1 : 0) + prog.fastenDone;
}

export function totalTaskCount(recipe: Recipe): number {
  return recipe.fab.length + (recipe.makesPart ? 1 + recipe.fasten.length : 0);
}

export function unitQuality(prog: UnitProgress): number {
  return prog.qCount > 0 ? Math.round(prog.qSum / prog.qCount) : 0;
}

/** progress percent of the whole step, counting every single task */
export function stepPercent(step: ProcessStepDef, units: UnitsMap): number {
  let done = 0;
  let total = 0;
  for (const u of expandUnits(step.materials, step.title)) {
    const r = getRecipe(u.label);
    done += doneTaskCount(r, units[u.key] ?? EMPTY_PROGRESS);
    total += totalTaskCount(r);
  }
  return total === 0 ? 0 : Math.round((done / total) * 100);
}

// ── sessions: walk to another room, work, walk back ──────────────────────

const FADE_MS = 430;

/** fade to black → run `swap` (nothing is visible) → fade back in */
function throughBlack(swap: () => void) {
  const st = useGameStore.getState();
  st.setFade(true);
  window.setTimeout(() => {
    swap();
    window.setTimeout(() => useGameStore.getState().setFade(false), 260);
  }, FADE_MS);
}

/** leaves the current hand-work session (camera goes back to the garage) */
export function endSession(after?: () => void) {
  throughBlack(() => {
    const s = useGameStore.getState();
    s.setHud(null);
    s.setCraftTarget(null);
    after?.();
  });
}

/** player pressed 작업 취소 — nothing is recorded, the unit stays at the same task */
export function cancelTask() {
  const st = useGameStore.getState();
  if (!st.craftTarget || st.fade) return;
  endSession();
}

/** Opens the 3D hand-work session for a unit's next fab / fasten task. */
export function startNextTask(step: ProcessStepDef, unit: UnitDef): void {
  const st = useGameStore.getState();
  if (!st.build || st.craftTarget || st.fade) return;
  const recipe = getRecipe(unit.label);
  const prog = readUnits(step.id)[unit.key] ?? EMPTY_PROGRESS;
  const nt = nextTaskOf(recipe, prog);
  if (nt.kind !== 'fab' && nt.kind !== 'fasten') return;

  const task = nt.task;
  const isCast = task.spec.kind === 'cast';
  const mold = isCast ? readMolds(step.id)[unit.key] ?? null : null;
  const target = getAssemblyTarget(unit.ordinal, unit.total, step.order);
  const atTarget = task.spec.kind === 'path' && !!task.spec.atTarget;
  const origin: [number, number, number] = atTarget ? target : BENCH_ORIGIN;
  const kind = nt.kind;
  const idx = nt.idx;
  const globalNo = doneTaskCount(recipe, prog) + 1;

  const craft = {
    id: `${unitPartId(step.id, unit)}-${kind}${idx}-${Date.now()}`,
    label: `${unitDisplayName(unit)} — ${task.title} (${globalNo}/${totalTaskCount(recipe)})`,
    spec: task.spec,
    origin,
    mold,
    unitKey: `${step.id}:${unit.key}`,
    shape: task.spec.kind === 'cast' ? task.spec.shape : undefined,
    onDone: (quality: number, errors: string[], extra?: { carveQuality?: number }) => finishTask(step, unit, kind, quality, errors, extra),
  };
  throughBlack(() => useGameStore.getState().setCraftTarget(craft));
}

function finishTask(
  step: ProcessStepDef, unit: UnitDef, kind: 'fab' | 'fasten',
  quality: number, errors: string[], extra?: { carveQuality?: number },
): void {
  const st = useGameStore.getState();
  if (!st.build) return;

  const recipe = getRecipe(unit.label);
  const units: UnitsMap = { ...readUnits(step.id) };
  const prev = units[unit.key] ?? EMPTY_PROGRESS;
  const next: UnitProgress = {
    ...prev,
    fabDone: kind === 'fab' ? prev.fabDone + 1 : prev.fabDone,
    fastenDone: kind === 'fasten' ? prev.fastenDone + 1 : prev.fastenDone,
    qSum: prev.qSum + quality,
    qCount: prev.qCount + 1,
    errs: [...prev.errs, ...errors],
  };
  units[unit.key] = next;

  let molds = readMolds(step.id);
  if (extra?.carveQuality != null) {
    molds = {
      ...molds,
      [unit.key]: {
        quality: extra.carveQuality,
        errors: extra.carveQuality < 95 ? [`${unit.label} 주조 틀 조각 오차 (품질 ${extra.carveQuality})`] : [],
      },
    };
  }

  // the physical part only exists once its last making-task is done
  if (recipe.makesPart && next.fabDone >= recipe.fab.length) syncPart(step, unit, recipe, next);
  st.updateStepProgress(step.id, stepPercent(step, units), { units, molds });

  const fin = isUnitDone(recipe, next);
  const msg = fin
    ? `${unitDisplayName(unit)} 완성! (품질 ${unitQuality(next)}점)`
    : `${unitDisplayName(unit)}: 단계 완료 · 품질 ${quality}점 (${doneTaskCount(recipe, next)}/${totalTaskCount(recipe)})`;
  endSession(() => useGameStore.getState().showToast(msg, quality >= 60 ? 'ok' : 'bad'));
}

// ── per-unit task list shown in the right panel ──────────────────────────

export interface TaskRow { title: string; kind: 'fab' | 'place' | 'fasten'; done: boolean; current: boolean; where: string }

export function unitTaskRows(recipe: Recipe, prog: UnitProgress): TaskRow[] {
  const rows: TaskRow[] = [];
  const cur = nextTaskOf(recipe, prog);
  recipe.fab.forEach((t, i) => rows.push({
    title: t.title, kind: 'fab', done: i < prog.fabDone, current: cur.kind === 'fab' && cur.idx === i,
    where: t.spec.kind === 'cast' ? '주조실' : t.spec.atTarget ? '차량 위' : '작업실',
  }));
  if (recipe.makesPart) {
    rows.push({ title: '차체의 파란 링 위로 옮겨 장착', kind: 'place', done: prog.placed, current: cur.kind === 'place', where: '차고' });
    recipe.fasten.forEach((t, i) => rows.push({
      title: t.title, kind: 'fasten', done: i < prog.fastenDone, current: cur.kind === 'fasten' && cur.idx === i, where: '차량 위',
    }));
  }
  return rows;
}

export function stepTaskCounts(step: ProcessStepDef, units: UnitsMap): { done: number; total: number } {
  let done = 0;
  let total = 0;
  for (const u of expandUnits(step.materials, step.title)) {
    const r = getRecipe(u.label);
    done += doneTaskCount(r, units[u.key] ?? EMPTY_PROGRESS);
    total += totalTaskCount(r);
  }
  return { done, total };
}

/** every hand-made task of the whole car, counted as one step each */
export function buildTaskTotals(build: NonNullable<ReturnType<typeof useGameStore.getState>['build']>): { done: number; total: number } {
  let done = 0;
  let total = 0;
  for (const step of build.steps) {
    if (step.interaction === 'inspection') continue;
    const units = ((build.stepStates[step.id]?.data?.['units'] as UnitsMap | undefined) ?? {});
    const c = stepTaskCounts(step, units);
    done += c.done;
    total += c.total;
  }
  return { done, total };
}

/** creates the physical part after its last making-task, and keeps it in sync afterwards */
function syncPart(step: ProcessStepDef, unit: UnitDef, recipe: Recipe, prog: UnitProgress): void {
  const st = useGameStore.getState();
  if (!st.build) return;
  const pid = unitPartId(step.id, unit);
  const existing = st.build.parts[pid];
  const connected = prog.placed && prog.fastenDone >= recipe.fasten.length;
  const part: PartInstance = {
    id: pid,
    defId: `${step.id}-${unit.label}`,
    label: unitDisplayName(unit),
    position: existing?.position ?? restSpot(unit.ordinal),
    rotation: existing?.rotation ?? [0, 0, 0],
    scale: existing?.scale ?? [1, 1, 1],
    qualityScore: unitQuality(prog),
    assembled: prog.placed,
    connected,
    fastenerCount: recipe.fasten.length,
    fastenersInstalled: prog.fastenDone,
    errors: prog.errs,
  };
  st.upsertPart(part);
}

/** Checks the part's real position against its target ring; on success it snaps there. */
export function tryPlace(step: ProcessStepDef, unit: UnitDef): { ok: boolean; msg: string } {
  const st = useGameStore.getState();
  if (!st.build) return { ok: false, msg: '' };
  const recipe = getRecipe(unit.label);
  const units: UnitsMap = { ...readUnits(step.id) };
  const prog = units[unit.key] ?? EMPTY_PROGRESS;
  const part = st.build.parts[unitPartId(step.id, unit)];
  if (!recipe.makesPart || !part) {
    const hint = partMakeHint(unit.label);
    const msg = hint ? `부품 없음 — ${hint}에서 먼저 만드세요` : '아직 부품이 없습니다';
    st.showToast(msg, 'bad');
    return { ok: false, msg };
  }
  if (prog.fabDone < recipe.fab.length) {
    const left = recipe.fab.length - prog.fabDone;
    const msg = `제작 공정 ${left}개 남음 — 먼저 완성하세요`;
    st.showToast(msg, 'bad');
    return { ok: false, msg };
  }
  if (prog.placed) return { ok: true, msg: '이미 장착되었습니다' };

  const target = getAssemblyTarget(unit.ordinal, unit.total, step.order);
  const dist = Math.hypot(part.position[0] - target[0], part.position[2] - target[2]);
  if (dist > 0.95) {
    const msg = `정위치에서 ${dist.toFixed(1)}m 떨어져 있어요 — 파란 링 위에 더 가까이 놓으세요`;
    st.showToast(msg, 'bad');
    return { ok: false, msg };
  }
  const q = Math.round(clamp(100 - dist * 14, 40, 100));
  const next: UnitProgress = {
    ...prog,
    placed: true,
    qSum: prog.qSum + q,
    qCount: prog.qCount + 1,
    errs: dist > 0.5 ? [...prog.errs, `${unitDisplayName(unit)}: 장착 위치가 어긋남 (${dist.toFixed(2)}m)`] : prog.errs,
  };
  units[unit.key] = next;
  st.upsertPart({
    ...part,
    position: target,
    rotation: [0, 0, 0],
    assembled: true,
    connected: recipe.fasten.length === 0,
    qualityScore: unitQuality(next),
    errors: next.errs,
  });
  st.updateStepProgress(step.id, stepPercent(step, units), { units });
  const msg = `${unitDisplayName(unit)} 장착 완료 (정렬 ${q}점)`;
  st.showToast(msg, 'ok');
  return { ok: true, msg };
}

/** Called by the 3D scene when a part is released after a drag. */
export function tryPlaceByPartId(partId: string): void {
  const st = useGameStore.getState();
  const step = st.build?.steps.find((s) => s.id === st.activeStepId);
  if (!step) return;
  const prefix = `${step.id}-u-`;
  if (!partId.startsWith(prefix)) return;
  const key = partId.slice(prefix.length);
  const unit = expandUnits(step.materials, step.title).find((u) => u.key === key);
  if (!unit) return;
  tryPlace(step, unit);
}

/** Finishes the step: unfinished pieces count as zero quality and are logged. */
export function finishAssemblyStep(step: ProcessStepDef): void {
  const st = useGameStore.getState();
  if (!st.build) return;
  const units = readUnits(step.id);
  const all = expandUnits(step.materials, step.title);

  let qualitySum = 0;
  const errors: string[] = [];
  let powerUnits = 0;
  let powerDone = 0;
  for (const u of all) {
    const r = getRecipe(u.label);
    const p = units[u.key] ?? EMPTY_PROGRESS;
    const done = isUnitDone(r, p);
    if (u.label.includes('전원')) { powerUnits++; if (done) powerDone++; }
    if (done) qualitySum += unitQuality(p);
    else errors.push(`${unitDisplayName(u)}: 공정 미완료 (${doneTaskCount(r, p)}/${totalTaskCount(r)})`);
    for (const e of p.errs) errors.push(`${unitDisplayName(u)} — ${e}`);
  }
  let quality = all.length === 0 ? 0 : qualitySum / all.length;

  if (step.interaction === 'finalAssemblyPlacement') {
    const loose = Object.values(st.build.parts).filter((p) => !p.assembled);
    if (loose.length > 0) {
      quality -= Math.min(40, loose.length * 4);
      errors.push(`장착하지 않은 부품 ${loose.length}개가 차에 결합되지 않음`);
    }
  }

  if (powerUnits > 0) st.updateStepProgress(step.id, 100, { powered: powerDone === powerUnits });
  if (powerUnits > 0 && powerDone < powerUnits) errors.push('전원 전선 미완성 — 이 장치는 켜지지 않습니다');

  const trimmed = errors.length > 40 ? [...errors.slice(0, 40), `…외 ${errors.length - 40}건`] : errors;
  st.completeStep(step.id, Math.round(clamp(quality, 0, 100)), trimmed);
  const steps = useGameStore.getState().build?.steps ?? [];
  const nextStep = steps[steps.findIndex((s) => s.id === step.id) + 1];
  useGameStore.getState().setCraftTarget(null);
  useGameStore.getState().showToast(`${step.title} 완료 — 품질 ${Math.round(clamp(quality, 0, 100))}점`, quality >= 60 ? 'ok' : 'bad');
  if (nextStep) useGameStore.getState().setActiveStep(nextStep.id);
}

export function jumpToUnit(step: ProcessStepDef, unit: UnitDef): void {
  const st = useGameStore.getState();
  const t = getAssemblyTarget(unit.ordinal, unit.total, step.order);
  st.requestFocus([t[0], t[1], t[2]], 6);
}

/** "N번째 작업의 M번째 항목" — tells the player where a missing part would be made. */
export function partMakeHint(label: string): string | null {
  const st = useGameStore.getState();
  const build = st.build;
  if (!build) return null;
  for (const step of build.steps) {
    if (step.interaction === 'inspection') continue;
    const units = expandUnits(step.materials, step.title);
    const hit = units.find((u) => u.label === label);
    if (hit && getRecipe(hit.label).makesPart) {
      return `${step.order}번째 작업 (${step.title})의 ${hit.ordinal + 1}번째 항목`;
    }
  }
  return null;
}
