import { resolveShape, type ShapeKey } from '../scenes/partShapes';

// ─────────────────────────────────────────────────────────────────────────
// Recipes: every material in a process step expands into INDIVIDUAL units
// ("피스톤 x16" → 16 pistons), and every unit expands into a chain of
// hand-done tasks (carve the mold, melt & pour, bore, groove, polish,
// weld, solder, stitch, tighten...). Nothing is ever produced by a single
// click — the station just walks the player through these tasks one by one.
// ─────────────────────────────────────────────────────────────────────────

export type ToolKind =
  | 'cutter' | 'needle' | 'torch' | 'solder' | 'wrench' | 'screwdriver'
  | 'file' | 'drill' | 'press' | 'brush' | 'crimper' | 'stripper' | 'heatgun';

export type WorkKind =
  | 'plate' | 'cloth' | 'wire' | 'board' | 'rod' | 'bolt' | 'cylinder' | 'surface' | 'gear' | 'tube';

export type PathShape = 'line' | 'circle' | 'outline' | 'zigzag';

export type CastStage = 'carve' | 'melt' | 'pour' | 'cool' | 'finish';

export interface CastSpec {
  kind: 'cast';
  /** which of the five foundry jobs this task is (each one is its own step) */
  stage: CastStage;
  /** cavity outline key (piston, wheel, panel ...) */
  shape: string;
  ingots: number;
  carveHits?: number;
}

export interface PathSpec {
  kind: 'path';
  tool: ToolKind;
  work: WorkKind;
  shape: PathShape;
  /** number of separate drag-strokes (each one is its own stitch / pass / turn) */
  steps: number;
  color: string;
  hint: string;
  /** when true the work is rendered at the car (target position) instead of on the bench */
  atTarget?: boolean;
  /** side-view depth passes (drill / press / crimp): 0 = nothing to do from the side, so that view is skipped */
  depth?: number;
}

export type TaskSpec = CastSpec | PathSpec;

export interface TaskDef {
  id: string;
  title: string;
  spec: TaskSpec;
}

export interface Recipe {
  /** false → pure process unit (painting, tightening a chassis bolt): no physical part is produced */
  makesPart: boolean;
  fab: TaskDef[];
  fasten: TaskDef[];
}

export interface UnitDef {
  /** stable key inside a step, e.g. "2-5" = material #2, unit #5 */
  key: string;
  matIdx: number;
  index: number; // 1-based within the material
  count: number; // how many units that material has
  ordinal: number; // 0-based over the entire step
  total: number; // units in the step
  label: string; // plain product name, without "x16"
}

export interface UnitProgress {
  fabDone: number;
  placed: boolean;
  fastenDone: number;
  qSum: number;
  qCount: number;
  errs: string[];
}

export const EMPTY_PROGRESS: UnitProgress = { fabDone: 0, placed: false, fastenDone: 0, qSum: 0, qCount: 0, errs: [] };

export function parseMaterial(raw: string): { base: string; count: number } {
  const m = raw.match(/^(.*?)\s*x\s*(\d+)$/i);
  if (m) return { base: m[1].trim(), count: Math.max(1, Number(m[2])) };
  return { base: raw.trim(), count: 1 };
}

export function expandUnits(materials: string[], fallbackTitle: string): UnitDef[] {
  const mats = materials.length > 0 ? materials : [fallbackTitle];
  const parsed = mats.map(parseMaterial);
  const total = parsed.reduce((n, p) => n + p.count, 0);
  const units: UnitDef[] = [];
  let ordinal = 0;
  parsed.forEach((p, matIdx) => {
    for (let i = 1; i <= p.count; i++) {
      units.push({ key: `${matIdx}-${i}`, matIdx, index: i, count: p.count, ordinal, total, label: p.base });
      ordinal++;
    }
  });
  return units;
}

export function unitPartId(stepId: string, unit: UnitDef): string {
  return `${stepId}-u-${unit.key}`;
}

export function unitDisplayName(unit: UnitDef): string {
  return unit.count > 1 ? `${unit.label} #${unit.index}` : unit.label;
}

// ── task builders ────────────────────────────────────────────────────────

/** placeholder — expanded into the five foundry tasks by expandCast() once the shape key is known */
const cast = (title: string, carveHits = 4, ingots = 3): TaskDef => ({ id: 'cast', title, spec: { kind: 'cast', stage: 'carve', shape: '', carveHits, ingots } });

const CAST_TITLES: Record<CastStage, string> = {
  carve: '모래 틀 조각 — 긁어서 공동 파내기',
  melt: '재료 용해 — 도가니 넣고 풀무질',
  pour: '쇳물 주입 — 주입구에 정확히 붓기',
  cool: '송풍 냉각 · 모래 털어내기',
  finish: '담금질 · 표면 연마',
};

function expandCast(r: Recipe, shape: string): Recipe {
  const fab: TaskDef[] = [];
  for (const t of r.fab) {
    if (t.spec.kind !== 'cast') { fab.push(t); continue; }
    const ingots = t.spec.ingots;
    (['carve', 'melt', 'pour', 'cool', 'finish'] as CastStage[]).forEach((stage) => {
      fab.push({ id: `cast-${stage}`, title: CAST_TITLES[stage], spec: { kind: 'cast', stage, shape, ingots } });
    });
  }
  return { ...r, fab };
}

const depthFor = (tool: ToolKind): number => (tool === 'drill' ? 2 : tool === 'press' ? 2 : tool === 'crimper' ? 2 : 0);

const path = (
  id: string, title: string, tool: ToolKind, work: WorkKind, shape: PathShape, steps: number,
  hint: string, color = '#c7c9cc', atTarget = false,
): TaskDef => ({ id, title, spec: { kind: 'path', tool, work, shape, steps, hint, color, atTarget, depth: atTarget ? 0 : depthFor(tool) } });

const tighten = (title: string, steps = 6): TaskDef =>
  path('fasten', title, 'wrench', 'bolt', 'circle', steps, '렌치를 원을 그리며 한 칸씩 돌려 조이세요', '#d0d0d4', true);

const weld = (title: string, steps = 6): TaskDef =>
  path('weld', title, 'torch', 'plate', 'line', steps, '토치를 이음선을 따라 한 구간씩 이동시키며 용접하세요', '#ff8a2a', true);

// ── recipe table ─────────────────────────────────────────────────────────

function recipeForShape(key: ShapeKey, label: string): Recipe {
  switch (key) {
    case 'slab':
      return {
        makesPart: true,
        fab: [cast('철 슬래브 주조', 4, 3), path('roll', '압연 — 롤러를 끌어 두께 맞추기', 'press', 'plate', 'line', 5, '압연 롤러를 끝까지 한 구간씩 밀어 두께를 맞추세요', '#9a9aa0')],
        fasten: [],
      };
    case 'panel':
      return {
        makesPart: true,
        fab: [
          cast(`${label} 소재 주조`, 5, 3),
          path('press', '프레스 성형', 'press', 'plate', 'outline', 8, '프레스를 외곽선을 따라 눌러 곡면을 만드세요', '#b8bcc2'),
          path('trim', '가장자리 절단', 'cutter', 'plate', 'outline', 8, '절단기를 외곽선을 따라 한 구간씩 자르세요', '#d8d8dc'),
          path('polish', '표면 연마', 'file', 'plate', 'zigzag', 6, '줄을 지그재그로 문질러 표면을 매끈하게 하세요', '#e6e8ea'),
        ],
        fasten: [weld(`${label} 용접 접합`, 6)],
      };
    case 'block':
      return {
        makesPart: true,
        fab: [
          cast('엔진 블록 주조', 6, 4),
          path('bore', '실린더 보어 가공', 'drill', 'cylinder', 'circle', 8, '드릴을 원을 따라 돌려 보어를 정밀하게 가공하세요', '#8a8a90'),
          path('hone', '실린더 내벽 호닝', 'file', 'cylinder', 'zigzag', 7, '호닝 스톤을 위아래로 문질러 내벽을 다듬으세요', '#a0a0a6'),
          path('deck', '블록 상면 평탄화', 'file', 'plate', 'zigzag', 6, '상면을 지그재그로 갈아 평탄도를 맞추세요', '#b0b0b6'),
        ],
        fasten: [tighten('엔진 마운트 볼트 조이기', 8)],
      };
    case 'piston':
      return {
        makesPart: true,
        fab: [
          cast('피스톤 주조', 4, 2),
          path('groove', '피스톤 링 홈 가공', 'file', 'cylinder', 'line', 4, '링 홈 자리를 따라 줄을 한 구간씩 밀어 가공하세요', '#b4b4ba'),
          path('pin', '핀 구멍 보링', 'drill', 'cylinder', 'circle', 6, '드릴을 원을 따라 돌려 핀 구멍을 뚫으세요', '#a0a0a6'),
          path('polish', '피스톤 표면 연마', 'file', 'cylinder', 'zigzag', 4, '표면을 문질러 연마하세요', '#d0d0d6'),
        ],
        fasten: [tighten('커넥팅 로드 볼트 조이기', 5)],
      };
    case 'shaft':
      return {
        makesPart: true,
        fab: [
          cast(`${label} 주조`, 5, 3),
          path('turn', '선반 가공', 'file', 'rod', 'line', 6, '선반 바이트를 축 방향으로 한 구간씩 밀어 깎으세요', '#9a9aa0'),
          path('grind', '저널 연마', 'file', 'rod', 'zigzag', 6, '저널을 지그재그로 연마하세요', '#c0c0c6'),
        ],
        fasten: [tighten(`${label} 베어링 캡 볼트 조이기`, 6)],
      };
    case 'turbo':
      return {
        makesPart: true,
        fab: [
          cast('터빈 하우징 주조', 5, 3),
          path('balance', '임펠러 균형 가공', 'drill', 'gear', 'circle', 8, '드릴을 원을 따라 돌려 임펠러 날개 균형을 맞추세요', '#8a8a90'),
          path('polish', '하우징 연마', 'file', 'plate', 'zigzag', 5, '하우징을 문질러 연마하세요', '#b8b8be'),
        ],
        fasten: [tighten('터보 플랜지 볼트 조이기', 6)],
      };
    case 'gearbox':
      return {
        makesPart: true,
        fab: [
          cast(`${label} 주조`, 6, 3),
          path('teeth', '기어 이빨 절삭', 'file', 'gear', 'circle', 12, '절삭 공구를 원을 따라 돌리며 이빨을 하나씩 깎으세요', '#7a7a80'),
          path('polish', '기어 면 연마', 'file', 'gear', 'zigzag', 5, '기어 면을 문질러 연마하세요', '#b0b0b6'),
        ],
        fasten: [tighten(`${label} 체결 볼트 조이기`, 6)],
      };
    case 'hydraulicUnit':
      return {
        makesPart: true,
        fab: [
          cast('유압 유닛 하우징 주조', 5, 3),
          path('bore', '유로 보링', 'drill', 'cylinder', 'circle', 6, '유로를 원을 따라 뚫으세요', '#8a8a90'),
          path('seal', '실링 조립', 'press', 'cylinder', 'line', 3, '실을 한 구간씩 눌러 끼우세요', '#222'),
        ],
        fasten: [tighten('유압 유닛 고정 볼트 조이기', 5)],
      };
    case 'circuitBoard':
      return {
        makesPart: true,
        fab: [
          path('cut', '기판 절단', 'cutter', 'board', 'outline', 6, '기판을 외곽선을 따라 한 구간씩 자르세요', '#d8d8dc'),
          path('trace', '회로 패턴 납땜 배선', 'solder', 'board', 'zigzag', 8, '인두를 패턴을 따라 한 구간씩 이동시켜 납땜하세요', '#d4d4d8'),
          path('drill', '장착 구멍 뚫기', 'drill', 'board', 'line', 4, '드릴로 장착 구멍을 한 개씩 뚫으세요', '#aaa'),
        ],
        fasten: [path('screw', '기판 고정 나사 조이기', 'screwdriver', 'bolt', 'circle', 4, '드라이버를 돌려 기판을 고정하세요', '#d0d0d4', true)],
      };
    case 'chip':
    case 'module':
      return {
        makesPart: true,
        fab: [
          path('place', `${label} 핀 납땜`, 'solder', 'board', 'circle', 8, '인두를 핀 위치를 따라 한 곳씩 옮겨 납땜하세요', '#d4d4d8'),
          path('case', `${label} 케이스 조립`, 'screwdriver', 'bolt', 'circle', 4, '케이스를 나사로 고정하세요', '#d0d0d4'),
        ],
        fasten: [path('screw', `${label} 고정 나사`, 'screwdriver', 'bolt', 'circle', 4, '드라이버를 돌려 고정하세요', '#d0d0d4', true)],
      };
    case 'screen':
      return {
        makesPart: true,
        fab: [
          path('cut', '유리 절단', 'cutter', 'plate', 'outline', 6, '유리를 외곽선을 따라 한 구간씩 자르세요', '#cfe8ff'),
          path('flex', '플렉시블 케이블 납땜', 'solder', 'board', 'line', 5, '케이블 단자를 한 곳씩 납땜하세요', '#d4d4d8'),
          path('bond', '패널 접합', 'press', 'plate', 'zigzag', 5, '접합면을 지그재그로 눌러 접합하세요', '#aab'),
        ],
        fasten: [path('screw', '화면 고정 나사', 'screwdriver', 'bolt', 'circle', 4, '드라이버를 돌려 고정하세요', '#d0d0d4', true)],
      };
    case 'wire':
      return {
        makesPart: true,
        fab: [
          path('cut', '전선 길이 재고 절단', 'cutter', 'wire', 'line', 4, '눈금을 따라 절단기를 이동시켜 자르세요', '#c0392b'),
          path('stripA', '피복 벗기기 (한쪽 끝)', 'stripper', 'wire', 'line', 2, '스트리퍼로 피복을 한 구간씩 벗기세요', '#c0392b'),
          path('stripB', '피복 벗기기 (반대쪽 끝)', 'stripper', 'wire', 'line', 2, '스트리퍼로 피복을 한 구간씩 벗기세요', '#c0392b'),
          path('crimpA', '단자 압착 (한쪽)', 'crimper', 'wire', 'line', 3, '압착기를 눌러 단자를 고정하세요', '#d4a017'),
          path('crimpB', '단자 압착 (반대쪽)', 'crimper', 'wire', 'line', 3, '압착기를 눌러 단자를 고정하세요', '#d4a017'),
          path('solderA', '납땜 (한쪽)', 'solder', 'wire', 'circle', 5, '인두를 접합부 둘레로 돌려 납땜하세요', '#d4d4d8'),
          path('solderB', '납땜 (반대쪽)', 'solder', 'wire', 'circle', 5, '인두를 접합부 둘레로 돌려 납땜하세요', '#d4d4d8'),
          path('shrink', '열수축 튜브 씌우기', 'heatgun', 'wire', 'line', 4, '열풍기를 튜브를 따라 이동시켜 수축시키세요', '#222'),
        ],
        fasten: [],
      };
    case 'tube':
      return {
        makesPart: true,
        fab: [
          path('cut', '배관 절단', 'cutter', 'tube', 'line', 3, '배관을 한 구간씩 자르세요', '#c7c9cc'),
          path('flareA', '끝단 플레어링 (한쪽)', 'press', 'tube', 'line', 2, '플레어링 공구를 눌러 끝을 넓히세요', '#c7c9cc'),
          path('flareB', '끝단 플레어링 (반대쪽)', 'press', 'tube', 'line', 2, '플레어링 공구를 눌러 끝을 넓히세요', '#c7c9cc'),
          path('bend', '곡관 가공', 'press', 'tube', 'zigzag', 5, '벤더를 한 구간씩 눌러 휘세요', '#c7c9cc'),
        ],
        fasten: [tighten('이음 너트 조이기', 5)],
      };
    case 'coil':
      return {
        makesPart: true,
        fab: [
          path('wind', '스프링 감기', 'press', 'rod', 'circle', 10, '심봉 둘레로 한 바퀴씩 감으세요', '#8a8a90'),
          path('temper', '열처리', 'heatgun', 'rod', 'line', 4, '열풍기를 스프링을 따라 이동시켜 열처리하세요', '#ff8a2a'),
          path('grind', '끝단 연마', 'file', 'rod', 'zigzag', 4, '끝단을 문질러 평평하게 만드세요', '#b8b8be'),
        ],
        fasten: [tighten('댐퍼 마운트 볼트 조이기', 5)],
      };
    case 'wheel':
      return {
        makesPart: true,
        fab: [
          cast('휠 주조', 6, 4),
          path('lathe', '림 선반 가공', 'file', 'gear', 'circle', 10, '바이트를 림 둘레로 돌려 가공하세요', '#a0a0a6'),
          path('drill', '허브 볼트 구멍 뚫기', 'drill', 'gear', 'circle', 5, '볼트 구멍 5곳을 한 곳씩 뚫으세요', '#8a8a90'),
          path('polish', '스포크 연마', 'file', 'gear', 'zigzag', 6, '스포크를 문질러 연마하세요', '#e0e0e6'),
        ],
        fasten: [tighten('휠 너트 5개 조이기', 5)],
      };
    case 'tire':
      return {
        makesPart: true,
        fab: [
          cast('타이어 고무 주입(금형)', 5, 3),
          path('vulcan', '가황 처리', 'heatgun', 'gear', 'circle', 8, '열풍기를 타이어 둘레로 돌려 가황하세요', '#ff8a2a'),
          path('trim', '트레드 다듬기', 'cutter', 'gear', 'circle', 10, '칼날을 둘레로 돌려 버를 제거하세요', '#222'),
        ],
        fasten: [path('inflate', '공기 주입', 'press', 'cylinder', 'zigzag', 6, '펌프를 위아래로 눌러 공기를 넣으세요', '#aaa', true)],
      };
    case 'disc':
      return {
        makesPart: true,
        fab: [
          cast('브레이크 디스크 주조', 5, 3),
          path('lathe', '디스크 면 선반 가공', 'file', 'gear', 'circle', 8, '바이트를 둘레로 돌려 가공하세요', '#a0a0a6'),
          path('vent', '냉각 홀 뚫기', 'drill', 'gear', 'circle', 8, '냉각 홀을 한 곳씩 뚫으세요', '#8a8a90'),
        ],
        fasten: [tighten('디스크 고정 볼트 조이기', 4)],
      };
    case 'caliper':
      return {
        makesPart: true,
        fab: [
          cast('캘리퍼 주조', 5, 3),
          path('bore', '피스톤 보어 가공', 'drill', 'cylinder', 'circle', 6, '보어를 원을 따라 가공하세요', '#8a8a90'),
          path('polish', '표면 연마', 'file', 'plate', 'zigzag', 4, '표면을 문질러 연마하세요', '#d0d0d6'),
        ],
        fasten: [tighten('캘리퍼 볼트 조이기', 4)],
      };
    case 'beam':
      return {
        makesPart: true,
        fab: [
          cast(`${label} 주조`, 4, 3),
          path('cut', '절단 및 맞춤 가공', 'cutter', 'rod', 'line', 4, '절단기를 한 구간씩 밀어 길이를 맞추세요', '#b8bcc2'),
          path('grind', '용접면 연마', 'file', 'rod', 'zigzag', 4, '용접면을 문질러 다듬으세요', '#c8c8ce'),
        ],
        fasten: [weld(`${label} 이음 용접`, 6)],
      };
    case 'seatFrame':
      return {
        makesPart: true,
        fab: [
          cast('시트 프레임 파이프 주조', 4, 3),
          path('cut', '파이프 절단', 'cutter', 'rod', 'line', 4, '파이프를 한 구간씩 자르세요', '#b8bcc2'),
          path('weld', '프레임 용접', 'torch', 'rod', 'outline', 8, '토치를 프레임 둘레를 따라 한 구간씩 용접하세요', '#ff8a2a'),
        ],
        fasten: [tighten('시트 레일 볼트 조이기', 4)],
      };
    case 'cushion':
      return {
        makesPart: true,
        fab: [
          path('cut', '폼 재단', 'cutter', 'cloth', 'outline', 8, '가위를 외곽선을 따라 한 구간씩 자르세요', '#8a6a4a'),
          path('shape', '폼 성형', 'press', 'cloth', 'zigzag', 5, '폼을 눌러 곡면을 만드세요', '#8a6a4a'),
          path('stitch', '쿠션 박음질', 'needle', 'cloth', 'line', 10, '바늘을 한 땀씩 끌어 박음질하세요', '#e8d8b8'),
        ],
        fasten: [],
      };
    case 'cover':
      return {
        makesPart: true,
        fab: [
          path('cut', '가죽 재단', 'cutter', 'cloth', 'outline', 8, '가위를 외곽선을 따라 한 구간씩 자르세요', '#5c4433'),
          path('stitch', '박음질 (한 땀씩)', 'needle', 'cloth', 'line', 12, '바늘을 한 땀씩 끌어 박음질하세요', '#e8d8b8'),
          path('back', '되돌아 박음질(매듭)', 'needle', 'cloth', 'line', 4, '끝에서 되돌아 겹쳐 박아 매듭을 지으세요', '#e8d8b8'),
        ],
        fasten: [],
      };
    case 'steeringWheel':
      return {
        makesPart: true,
        fab: [
          cast('스티어링 림 주조', 5, 3),
          path('wrap', '가죽 감싸기 박음질', 'needle', 'cloth', 'circle', 14, '바늘을 림 둘레로 한 땀씩 끌어 박음질하세요', '#e8d8b8'),
          path('polish', '림 연마', 'file', 'plate', 'zigzag', 4, '림을 문질러 연마하세요', '#d0d0d6'),
        ],
        fasten: [tighten('스티어링 허브 너트 조이기', 5)],
      };
    case 'strap':
      return {
        makesPart: true,
        fab: [
          path('cut', '벨트 웨빙 재단', 'cutter', 'cloth', 'line', 3, '웨빙을 한 구간씩 자르세요', '#2a2a2a'),
          path('bartack', '벨트 고정 박음질', 'needle', 'cloth', 'zigzag', 8, '바늘을 지그재그로 한 땀씩 박으세요', '#e8d8b8'),
          path('buckle', '버클 압착', 'press', 'plate', 'line', 3, '버클을 눌러 압착하세요', '#aaa'),
        ],
        fasten: [tighten('벨트 앵커 볼트 조이기', 4)],
      };
    case 'airbag':
      return {
        makesPart: true,
        fab: [
          path('cut', '에어백 원단 재단', 'cutter', 'cloth', 'outline', 8, '원단을 외곽선을 따라 자르세요', '#e8e2d8'),
          path('stitch', '에어백 이음 박음질', 'needle', 'cloth', 'outline', 12, '바늘을 둘레로 한 땀씩 박음질하세요', '#e8d8b8'),
          path('fold', '접기 및 포장', 'press', 'cloth', 'zigzag', 5, '접힌 선을 한 구간씩 눌러 포장하세요', '#e8e2d8'),
        ],
        fasten: [tighten('에어백 모듈 고정 볼트', 4)],
      };
    case 'speaker':
      return {
        makesPart: true,
        fab: [
          cast('스피커 프레임 주조', 4, 2),
          path('cone', '콘 재단', 'cutter', 'cloth', 'circle', 8, '가위를 둘레로 돌려 콘을 자르세요', '#222'),
          path('coil', '보이스 코일 감기', 'press', 'rod', 'circle', 10, '코일을 한 바퀴씩 감으세요', '#c06020'),
          path('terminal', '단자 납땜', 'solder', 'board', 'line', 3, '단자를 한 곳씩 납땜하세요', '#d4d4d8'),
        ],
        fasten: [tighten('스피커 고정 볼트', 4)],
      };
    case 'ampBox':
      return {
        makesPart: true,
        fab: [
          cast('앰프 케이스 주조', 4, 2),
          path('board', '앰프 기판 납땜', 'solder', 'board', 'zigzag', 8, '기판 패턴을 따라 납땜하세요', '#d4d4d8'),
          path('close', '케이스 조립', 'screwdriver', 'bolt', 'circle', 4, '케이스를 나사로 고정하세요', '#d0d0d4'),
        ],
        fasten: [tighten('앰프 고정 볼트', 4)],
      };
    case 'screw':
      return {
        makesPart: true,
        fab: [
          cast('나사 주조', 3, 1),
          path('thread', '나사산 절삭', 'file', 'rod', 'line', 5, '다이스를 축 방향으로 한 구간씩 돌려 나사산을 내세요', '#d0d0d4'),
        ],
        fasten: [path('drive', '나사 조이기', 'screwdriver', 'bolt', 'circle', 8, '드라이버를 원을 그리며 한 칸씩 돌려 조이세요', '#d0d0d4', true)],
      };
    default:
      return {
        makesPart: true,
        fab: [
          cast(`${label} 주조`, 4, 3),
          path('finish', '표면 마감 연마', 'file', 'plate', 'zigzag', 5, '표면을 지그재그로 문질러 마감하세요', '#c8c8ce'),
        ],
        fasten: [tighten(`${label} 고정 볼트 조이기`, 5)],
      };
  }
}

const recipeCache = new Map<string, Recipe>();

export function getRecipe(label: string): Recipe {
  const hit = recipeCache.get(label);
  if (hit) return hit;
  const r = buildRecipe(label);
  recipeCache.set(label, r);
  return r;
}

function buildRecipe(label: string): Recipe {
  // pure process units (no physical part is produced)
  if (label.includes('도장') || label.includes('클리어코트')) {
    return {
      makesPart: false,
      fab: [
        path('sand', `${label} — 표면 연마`, 'file', 'surface', 'zigzag', 6, '연마기를 지그재그로 밀어 도장면을 준비하세요', '#d8d8dc', true),
        path('spray', `${label} — 분사`, 'brush', 'surface', 'zigzag', 10, '스프레이건을 지그재그로 한 구간씩 이동시키며 분사하세요', '#f5c518', true),
        path('cure', `${label} — 건조`, 'heatgun', 'surface', 'line', 4, '열풍기를 한 구간씩 이동시켜 건조시키세요', '#ff8a2a', true),
      ],
      fasten: [],
    };
  }
  if (label.includes('볼트')) {
    return {
      makesPart: false,
      fab: [tighten(`${label} 조이기`, 8)],
      fasten: [],
    };
  }
  const { key } = resolveShape(label);
  return expandCast(recipeForShape(key, label), key);
}

export function recipeTaskCount(r: Recipe): number {
  return r.fab.length + (r.makesPart ? 1 + r.fasten.length : 0);
}

/** Rest position for a freshly fabricated part (beside the bench, well away from the car). */
export function restSpot(ordinal: number): [number, number, number] {
  return [-2.8 + (ordinal % 6) * 0.55, 0.3, 7.4 + Math.floor(ordinal / 6) * 0.6];
}

/** short label of a single task for step lists */
export function taskKindLabel(spec: TaskSpec): string {
  return spec.kind === 'cast' ? '주조실' : spec.atTarget ? '차량 위' : '작업대';
}
