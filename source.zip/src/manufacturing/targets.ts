// Shared formulas for where each unit must be placed on / inside the car.
// Used by BOTH the assembly station (distance check) and the 3D scene (blue
// target rings), so what the player sees is exactly what gets checked.

/** Where the hand-work bench room stands (sewing, soldering, filing...) — far away from the garage, a separate space. */
export const BENCH_ORIGIN: [number, number, number] = [90, 0, 0];
/** The foundry room (carve the sand mould, melt, pour, cool, quench). */
export const FORGE_ORIGIN: [number, number, number] = [-90, 0, 0];

function gridShape(total: number) {
  const cols = total <= 8 ? 4 : total <= 24 ? 6 : 8;
  const rows = Math.max(1, Math.ceil(total / cols));
  const sx = Math.min(0.5, 1.9 / Math.max(1, cols - 1));
  const sz = Math.min(0.55, 3.8 / Math.max(1, rows - 1));
  return { cols, rows, sx, sz };
}

/**
 * Grid of seats for every unit of a step, spread over the car's footprint.
 * `layer` lifts each step a little so parts from different steps don't sit
 * exactly on top of each other.
 */
export function getAssemblyTarget(idx: number, total: number, layer = 0): [number, number, number] {
  const { cols, rows, sx, sz } = gridShape(total);
  const row = Math.floor(idx / cols);
  const col = idx % cols;
  return [(col - (cols - 1) / 2) * sx, 0.45 + (layer % 5) * 0.12, (row - (rows - 1) / 2) * sz];
}

/** Visual scale for the blue ring so dense grids don't overlap. */
export function getRingScale(total: number): number {
  const { sx, sz } = gridShape(total);
  return Math.max(0.35, Math.min(1, Math.min(sx, sz) / 0.5));
}
