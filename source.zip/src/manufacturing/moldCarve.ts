// ─────────────────────────────────────────────────────────────────────────
// Pure maths for the foundry mini-games (no three.js, so it is unit-testable):
//   • a sand-mould heightfield you scrape away — the amount removed is
//     proportional to how far (and how often) the scraper travelled
//   • the cavity outline for every kind of part
//   • molten-metal fill order, cooling temperatures, polishing coverage
// ─────────────────────────────────────────────────────────────────────────

export const GW = 96; // cells across the block's width (x)
export const GH = 64; // cells along its depth (z)
export const BLOCK_W = 3.2;
export const BLOCK_D = 2.2;
export const NV = (GW + 1) * (GH + 1);

export const vx = (i: number) => (i / GW - 0.5) * BLOCK_W;
export const vz = (j: number) => (j / GH - 0.5) * BLOCK_D;
export const idx = (i: number, j: number) => j * (GW + 1) + i;

type Inside = (x: number, z: number) => boolean;

const rrect = (cx: number, cz: number, hx: number, hz: number, r: number): Inside => (x, z) => {
  const dx = Math.abs(x - cx) - (hx - r);
  const dz = Math.abs(z - cz) - (hz - r);
  if (dx <= 0 || dz <= 0) return Math.abs(x - cx) <= hx && Math.abs(z - cz) <= hz;
  return dx * dx + dz * dz <= r * r;
};
const disc = (cx: number, cz: number, r: number): Inside => (x, z) => (x - cx) ** 2 + (z - cz) ** 2 <= r * r;
const union = (...f: Inside[]): Inside => (x, z) => f.some((g) => g(x, z));
const minus = (a: Inside, ...b: Inside[]): Inside => (x, z) => a(x, z) && !b.some((g) => g(x, z));

function gearShape(R: number, teeth: number, hole: number): Inside {
  return (x, z) => {
    const r = Math.hypot(x, z);
    if (r < hole) return false;
    const th = Math.atan2(z, x);
    const lim = R * (1 + 0.1 * Math.sign(Math.sin(teeth * th)));
    return r <= lim;
  };
}

/** The cavity outline for a part kind. Units are metres on the mould block. */
export function cavityFor(shape: string): Inside {
  switch (shape) {
    case 'panel': return minus(rrect(0, 0, 1.1, 0.62, 0.2), disc(0.7, 0.3, 0.09));
    case 'slab': return rrect(0, 0, 1.05, 0.6, 0.05);
    case 'block': return minus(rrect(0, 0, 1.0, 0.65, 0.08), disc(-0.55, 0, 0.17), disc(0, 0, 0.17), disc(0.55, 0, 0.17));
    case 'piston': return minus(rrect(0, 0, 0.9, 0.42, 0.3), rrect(0.05, 0, 0.025, 0.5, 0), rrect(0.22, 0, 0.025, 0.5, 0), rrect(0.39, 0, 0.025, 0.5, 0));
    case 'shaft': return union(rrect(0, 0, 1.2, 0.13, 0.05), disc(-0.85, 0, 0.3), disc(-0.28, 0, 0.3), disc(0.28, 0, 0.3), disc(0.85, 0, 0.3));
    case 'turbo': return union(disc(-0.45, 0, 0.5), disc(0.5, 0.12, 0.36), rrect(0.1, 0, 0.35, 0.18, 0.05));
    case 'gearbox': return gearShape(0.66, 14, 0.18);
    case 'wheel': return minus(disc(0, 0, 0.7), disc(0, 0, 0.14), ...[0, 1, 2, 3, 4].map((k) => disc(Math.cos((k / 5) * Math.PI * 2) * 0.42, Math.sin((k / 5) * Math.PI * 2) * 0.42, 0.15)));
    case 'tire': return minus(disc(0, 0, 0.72), disc(0, 0, 0.42));
    case 'disc': return minus(disc(0, 0, 0.68), disc(0, 0, 0.16), ...[0, 1, 2, 3, 4, 5, 6, 7].map((k) => disc(Math.cos((k / 8) * Math.PI * 2) * 0.46, Math.sin((k / 8) * Math.PI * 2) * 0.46, 0.06)));
    case 'caliper': return union(rrect(-0.3, 0, 0.6, 0.22, 0.06), rrect(0.35, 0.28, 0.3, 0.5, 0.06));
    case 'coil': return (x, z) => Math.abs(x) < 1.15 && Math.abs(z - 0.32 * Math.sin(x * 3.2)) < 0.13;
    case 'beam': return union(rrect(0, 0, 1.15, 0.1, 0.02), rrect(-1.0, 0, 0.15, 0.3, 0.03), rrect(1.0, 0, 0.15, 0.3, 0.03));
    case 'seatFrame': return minus(rrect(0, 0, 0.85, 0.58, 0.08), rrect(0, 0, 0.65, 0.4, 0.04));
    case 'steeringWheel': return union(minus(disc(0, 0, 0.66), disc(0, 0, 0.5)), rrect(0, 0, 0.58, 0.07, 0), rrect(0, -0.28, 0.07, 0.3, 0));
    case 'speaker': return minus(disc(0, 0, 0.62), disc(0, 0, 0.22));
    case 'screw': return union(disc(-0.95, 0, 0.24), rrect(0.1, 0, 1.05, 0.07, 0.02));
    case 'wire':
    case 'tube': return union(rrect(0, 0, 1.2, 0.07, 0.03), disc(-1.2, 0, 0.12), disc(1.2, 0, 0.12));
    case 'ampBox':
    case 'hydraulicUnit': return minus(rrect(0, 0, 0.85, 0.55, 0.06), disc(0.55, 0, 0.12));
    case 'ingot': return rrect(0, 0, 0.9, 0.45, 0.05);
    default: return rrect(0, 0, 0.9, 0.55, 0.12);
  }
}

export interface CarveField {
  /** carved depth 0..1 per vertex */
  d: Float32Array;
  /** 1 where the cavity outline is */
  mask: Uint8Array;
  /** 1 on the thin band just outside the outline (forgiven) */
  forgive: Uint8Array;
  maskCount: number;
  /** molten-fill front distance from the sprue, 0 outside the cavity */
  order: Float32Array;
  maxOrder: number;
  sprue: [number, number];
}

export function newField(shape: string): CarveField {
  const inside = cavityFor(shape);
  const mask = new Uint8Array(NV);
  let count = 0;
  let sx = 0;
  let sz = 0;
  for (let j = 0; j <= GH; j++) {
    for (let i = 0; i <= GW; i++) {
      if (inside(vx(i), vz(j))) {
        mask[idx(i, j)] = 1;
        count++;
        sx += vx(i);
        sz += vz(j);
      }
    }
  }
  const forgive = new Uint8Array(NV);
  for (let j = 0; j <= GH; j++) {
    for (let i = 0; i <= GW; i++) {
      if (mask[idx(i, j)]) continue;
      let near = false;
      for (let dj = -2; dj <= 2 && !near; dj++) {
        for (let di = -2; di <= 2; di++) {
          const a = i + di;
          const b = j + dj;
          if (a >= 0 && a <= GW && b >= 0 && b <= GH && mask[idx(a, b)]) { near = true; break; }
        }
      }
      if (near) forgive[idx(i, j)] = 1;
    }
  }
  // the sprue (pouring hole) sits on the cavity cell closest to its centroid
  const cx = count ? sx / count : 0;
  const cz = count ? sz / count : 0;
  let best = Infinity;
  let sprue: [number, number] = [cx, cz];
  for (let j = 0; j <= GH; j++) {
    for (let i = 0; i <= GW; i++) {
      if (!mask[idx(i, j)]) continue;
      const dd = (vx(i) - cx) ** 2 + (vz(j) - cz) ** 2;
      if (dd < best) { best = dd; sprue = [vx(i), vz(j)]; }
    }
  }
  const order = new Float32Array(NV);
  let maxOrder = 0.0001;
  for (let j = 0; j <= GH; j++) {
    for (let i = 0; i <= GW; i++) {
      if (!mask[idx(i, j)]) continue;
      const o = Math.hypot(vx(i) - sprue[0], vz(j) - sprue[1]);
      order[idx(i, j)] = o;
      if (o > maxOrder) maxOrder = o;
    }
  }
  return { d: new Float32Array(NV), mask, forgive, maskCount: count, order, maxOrder, sprue };
}

/** A mould carved earlier: perfectly cut at quality 100, sloppier edges below. */
export function carvedField(shape: string, quality: number): CarveField {
  const f = newField(shape);
  const sloppy = Math.max(0, (100 - quality) / 100);
  let seed = 977;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  for (let k = 0; k < NV; k++) {
    if (f.mask[k]) f.d[k] = 1;
    else if (f.forgive[k]) f.d[k] = rnd() < sloppy * 1.4 ? 0.4 + rnd() * 0.5 : 0;
  }
  return f;
}

export function flowOrder(f: CarveField): { order: Float32Array; max: number } {
 const order = new Float32Array(NV); order.fill(Infinity);
 const si = Math.round((f.sprue[0] / BLOCK_W + 0.5) * GW), sj = Math.round((f.sprue[1] / BLOCK_D + 0.5) * GH), start = idx(si, sj);
 if (f.d[start] < 0.3) return { order, max: 1 };
 const queue = new Int32Array(NV); let head = 0, tail = 0, max = 1; order[start] = 0; queue[tail++] = start;
 while (head < tail) { const k = queue[head++], i = k % (GW + 1), j = Math.floor(k / (GW + 1));
  for (const [di, dj] of [[1,0],[-1,0],[0,1],[0,-1]]) { const x = i + di, y = j + dj;
   if (x < 0 || x > GW || y < 0 || y > GH) continue; const n = idx(x,y);
   if (f.d[n] < 0.3 || Number.isFinite(order[n])) continue; order[n] = order[k] + 1; max = Math.max(max, order[n]); queue[tail++] = n;
  }
 } return { order, max };
}

export interface ScrapeResult { touched: number }

/**
 * Scrape the mould. `moved` is the distance (metres) the scraper travelled since
 * the last call — depth removed is proportional to it, so scraping the same
 * spot repeatedly digs deeper and standing still removes nothing.
 */
export function scrape(f: CarveField, x: number, z: number, moved: number, radius = 0.075, rate = 7): ScrapeResult {
  if (moved <= 0) return { touched: 0 };
  const i0 = Math.max(0, Math.floor(((x - radius) / BLOCK_W + 0.5) * GW));
  const i1 = Math.min(GW, Math.ceil(((x + radius) / BLOCK_W + 0.5) * GW));
  const j0 = Math.max(0, Math.floor(((z - radius) / BLOCK_D + 0.5) * GH));
  const j1 = Math.min(GH, Math.ceil(((z + radius) / BLOCK_D + 0.5) * GH));
  let touched = 0;
  for (let j = j0; j <= j1; j++) {
    for (let i = i0; i <= i1; i++) {
      const dd = Math.hypot(vx(i) - x, vz(j) - z) / radius;
      if (dd >= 1) continue;
      const w = Math.pow(1 - dd * dd, 1.5);
      const k = idx(i, j);
      const before = f.d[k];
      f.d[k] = Math.min(1, before + rate * moved * w);
      if (f.d[k] !== before) touched++;
    }
  }
  return { touched };
}

/** Restore sand under a dragged repair tool. Depth can be cut again later. */
export function fillSand(f: CarveField, x: number, z: number, moved: number, radius = 0.10, rate = 7): void {
  if (moved <= 0) return;
  const i0 = Math.max(0, Math.floor(((x - radius) / BLOCK_W + 0.5) * GW));
  const i1 = Math.min(GW, Math.ceil(((x + radius) / BLOCK_W + 0.5) * GW));
  const j0 = Math.max(0, Math.floor(((z - radius) / BLOCK_D + 0.5) * GH));
  const j1 = Math.min(GH, Math.ceil(((z + radius) / BLOCK_D + 0.5) * GH));
  for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
    const dd = Math.hypot(vx(i) - x, vz(j) - z) / radius;
    if (dd >= 1) continue;
    const k = idx(i,j); f.d[k] = Math.max(0, f.d[k] - rate * moved * Math.pow(1 - dd * dd, 1.5));
  }
}

export interface CarveStats { fill: number; over: number; quality: number }

export function carveStats(f: CarveField): CarveStats {
  let filled = 0;
  let over = 0;
  for (let k = 0; k < NV; k++) {
    if (f.mask[k]) { if (f.d[k] >= 0.85) filled++; }
    else if (!f.forgive[k] && f.d[k] > 0.3) over++;
  }
  const fill = f.maskCount ? filled / f.maskCount : 0;
  const overFrac = f.maskCount ? over / f.maskCount : 0;
  const quality = Math.round(Math.max(25, Math.min(100, 100 - overFrac * 130 - (1 - fill) * 40)));
  return { fill, over: overFrac, quality };
}

/**
 * Blurred carved region → heights for the finished casting's relief mesh.
 *
 * Previously this only used the cavity mask, so if the player had scraped
 * outside the golden outline the extra grooves stayed in the sand but the
 * molten metal visualisation and the final piece pretended they weren't
 * there. Now every carved cell contributes: the piece takes the exact
 * shape of the carved space, mistakes and all, so a lopsided mould comes
 * out of the foundry as a lopsided casting.
 */
export function pieceHeights(f: CarveField): Float32Array {
  let a = new Float32Array(NV);
  const flow = flowOrder(f);
  for (let k = 0; k < NV; k++) if (Number.isFinite(flow.order[k])) a[k] = f.d[k];
  for (let pass = 0; pass < 2; pass++) {
    const b = new Float32Array(NV);
    for (let j = 0; j <= GH; j++) {
      for (let i = 0; i <= GW; i++) {
        let s = 0;
        let n = 0;
        for (let dj = -1; dj <= 1; dj++) {
          for (let di = -1; di <= 1; di++) {
            const ii = i + di;
            const jj = j + dj;
            if (ii < 0 || ii > GW || jj < 0 || jj > GH) { n++; continue; }
            s += a[idx(ii, jj)];
            n++;
          }
        }
        b[idx(i, j)] = s / n;
      }
    }
    a = b;
  }
  return a;
}

// ── cooling ──────────────────────────────────────────────────────────────

export interface CoolField { t: Float32Array }
export function newCool(f: CarveField): CoolField {
  const t = new Float32Array(NV);
  for (let k = 0; k < NV; k++) t[k] = f.mask[k] ? 1 : 0;
  return { t };
}

/** returns thermal stress added this tick (fast uneven cooling cracks metal) */
export function blow(c: CoolField, f: CarveField, x: number, z: number, dt: number, radius = 0.38): number {
  let stress = 0;
  for (let j = 0; j <= GH; j++) {
    const zz = vz(j);
    if (Math.abs(zz - z) > radius) continue;
    for (let i = 0; i <= GW; i++) {
      const xx = vx(i);
      if (Math.abs(xx - x) > radius) continue;
      const k = idx(i, j);
      if (!f.mask[k]) continue;
      const dd = Math.hypot(xx - x, zz - z) / radius;
      if (dd >= 1) continue;
      const w = 1 - dd * dd;
      c.t[k] = Math.max(0, c.t[k] - dt * 0.55 * w);
    }
  }
  // stress: a cell far colder than its hot neighbourhood
  let cold = 0;
  let hot = 0;
  for (let k = 0; k < NV; k += 7) {
    if (!f.mask[k]) continue;
    if (c.t[k] < 0.12) cold++;
    else if (c.t[k] > 0.75) hot++;
  }
  if (cold > 6 && hot > 6) stress = dt;
  return stress;
}

export function coolTick(c: CoolField, f: CarveField, dt: number) {
  for (let k = 0; k < NV; k++) if (f.mask[k]) c.t[k] = Math.max(0, c.t[k] - dt * 0.012);
}

export function coolProgress(c: CoolField, f: CarveField): number {
  let s = 0;
  for (let k = 0; k < NV; k++) if (f.mask[k]) s += c.t[k];
  return f.maskCount ? 1 - s / f.maskCount : 0;
}

export function coolMax(c: CoolField, f: CarveField): number {
  let m = 0;
  for (let k = 0; k < NV; k++) if (f.mask[k] && c.t[k] > m) m = c.t[k];
  return m;
}

// ── polishing ────────────────────────────────────────────────────────────

export function polish(cover: Float32Array, f: CarveField, x: number, z: number, moved: number, radius = 0.1, rate = 5) {
  if (moved <= 0) return;
  const i0 = Math.max(0, Math.floor(((x - radius) / BLOCK_W + 0.5) * GW));
  const i1 = Math.min(GW, Math.ceil(((x + radius) / BLOCK_W + 0.5) * GW));
  const j0 = Math.max(0, Math.floor(((z - radius) / BLOCK_D + 0.5) * GH));
  const j1 = Math.min(GH, Math.ceil(((z + radius) / BLOCK_D + 0.5) * GH));
  for (let j = j0; j <= j1; j++) {
    for (let i = i0; i <= i1; i++) {
      const k = idx(i, j);
      if (!f.mask[k]) continue;
      const dd = Math.hypot(vx(i) - x, vz(j) - z) / radius;
      if (dd >= 1) continue;
      cover[k] = Math.min(1, cover[k] + rate * moved * (1 - dd * dd));
    }
  }
}

export function polishProgress(cover: Float32Array, f: CarveField): number {
  let n = 0;
  for (let k = 0; k < NV; k++) if (f.mask[k] && cover[k] >= 0.9) n++;
  return f.maskCount ? n / f.maskCount : 0;
}
