import { useGameStore } from './store/useGameStore';
import IntroScreen from './components/IntroScreen';
import TutorialScreen from './components/TutorialScreen';
import CarSelectScreen from './components/CarSelectScreen';
import ModelSelectScreen from './components/ModelSelectScreen';
import OptionSelectScreen from './components/OptionSelectScreen';
import WorkshopScreen from './components/WorkshopScreen';
import CompletionScreen from './components/CompletionScreen';
import DriveScreen from './components/DriveScreen';

export default function App() {
  const screen = useGameStore((s) => s.screen);

  return (
    <div className="app-root">
      {screen === 'intro' && <IntroScreen />}
      {screen === 'menu' && <IntroScreen />}
      {screen === 'tutorial' && <TutorialScreen />}
      {screen === 'carSelect' && <CarSelectScreen />}
      {screen === 'modelSelect' && <ModelSelectScreen />}
      {screen === 'optionSelect' && <OptionSelectScreen />}
      {screen === 'workshop' && <WorkshopScreen />}
      {screen === 'completion' && <CompletionScreen />}
      {screen === 'drive' && <DriveScreen />}
    </div>
  );
}
