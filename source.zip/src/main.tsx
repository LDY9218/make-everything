import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { startRouting } from './routing';
import './styles/global.css';

void startRouting().then(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode><App /></React.StrictMode>,
  );
});
